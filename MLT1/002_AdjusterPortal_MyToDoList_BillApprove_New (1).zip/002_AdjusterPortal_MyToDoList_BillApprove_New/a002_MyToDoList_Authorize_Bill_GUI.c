a002_MyToDoList_Authorize_Bill_GUI()
{
	lr_think_time(5);

	lr_start_transaction("a002_Bill_Select");

	web_check_box("WidgetContainerX$WidgetX$MTD", 
		"Snapshot=t38.inf", 
		DESCRIPTION, 
		"Name=WidgetContainer{WidgetContainerID}$Widget{WidgetContainerID}$MTDGrid$ctl02$chkSelected", 
		ACTION, 
		"Set=ON", 
		LAST);
	
	lr_end_transaction("a002_Bill_Select",LR_AUTO);
	
	lr_start_transaction("a002_Bill_Authorize");
	
	lr_output_message("WidgetContainerID=%s"
		,lr_eval_string("{WidgetContainerID}")
		);
	
	web_reg_dialog(
		DESCRIPTION, 
		"Type=Modal", 
		ACTION, 
		"SetCallback=ModalDialog1", 
		LAST);
	/*
	lr_set_debug_message(LR_MSG_CLASS_EXTENDED_LOG | LR_MSG_CLASS_RESULT_DATA | LR_MSG_CLASS_PARAMETERS | LR_MSG_CLASS_FULL_TRACE, LR_MSG_ON );
	lr_set_debug_message(LR_MSG_CLASS_JIT_LOG_ON_ERROR , LR_SWITCH_OFF); 
	*/
	//Click on 'Authorize...' in MyToDoList
	
	//Expected return 'cmdAuthorizeBillSave'
	web_button("Authorize_Bill", 
		"Snapshot=t39.inf", 
		DESCRIPTION, 
		"Type=submit", 
		"Tag=INPUT", 
		"ID=WidgetContainer{WidgetContainerID}_Widget{WidgetContainerID}_cmdAuthorize", 
		"BrowserOrdinal=1", 
		ACTION, 
		"UserAction=Click", 
		LAST);
	
	lr_think_time(10);
	
	//Click 'OK' out of Authorize Screen
	web_button("Confirm", 
		"Snapshot=t41.inf", 
		DESCRIPTION, 
		"Type=button", 
		"Tag=INPUT", 
		"ID=DeleteConfirmPopup_No", 
		ACTION, 
		"UserAction=Click", 
		LAST);
	
	lr_end_transaction("a002_Bill_Authorize",LR_AUTO);

	lr_think_time(5);

	return 0;
}