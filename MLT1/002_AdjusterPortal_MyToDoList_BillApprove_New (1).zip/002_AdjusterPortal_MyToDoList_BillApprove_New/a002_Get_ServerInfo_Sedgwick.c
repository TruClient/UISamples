a002_Get_ServerInfo_Sedgwick()
{
	// *******************************************************************************************
	// Created by:	Jason Wei
	// Create Date:	8/22/08
	// Description:	This action retrieves the server information for CareSolutions
	// 				Separate actions are created for each customer so that the distribution
	// 				between the clients can be easily changed in run-time settings.
	// History:		
	// 
	// 02/08/2010 - JWei:	Changed DuplicateClientInstance to use an Additional Attribute
	// 						(Runtime setting)
	// *******************************************************************************************

    

	lr_start_transaction("a002t_RetrievingServerInfo");

	lr_output_message( "DuplicateClientInstanceValue: %s", lr_get_attrib_string("DuplicateClientInstanceValue") ); //DEBUG CODE

	//Find the line for appropriate CustomerID
	do {
		//traverse sequentially through the list until the correct CustomerID is found
		lr_save_string(lr_eval_string("{GetCustomerIDFromURLFile}"), "CustomerIDFromURLFile");
		lr_output_message( "CurrentID: %s", lr_eval_string("{CustomerIDFromURLFile}") ); //DEBUG CODE
		lr_save_string(lr_eval_string("{GetDuplicateClientInstance}"), "DuplicateClientInstance");
		lr_output_message( "CurrentDupClientInstance: %s", lr_eval_string("{DuplicateClientInstance}") ); //DEBUG CODE
	} while (  !((atoi(lr_eval_string("{CustomerIDFromURLFile}")) == 35) &&
			   (atoi(lr_eval_string("{DuplicateClientInstance}")) == 
	              atoi(lr_get_attrib_string("DuplicateClientInstanceValue")) ))  );

	lr_output_message( "Selected ID: %s", lr_eval_string("{CustomerIDFromURLFile}") ); //DEBUG CODE


	//Retrieve ClientDBName
	lr_save_string(lr_eval_string("{GetClientDBName}"), "ClientDBName");


	//Retrieve ServerURL
	lr_save_string(lr_eval_string("{GetServerURL}"), "ServerURL");


	//Retrieve CustomerCode
	lr_save_string(lr_eval_string("{GetCustomerCode}"), "CustomerCode");


	//Retrieve DBServerName
	lr_save_string(lr_eval_string("{GetDBServerName}"), "DBServerName");


	//Retrieve EDIServerName
	lr_save_string(lr_eval_string("{GetEDIServerName}"), "EDIServerName");


	//Retrieve AccountID
	lr_start_transaction("a002t_RetrieveValidAccountID");

	//Used for login query
	do {
		//choose a random row until correct CustomerID is found
		//This loop traverses through the SC_DemographicInfo.dat file
		lr_save_string(lr_eval_string("{GetCustomerID}"), "OrigCustomerID");
		lr_output_message( "CurrentID: %s", lr_eval_string("{OrigCustomerID}") ); //DEBUG CODE
	} while (  atoi(lr_eval_string("{OrigCustomerID}")) != 35 );
	lr_save_string(lr_eval_string("{GetAccountID}"), "OrigAccountID");

	lr_output_message( "Selected OrigCustID: %s", lr_eval_string("{OrigCustomerID}") ); //DEBUG CODE
	lr_output_message( "Selected OrigAcctID: %s", lr_eval_string("{OrigAccountID}") ); //DEBUG CODE

	lr_end_transaction("a002t_RetrieveValidAccountID", LR_AUTO);


	lr_end_transaction("a002t_RetrievingServerInfo", LR_AUTO);

	return 0;
}

