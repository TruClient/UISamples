a002_ThinkTime()
{
	//Wait set to 1200 seconds
	//lr_think_time(1);

	// Sleep 120 seconds x 10 (Run-Time Run Logic is set to repeat Think Time 100x)
	// If script stop is called, then allows for earlier abort.
	//sleep(12000);
	//lr_think_time(120);  //with think time set to 25-175%, creates bell curves every 20 min
	lr_think_time(30);

	return 0;
}
