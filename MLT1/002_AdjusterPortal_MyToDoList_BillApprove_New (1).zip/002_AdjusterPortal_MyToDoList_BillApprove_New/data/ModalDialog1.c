ModalDialog1()
{
	web_button("INPUT_2", 
		"Snapshot=t177.inf", 
		DESCRIPTION, 
		"Type=submit", 
		"Tag=INPUT", 
		"ID=cmdAuthorizeBillSave", 
		"WindowType=Modal", 
		ACTION, 
		"UserAction=Click", 
		LAST);

	return 0;
}

