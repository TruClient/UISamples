a002_MyToDoList_Authorize_Bill_GUI()
{

	web_add_cookie_ex("Cookie=Claim_process_search=9589080%7E%20; domain=lt4-cmi.stratacare.net; path=/LT4-CMI/strataware/Common/datagrid/", ENDITEM, 
		"Cookie=VersionNumber=7.04.0001.010.2252; domain=qaidplt4.stratacareservices1.net; path=/", ENDITEM, 
		LAST);

	web_browser("lt4-cmi.stratacare.net", 
		DESCRIPTION, 
		ACTION, 
		"Navigate=https://lt4-cmi.stratacare.net/", 
		LAST);

	lr_think_time(15);

	lr_start_transaction("Login");

	web_edit_field("_login$UserName", 
		"Snapshot=t36.inf", 
		DESCRIPTION, 
		"Type=text", 
		"Name=_login$UserName", 
		ACTION, 
		"SetValue=lt_adjuster_35_1@stratacare.com", 
		LAST);

	web_edit_field("_login$Password", 
		"Snapshot=t37.inf", 
		DESCRIPTION, 
		"Type=password", 
		"Name=_login$Password", 
		ACTION, 
		"SetEncryptedValue=551c88598d740183ed4f3063", 
		LAST);

	lr_end_transaction("Login",LR_AUTO);

	lr_think_time(4);

	lr_start_transaction("Bill_Select");

	web_check_box("WidgetContainer56023$Widget56023$MTD", 
		"Snapshot=t38.inf", 
		DESCRIPTION, 
		"Name=WidgetContainer56023$Widget56023$MTDGrid$ctl02$chkSelected", 
		ACTION, 
		"Set=ON", 
		LAST);

	lr_end_transaction("Bill_Select",LR_AUTO);

	lr_start_transaction("Bill_Authorize");

	web_reg_dialog(
		DESCRIPTION, 
		"Type=Modal", 
		ACTION, 
		"SetCallback=ModalDialog1", 
		LAST);

	lr_think_time(8);

	web_button("INPUT", 
		"Snapshot=t39.inf", 
		DESCRIPTION, 
		"Type=submit", 
		"Tag=INPUT", 
		"ID=WidgetContainer56023_Widget56023_cmdAuthorize", 
		ACTION, 
		"UserAction=Click", 
		LAST);

	web_button("INPUT_3", 
		"Snapshot=t41.inf", 
		DESCRIPTION, 
		"Type=button", 
		"Tag=INPUT", 
		"ID=DeleteConfirmPopup_No", 
		ACTION, 
		"UserAction=Click", 
		LAST);

	lr_end_transaction("Bill_Authorize",LR_AUTO);

	lr_think_time(5);

	lr_start_transaction("Logout");

	web_text_link("Log out", 
		"Snapshot=t42.inf", 
		DESCRIPTION, 
		"Text=Log out", 
		ACTION, 
		"UserAction=Click", 
		LAST);

	lr_end_transaction("Logout",LR_AUTO);

	return 0;
}