a002_MyToDoList_Authorize_Bill_URL()
{

	web_set_sockets_option("SSL_VERSION", "TLS");

	web_set_sockets_option("SSL_VERSION", "TLS1.1");

	web_url("lt4-cmi.stratacare.net", 
		"URL=https://lt4-cmi.stratacare.net/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t58.inf", 
		"Mode=HTTP", 
		LAST);

	web_set_sockets_option("SSL_VERSION", "TLS");

	web_url("default.aspx", 
		"URL=https://lt4-cmi.stratacare.net/lt4-cmi/default.aspx", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t59.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("StyleSheet.css", 
		"URL=https://qaidplt4.stratacareservices1.net/StrataCareIdentityProvider/StyleSheet.css", 
		"Resource=1", 
		"RecContentType=text/css", 
		"Referer=https://qaidplt4.stratacareservices1.net/StrataCareIdentityProvider/login.aspx?ReturnUrl=%2fStrataCareIdentityProvider%2fusers%2fissue.aspx%3fwa%3dwsignin1.0%26wtrealm%3dhttp%253a%252f%252fqasso.stratacareservices1.net%252fadfs%252fservices%252ftrust%26wctx%3d4a724f8c-a0f6-4770-af93-a976c590519d%26wct%3d2015-04-24T18%253a58%253a42Z%26whr%3dhttps%253a%252f%252fqaidplt4.stratacareservices1.net%252fstratacareidentityprovider%252ftrust&wa=wsignin1.0&wtrealm="
		"http%3a%2f%2fqasso.stratacareservices1.net%2fadfs%2fservices%2ftrust&wctx=4a724f8c-a0f6-4770-af93-a976c590519d&wct=2015-04-24T18%3a58%3a42Z&whr=https%3a%2f%2fqaidplt4.stratacareservices1.net%2fstratacareidentityprovider%2ftrust", 
		"Snapshot=t60.inf", 
		LAST);

	web_concurrent_start(NULL);

	web_url("WebResource.axd", 
		"URL=https://qaidplt4.stratacareservices1.net/StrataCareIdentityProvider/WebResource.axd?d=JDbc9IuXo1QJLy_RFVcjBdjISPw9d7fJfcOctKJvL_XAAdiLSZBT5JJG-c5Q-3ukmAcCd4rquMhCmSads1vTjaH4HNc1&t=635328527960000000", 
		"Resource=1", 
		"RecContentType=application/x-javascript", 
		"Referer=https://qaidplt4.stratacareservices1.net/StrataCareIdentityProvider/login.aspx?ReturnUrl=%2fStrataCareIdentityProvider%2fusers%2fissue.aspx%3fwa%3dwsignin1.0%26wtrealm%3dhttp%253a%252f%252fqasso.stratacareservices1.net%252fadfs%252fservices%252ftrust%26wctx%3d4a724f8c-a0f6-4770-af93-a976c590519d%26wct%3d2015-04-24T18%253a58%253a42Z%26whr%3dhttps%253a%252f%252fqaidplt4.stratacareservices1.net%252fstratacareidentityprovider%252ftrust&wa=wsignin1.0&wtrealm="
		"http%3a%2f%2fqasso.stratacareservices1.net%2fadfs%2fservices%2ftrust&wctx=4a724f8c-a0f6-4770-af93-a976c590519d&wct=2015-04-24T18%3a58%3a42Z&whr=https%3a%2f%2fqaidplt4.stratacareservices1.net%2fstratacareidentityprovider%2ftrust", 
		"Snapshot=t61.inf", 
		LAST);

	web_url("WebResource.axd_2", 
		"URL=https://qaidplt4.stratacareservices1.net/StrataCareIdentityProvider/WebResource.axd?d=EmPMn8uZm6IGvyNMxF-o1JoRjmXoCPCRC84oGAuKUtrCvv-qu51KdNZ6UU90XHEKgkJ9dns_Sm67T5-pcEG2Z9XXg0w1&t=635328527960000000", 
		"Resource=1", 
		"RecContentType=application/x-javascript", 
		"Referer=https://qaidplt4.stratacareservices1.net/StrataCareIdentityProvider/login.aspx?ReturnUrl=%2fStrataCareIdentityProvider%2fusers%2fissue.aspx%3fwa%3dwsignin1.0%26wtrealm%3dhttp%253a%252f%252fqasso.stratacareservices1.net%252fadfs%252fservices%252ftrust%26wctx%3d4a724f8c-a0f6-4770-af93-a976c590519d%26wct%3d2015-04-24T18%253a58%253a42Z%26whr%3dhttps%253a%252f%252fqaidplt4.stratacareservices1.net%252fstratacareidentityprovider%252ftrust&wa=wsignin1.0&wtrealm="
		"http%3a%2f%2fqasso.stratacareservices1.net%2fadfs%2fservices%2ftrust&wctx=4a724f8c-a0f6-4770-af93-a976c590519d&wct=2015-04-24T18%3a58%3a42Z&whr=https%3a%2f%2fqaidplt4.stratacareservices1.net%2fstratacareidentityprovider%2ftrust", 
		"Snapshot=t62.inf", 
		LAST);

	web_url("WebResource.axd_3", 
		"URL=https://qaidplt4.stratacareservices1.net/StrataCareIdentityProvider/WebResource.axd?d=HlxChpNl3FLZ8TnNI8dVqImTpnSt-ZI0vUfU2OEqI9n0-OvQHpqd25vgzU-dXvkvwd6RpI82lGCklB2R5IkEdC2kQRY1&t=635328527960000000", 
		"Resource=1", 
		"RecContentType=application/x-javascript", 
		"Referer=https://qaidplt4.stratacareservices1.net/StrataCareIdentityProvider/login.aspx?ReturnUrl=%2fStrataCareIdentityProvider%2fusers%2fissue.aspx%3fwa%3dwsignin1.0%26wtrealm%3dhttp%253a%252f%252fqasso.stratacareservices1.net%252fadfs%252fservices%252ftrust%26wctx%3d4a724f8c-a0f6-4770-af93-a976c590519d%26wct%3d2015-04-24T18%253a58%253a42Z%26whr%3dhttps%253a%252f%252fqaidplt4.stratacareservices1.net%252fstratacareidentityprovider%252ftrust&wa=wsignin1.0&wtrealm="
		"http%3a%2f%2fqasso.stratacareservices1.net%2fadfs%2fservices%2ftrust&wctx=4a724f8c-a0f6-4770-af93-a976c590519d&wct=2015-04-24T18%3a58%3a42Z&whr=https%3a%2f%2fqaidplt4.stratacareservices1.net%2fstratacareidentityprovider%2ftrust", 
		"Snapshot=t63.inf", 
		LAST);

	web_url("HeaderBack.jpg", 
		"URL=https://qaidplt4.stratacareservices1.net/StrataCareIdentityProvider/images/HeaderBack.jpg", 
		"Resource=1", 
		"RecContentType=image/jpeg", 
		"Referer=https://qaidplt4.stratacareservices1.net/StrataCareIdentityProvider/login.aspx?ReturnUrl=%2fStrataCareIdentityProvider%2fusers%2fissue.aspx%3fwa%3dwsignin1.0%26wtrealm%3dhttp%253a%252f%252fqasso.stratacareservices1.net%252fadfs%252fservices%252ftrust%26wctx%3d4a724f8c-a0f6-4770-af93-a976c590519d%26wct%3d2015-04-24T18%253a58%253a42Z%26whr%3dhttps%253a%252f%252fqaidplt4.stratacareservices1.net%252fstratacareidentityprovider%252ftrust&wa=wsignin1.0&wtrealm="
		"http%3a%2f%2fqasso.stratacareservices1.net%2fadfs%2fservices%2ftrust&wctx=4a724f8c-a0f6-4770-af93-a976c590519d&wct=2015-04-24T18%3a58%3a42Z&whr=https%3a%2f%2fqaidplt4.stratacareservices1.net%2fstratacareidentityprovider%2ftrust", 
		"Snapshot=t64.inf", 
		LAST);

	web_url("img_techbystratalogo_w144h153.gif", 
		"URL=https://qaidplt4.stratacareservices1.net/StrataCareIdentityProvider/images/img_techbystratalogo_w144h153.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=https://qaidplt4.stratacareservices1.net/StrataCareIdentityProvider/login.aspx?ReturnUrl=%2fStrataCareIdentityProvider%2fusers%2fissue.aspx%3fwa%3dwsignin1.0%26wtrealm%3dhttp%253a%252f%252fqasso.stratacareservices1.net%252fadfs%252fservices%252ftrust%26wctx%3d4a724f8c-a0f6-4770-af93-a976c590519d%26wct%3d2015-04-24T18%253a58%253a42Z%26whr%3dhttps%253a%252f%252fqaidplt4.stratacareservices1.net%252fstratacareidentityprovider%252ftrust&wa=wsignin1.0&wtrealm="
		"http%3a%2f%2fqasso.stratacareservices1.net%2fadfs%2fservices%2ftrust&wctx=4a724f8c-a0f6-4770-af93-a976c590519d&wct=2015-04-24T18%3a58%3a42Z&whr=https%3a%2f%2fqaidplt4.stratacareservices1.net%2fstratacareidentityprovider%2ftrust", 
		"Snapshot=t65.inf", 
		LAST);

	web_url("blank.gif", 
		"URL=https://qaidplt4.stratacareservices1.net/StrataCareIdentityProvider/images/blank.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=https://qaidplt4.stratacareservices1.net/StrataCareIdentityProvider/login.aspx?ReturnUrl=%2fStrataCareIdentityProvider%2fusers%2fissue.aspx%3fwa%3dwsignin1.0%26wtrealm%3dhttp%253a%252f%252fqasso.stratacareservices1.net%252fadfs%252fservices%252ftrust%26wctx%3d4a724f8c-a0f6-4770-af93-a976c590519d%26wct%3d2015-04-24T18%253a58%253a42Z%26whr%3dhttps%253a%252f%252fqaidplt4.stratacareservices1.net%252fstratacareidentityprovider%252ftrust&wa=wsignin1.0&wtrealm="
		"http%3a%2f%2fqasso.stratacareservices1.net%2fadfs%2fservices%2ftrust&wctx=4a724f8c-a0f6-4770-af93-a976c590519d&wct=2015-04-24T18%3a58%3a42Z&whr=https%3a%2f%2fqaidplt4.stratacareservices1.net%2fstratacareidentityprovider%2ftrust", 
		"Snapshot=t66.inf", 
		LAST);

	web_url("strataware_portal_logo.gif", 
		"URL=https://qaidplt4.stratacareservices1.net/StrataCareIdentityProvider/images/strataware_portal_logo.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=https://qaidplt4.stratacareservices1.net/StrataCareIdentityProvider/login.aspx?ReturnUrl=%2fStrataCareIdentityProvider%2fusers%2fissue.aspx%3fwa%3dwsignin1.0%26wtrealm%3dhttp%253a%252f%252fqasso.stratacareservices1.net%252fadfs%252fservices%252ftrust%26wctx%3d4a724f8c-a0f6-4770-af93-a976c590519d%26wct%3d2015-04-24T18%253a58%253a42Z%26whr%3dhttps%253a%252f%252fqaidplt4.stratacareservices1.net%252fstratacareidentityprovider%252ftrust&wa=wsignin1.0&wtrealm="
		"http%3a%2f%2fqasso.stratacareservices1.net%2fadfs%2fservices%2ftrust&wctx=4a724f8c-a0f6-4770-af93-a976c590519d&wct=2015-04-24T18%3a58%3a42Z&whr=https%3a%2f%2fqaidplt4.stratacareservices1.net%2fstratacareidentityprovider%2ftrust", 
		"Snapshot=t67.inf", 
		LAST);

	web_concurrent_end(NULL);

	lr_think_time(22);

	web_submit_data("login.aspx", 
		"Action=https://qaidplt4.stratacareservices1.net/StrataCareIdentityProvider/login.aspx?ReturnUrl=%2fStrataCareIdentityProvider%2fusers%2fissue.aspx%3fwa%3dwsignin1.0%26wtrealm%3dhttp%253a%252f%252fqasso.stratacareservices1.net%252fadfs%252fservices%252ftrust%26wctx%3d4a724f8c-a0f6-4770-af93-a976c590519d%26wct%3d2015-04-24T18%253a58%253a42Z%26whr%3dhttps%253a%252f%252fqaidplt4.stratacareservices1.net%252fstratacareidentityprovider%252ftrust&wa=wsignin1.0&wtrealm="
		"http%3a%2f%2fqasso.stratacareservices1.net%2fadfs%2fservices%2ftrust&wctx=4a724f8c-a0f6-4770-af93-a976c590519d&wct=2015-04-24T18%3a58%3a42Z&whr=https%3a%2f%2fqaidplt4.stratacareservices1.net%2fstratacareidentityprovider%2ftrust", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://qaidplt4.stratacareservices1.net/StrataCareIdentityProvider/login.aspx?ReturnUrl=%2fStrataCareIdentityProvider%2fusers%2fissue.aspx%3fwa%3dwsignin1.0%26wtrealm%3dhttp%253a%252f%252fqasso.stratacareservices1.net%252fadfs%252fservices%252ftrust%26wctx%3d4a724f8c-a0f6-4770-af93-a976c590519d%26wct%3d2015-04-24T18%253a58%253a42Z%26whr%3dhttps%253a%252f%252fqaidplt4.stratacareservices1.net%252fstratacareidentityprovider%252ftrust&wa=wsignin1.0&wtrealm="
		"http%3a%2f%2fqasso.stratacareservices1.net%2fadfs%2fservices%2ftrust&wctx=4a724f8c-a0f6-4770-af93-a976c590519d&wct=2015-04-24T18%3a58%3a42Z&whr=https%3a%2f%2fqaidplt4.stratacareservices1.net%2fstratacareidentityprovider%2ftrust", 
		"Snapshot=t68.inf", 
		"Mode=HTTP", 
		ITEMDATA, 
		"Name=__LASTFOCUS", "Value=", ENDITEM, 
		"Name=__EVENTTARGET", "Value=", ENDITEM, 
		"Name=__EVENTARGUMENT", "Value=", ENDITEM, 
		"Name=__VIEWSTATE", "Value=/wEPDwUJOTMwMzk3ODUzD2QWAgIED2QWBAIBD2QWAmYPZBYEAgEPDxYCHgdWaXNpYmxlaGRkAgMPDxYEHgRUZXh0ZR8AaGRkAgMPDxYCHwEFHlByb2R1Y3QgSUQ6IDcuMDQuMDAwMS4wMTAuMjI1MmRkZAcaEuurIPkD8DtyI5VtZ066+nXN", ENDITEM, 
		"Name=__VIEWSTATEGENERATOR", "Value=DF87F02C", ENDITEM, 
		"Name=__EVENTVALIDATION", "Value=/wEdAAQMXX/EDKHmmPRBYJJoYDvNQTkB5TtQf/+Aehr2/D26WG+uVjkVj1Ilz8KW9xxPSBTOUIVBO+L1TC0ZC01HU/2AXJjHLI5RDTEnW2Js7/tC0gaF40M=", ENDITEM, 
		"Name=_login$UserName", "Value=lt_adjuster_35_1@stratacare.com", ENDITEM, 
		"Name=_login$Password", "Value=password", ENDITEM, 
		"Name=_login$LoginButton", "Value=Log In", ENDITEM, 
		LAST);

	web_submit_data("ls", 
		"Action=https://qasso.stratacareservices1.net/adfs/ls/", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://qaidplt4.stratacareservices1.net/StrataCareIdentityProvider/users/issue.aspx?wa=wsignin1.0&wtrealm=http%3a%2f%2fqasso.stratacareservices1.net%2fadfs%2fservices%2ftrust&wctx=4a724f8c-a0f6-4770-af93-a976c590519d&wct=2015-04-24T18%3a58%3a42Z&whr=https%3a%2f%2fqaidplt4.stratacareservices1.net%2fstratacareidentityprovider%2ftrust", 
		"Snapshot=t69.inf", 
		"Mode=HTTP", 
		ITEMDATA, 
		"Name=wa", "Value=wsignin1.0", ENDITEM, 
		"Name=wresult", "Value=<trust:RequestSecurityTokenResponseCollection xmlns:trust=\"http://docs.oasis-open.org/ws-sx/ws-trust/200512\"><trust:RequestSecurityTokenResponse Context=\"4a724f8c-a0f6-4770-af93-a976c590519d\"><trust:Lifetime><wsu:Created xmlns:wsu=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd\">2015-04-24T18:59:41.114Z</wsu:Created><wsu:Expires xmlns:wsu=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd\""
		">2015-04-25T08:59:41.114Z</wsu:Expires></trust:Lifetime><wsp:AppliesTo xmlns:wsp=\"http://schemas.xmlsoap.org/ws/2004/09/policy\"><wsa:EndpointReference xmlns:wsa=\"http://www.w3.org/2005/08/addressing\"><wsa:Address>http://qasso.stratacareservices1.net/adfs/services/trust</wsa:Address></wsa:EndpointReference></wsp:AppliesTo><trust:RequestedSecurityToken><xenc:EncryptedData Type=\"http://www.w3.org/2001/04/xmlenc#Element\" xmlns:xenc=\"http://www.w3.org/2001/04/xmlenc#\"><xenc:EncryptionMethod "
		"Algorithm=\"http://www.w3.org/2001/04/xmlenc#aes256-cbc\" /><KeyInfo xmlns=\"http://www.w3.org/2000/09/xmldsig#\"><e:EncryptedKey xmlns:e=\"http://www.w3.org/2001/04/xmlenc#\"><e:EncryptionMethod Algorithm=\"http://www.w3.org/2001/04/xmlenc#rsa-oaep-mgf1p\"><DigestMethod Algorithm=\"http://www.w3.org/2000/09/xmldsig#sha1\" /></e:EncryptionMethod><KeyInfo><o:SecurityTokenReference xmlns:o=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd\"><X509Data>"
		"<X509IssuerSerial><X509IssuerName>CN=GeoTrust DV SSL CA, OU=Domain Validated SSL, O=GeoTrust Inc., C=US</X509IssuerName><X509SerialNumber>185592</X509SerialNumber></X509IssuerSerial></X509Data></o:SecurityTokenReference></KeyInfo><e:CipherData><e:CipherValue>kAlGHaqTmosFyZWTFh6gTCkU6aWP/X09jkYMZP/mfmCSpMFr5qteii8sbXVaMpgJlfT5pzYNTGP/pjvO4YUURHlo6WO3tSn7+u3Py9aRWu6l044JtCDl0HIuWwMzREaNus/0xhScOdfFyCEjcWHwTT2gZDWpdvfDFJQOBSKVIZXrGJ05k+rMjmmnJvSIpWXmqTNC3q7fualF8nb/RL7/"
		"tsYf9N6yRA1YQ31YQUsCO55IhqZrv2CymlQ32tYTfTmci8kR01QdywCyNzVY8kk+wnnNnhktXcs1TXjMJKkTDW3FzC8kw9vvCIX7/qGNIIOZcjJXXiEekkP/Rm9S66nvuA==</e:CipherValue></e:CipherData></e:EncryptedKey></KeyInfo><xenc:CipherData><xenc:CipherValue>YqiYmYpyT63K6FyV0mplyfAmd73yEFgkvq6ohEwczPiUDRTdHIMAVvES4t6pJfB5IHWpKpTIXfdvxG+FCI0RiT7k5cIN7gAx3yLZkc7kASRtlwv9S7bv2lCpFpzf/1qWQi/0OxTsJn6H7TcLafUHss+kMpgjkFXAElFf6xNg9BsJ9aKu557tD6SPJiiHd8sBjbdc8rl2fGuTo0EBPX8gRC9nNVWcQKoVR1+S60EgdjQilon6Qz/"
		"stkDkAkcyZ5WZ5YS2fLlK0ow9SH8ZZKO8UyXlB+QKmHU9hDuQyuOeQfi1S1NuXPx8EcqlR5HfU95YFqOq4CTBWbq5EYpL1iZ0u5PELZtX3xPluVhB1PM5bodBOgZzDFsb6wzblZGr6uWpt+6j+8MYb9OiPtmV0wK0Tm9P3Q809+EBwFwXEifHr8ptQip15NtjdxwQCWLHuCMhbsvnzQAzohCZcSlmprSFUPVVJyx9J0xvCj6BKwtDs5uSo26OCruLDz7TKU7EXkDUuTfeBmOrnwohR2n5GMxGn7b4yRXBCe5OOJylNsGfBvQ5h30bQQAFvTxCJAdUYAblhaP76x6cSs3X3PbFmMXhtjhZJgmZRWy33crBJPYEG1QUW25Bz81kQ9O3/BistkCVP/E9C0fLXF57hKfRJgn6dUbjnJmyw5t66Uk739cmWP6wZENBVYAvmuRQk8xRzDyzvgXHl94Jo9BF+"
		"SPeeGQy36803PfYMpbzCQFJuRe0jereZ1pmjFLVdCP0u0hGl32g1qfaKAgkd2hKO+pFFI3hSTq1Wsni+ZX3zjCJhyh17e7BzXmZCn5gbwxp4qlWdX+lsTF0Dfpl/psQAVjfYimrlQLYlHQlWD4eltpWKcDNeew+HsFeEINW/LbUoHieT2W7ExZgCOVbF/XDMRV+SIrkxyilnUGjMts1hqtiO4f7ExvTfHgsKxNTtQfAJuoCXg4bticlmA46dnHK542BC+NBrsiAuPwJxh6wlPKlloVW+vw7462vUKaZZgOhnFZBQ7m0/vuS33lBPfy27o0bGmX4ur6kFO3265DpBGnllLU8/LVL4zpFK6+pmDVfzHVzuEGKc/THbhODa2Z0Rma8qGA6gm2Cb6/CDSZCPPSI06K8HmJb92VQTAsh31H/0Uboa4Iy9FsRwkuPUC1JdbuXlD1A8FDvq2aca+R3xGLDJjpnEUA5vuMfXA93wxCYNWceo/"
		"yVvmNmnpAuuqj1NWXRx9BoPXf0z+6iYkDczILn1KX075zwsZKH9fXDHifCCkjpo+gYP/t4r+NUMMkMPQcd6FtgQqRtyN+HFputNm0WAIsOYrBH7lwZ35TmxnlVCEFxEhiyv7qYoaW3XgXrTJDDH9nluN2XzNkDe8I6v9PjF0FmdhyRH5qU4fmNgDZ1j7F4lIhZ7Uu7SMObRSfigjMCmNxU1B1nWQjAeQOmLovhImzpUiRzHxAsv66jqM/3Vzo3lNKKnZnIQF+vHbSCRB3qEZ4eXZM2KbP12L59fJP0n7wxwvhhAPWBzTnI1H0bLpMp9nDS5v+AHB5rg1tj2CEDWuC21IazMfQHRO/AKp+PXNWULkcUOxjZbf4iVhKr08vz5Lvv3ocsTCFlPLC53D2uG1YrwAH6CDJ8bPeLA5TtUfMGHzkPzft1CQtSLRODEd2hpq2cMiy/ZWkAQcAuTEFhN9C6+okubhoDLGXNO3gDuBjnS2lCNdrrm+"
		"D32APH15AK8gINRHRCHEZeFSMfSI+/sppdWyGhzt/uTdecSvPXoGcJlW8iJR8MnEeogWZnyp9IHOnonTqjfs/34lOkNPX9CIEjpapvoXDyAsUwD2Ga45rK+b1tlVpIAnx9P7lVwNWZMqxH7TPSKuQE6g9XWRmCIG71x0eqefGAFbkmp4niY6vUCIJ8D9wn8SOFifpbh+w0St9LulkfB9DkM81dduYyO22pceSiUC7uT4hoN+SEaONs0VVjvo8rvNjPTT6sdDRjZvoFEGR6idUp+HAndJKFmMhJ4MUpEpnU5HKqp/tl9tQDPulCOFPR+xMKJPZ5faGjQ5RAbH9m98SE874ynCkewzkwbENKT1VGCFtLrlw1lhQwhuxeX5oveBUmCdKlbbrT7CwBafgMkgNhb5L/jLJ6yFPK6aHuwmEQn5t5VHDygjqKrCW9Mh9Y9nvy9zlkdeRwNGsQeiGE+1Vp/nWVKh3J+/"
		"8Yod8xtERYmzsuTqtzmXTOZbYREFGl9yI0hpWUeD7qZ/ofuy3iN+f+uJTM+FOqoMsigrp0DaAT84xoZM5k9LcM3NSK4jTOwLUdl4j8CSfhd7MSe7obaf7Ha4SA7/9HTloLe4IqF+syhfmDeCqj+xag7mizH+NFaqMcZSduk54c5zb2dpMA6O61UCQqjxS8/doAmX//Se2onZuRCNUdzPBBP5nYXGEm/CvxsiU4EtgSTCT3nvNVpdZuLLP6betiOWUZqrEl3HSFAA+fex9clVehvXvCUgN6B9e+HlktUN4y7v7Wun/XuWXkL28rl1roYjLOZVEIvUfaplnAVi/0tB+7BFaxyG3FsBS5YEjlfUvrT1O/0zzDoQy5e+"
		"x1mXr4Kvrcj4CJlarrk2aLsVtLA61Tbwup6DAIh3Dq1gr6zxVjPqrCnhbbOivaczvjVp5zeiP9BHtlU1H2Rk0JrBIgTPIwrHjGmnXW6vNg9HxeubvXRNfERcz9z2Lo3+VLs3yZRIIowUxsVjYmov2D237XVUkgmcw6B2RAtKpwAnMdeBQay5DhhHK2WmX7+bxe0Q8gz8ev/Z3tJTZvijIfuIfb2V6yNXEuRMwfDcEJKFnNcmPfhpXN4I2No1JlJgtIEDdM6UMIRp9calEHbdnwRaYx3KYEB8oPB2rGNp+M9mEkJJnqpUwa8dpFIZTQWnFcLhAO9ZjapnHAXjrT5ohRZUG7Vt4I/wPDabGf8KBSLnGOUxb+zRSxPhd4krekHFVnqimlAFWu2uvabcYhEl+"
		"aejAtRwzysZZazOBxil7hWm2RfZNbP2Kx2G3pNbM3JwTq3SMrvSbU5KS8tC8wL4MnJz6N3OoI6vzLY6F58nE2QXVTCqTSjuv7bVBj3HyMCz7vv7sn2ZFY+Ew/0tHMeccRFyWBQu8pWHMZ4LLsSzB7zvFI9ONacy1LPDe0cd7EcTfDQMOACS+BvEDZ/LjdAKEhm+4BRMa2Mr7fQc9/oS20cj6my257wSXEW16TECtG+ABaEJsNwj42JZ6wL6X+mdR1gt0smZYyvH2XxJ0x9sDTahsc4U0nmfCQ3skvW9YdkfU5SYRsm4A4k8Rbl2e/2sIVJ5aUXag2Uteomsgu76h74SP+PHLZmIMOqu2pt+A9QZ2g11ZjiVZ/jDqNMjmgj4bt/h8sSglqYtq8IKIfM0eips8PbmKeAkEAjoE7tblY/5Tk4Xmteu33N7Q3x4uKz4h4xJ9auIZlfju/ELw/+zCaGB0lu6oXc1gbcpX7h+"
		"QQZhA5EHrL1uz9BR0NPNwfOTx5x4Mxn9s2NSajTFBLTfR6t+K/tuEdgJK9pgEOHDlgGYv6Yuef40VIA1UU90m5M7FiXx4kLOlJBtwehDsj6GSpLqCe6HkPlxNfCWzp+uIqXrpQSUAB5QfdbYoquBQzbOw0RO42WxtE99U5hT5eL4b2Pmc0w/XrLddsDV49nwMn7cwgShi1CL+XPoVz1jWrcPtBmVGzOsfm5QDDJ4ZfMxx0yIFNSa/6vyZyTEJ+uKXJ6vWMkaFwXGBOvwLCO0IcbgAhB809rW5u5adbkEMGOpIcXXwY2E3wSvHpG8W5MXSyGcmfDSv+ExJgSHxj2XuSKLBR+ye/wFsl5An4nJIakC+ZcsbCKPGN97Q8Cyt7ykzzT4O1UL6dHmLGCdt6+eA3xmeB4wnCw+FkVQRClkqj1+S9FpHGSrzeqxWo9gk974/ToA79YExVKvxwlmsii5Q/"
		"NfvK0PgVh8TyX1fZlARpJjAt0IoCQg0rTX9yPqcobyGB0fq6901xPC8UODpC7Nl4ylQHngdaAZ5QNeCjBpIyBga69GfgwATgLUpmGcQAU6yYSe/9oKoqGmR5CBVQLwYAKet8viCUjBLB8D8WAEusWOSQuNzu5D3Iq/kcsTY2p5OTuvML9LUhn85XElMBWT4k/HCvuUz5dNgPdHMl3o/nSNVFWbsr9qKe8HxcqAKWmkMslrwGA7DgOFrZRxyq8qXRdQfycZRESXbOUYDjEOhOmhyb+A32NkfzGdut1IDS4CYxzayJrhiyfCLfOfCVgwMoHI7hubbv4ca8qlJbHfg+SUWUaytnVhMTQ6bsWY8Lxn/7bcOGDKIr+ohVLwFGsc/QPh0mb1ZF2qVr7OpVgSEr/hJ+vmfzRaG2QWWmgRDuhll0EJ1ZVXlHOS9Yf4hXPMjzIeYEoB/"
		"mF9Cwll7CF7YNaPZpCPN0TzT5qsP0PJc8MbSm54HoucI1DVr5t0xQ2IY1H/CuB9jXui9+lX5Kx89RGRuu75UoL10VKXgk+msu+Hl3jYQukdNF12sg8Tt0mKFFooy0I3eqjL7gOiPz2Kh4nN1nKnvuAn4IFQ7Rma05Q+8D5OCRNMS/JENHnMYlqPPTMnETICUXLBUIavHSqp81dT5mWckOqa0ReoCvOL7IA3qyHJJhdcxd77LTox+r5L9fbLbYeThbbet++cWlT9EJI/LAo3Nrv1UB4fZV1BDHWbPp2qW/ZolYgiUtq+7+tYccZvfCk11NqmX3/6KGDzORoyOXn8mrgOA14utR</xenc:CipherValue></xenc:CipherData></xenc:EncryptedData></trust:RequestedSecurityToken><trust:RequestedAttachedReference><o:SecurityTokenReference k"
		":TokenType=\"http://docs.oasis-open.org/wss/oasis-wss-saml-token-profile-1.1#SAMLV1.1\" xmlns:k=\"http://docs.oasis-open.org/wss/oasis-wss-wssecurity-secext-1.1.xsd\" xmlns:o=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd\"><o:KeyIdentifier ValueType=\"http://docs.oasis-open.org/wss/oasis-wss-saml-token-profile-1.0#SAMLAssertionID\">_5c9d88b7-9f25-4a97-90cf-76e943f8931d</o:KeyIdentifier></o:SecurityTokenReference></trust:RequestedAttachedReference><trust"
		":RequestedUnattachedReference><o:SecurityTokenReference k:TokenType=\"http://docs.oasis-open.org/wss/oasis-wss-saml-token-profile-1.1#SAMLV1.1\" xmlns:k=\"http://docs.oasis-open.org/wss/oasis-wss-wssecurity-secext-1.1.xsd\" xmlns:o=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd\"><o:KeyIdentifier ValueType=\"http://docs.oasis-open.org/wss/oasis-wss-saml-token-profile-1.0#SAMLAssertionID\">_5c9d88b7-9f25-4a97-90cf-76e943f8931d</o:KeyIdentifier></o"
		":SecurityTokenReference></trust:RequestedUnattachedReference><trust:TokenType>urn:oasis:names:tc:SAML:1.0:assertion</trust:TokenType><trust:RequestType>http://docs.oasis-open.org/ws-sx/ws-trust/200512/Issue</trust:RequestType><trust:KeyType>http://docs.oasis-open.org/ws-sx/ws-trust/200512/Bearer</trust:KeyType></trust:RequestSecurityTokenResponse></trust:RequestSecurityTokenResponseCollection>", ENDITEM, 
		"Name=wctx", "Value=4a724f8c-a0f6-4770-af93-a976c590519d", ENDITEM, 
		LAST);

	web_submit_data("default.aspx_2", 
		"Action=https://lt4-cmi.stratacare.net/LT4-CMI/default.aspx", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://qasso.stratacareservices1.net/adfs/ls/", 
		"Snapshot=t70.inf", 
		"Mode=HTTP", 
		ITEMDATA, 
		"Name=wa", "Value=wsignin1.0", ENDITEM, 
		"Name=wresult", "Value=<t:RequestSecurityTokenResponse xmlns:t=\"http://schemas.xmlsoap.org/ws/2005/02/trust\"><t:Lifetime><wsu:Created xmlns:wsu=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd\">2015-04-24T18:59:41.998Z</wsu:Created><wsu:Expires xmlns:wsu=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd\">2015-04-24T20:39:41.998Z</wsu:Expires></t:Lifetime><wsp:AppliesTo xmlns:wsp=\"http://schemas.xmlsoap.org/ws/2004/09/"
		"policy\"><wsa:EndpointReference xmlns:wsa=\"http://www.w3.org/2005/08/addressing\"><wsa:Address>https://lt4-cmi.stratacare.net/LT4-CMI/</wsa:Address></wsa:EndpointReference></wsp:AppliesTo><t:RequestedSecurityToken><xenc:EncryptedData Type=\"http://www.w3.org/2001/04/xmlenc#Element\" xmlns:xenc=\"http://www.w3.org/2001/04/xmlenc#\"><xenc:EncryptionMethod Algorithm=\"http://www.w3.org/2001/04/xmlenc#aes256-cbc\" /><KeyInfo xmlns=\"http://www.w3.org/2000/09/xmldsig#\"><e:EncryptedKey xmlns:e=\"http:"
		"//www.w3.org/2001/04/xmlenc#\"><e:EncryptionMethod Algorithm=\"http://www.w3.org/2001/04/xmlenc#rsa-oaep-mgf1p\"><DigestMethod Algorithm=\"http://www.w3.org/2000/09/xmldsig#sha1\" /></e:EncryptionMethod><KeyInfo><o:SecurityTokenReference xmlns:o=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd\"><X509Data><X509IssuerSerial><X509IssuerName>CN=GeoTrust SSL CA, O=\"GeoTrust, Inc.\", C=US</X509IssuerName><X509SerialNumber>74338</X509SerialNumber></X509IssuerSerial></"
		"X509Data></o:SecurityTokenReference></KeyInfo><e:CipherData><e:CipherValue>SJZ96o/uTN0c9amHAr+sdE2a180n4mzNugWxS5Sc430zgn3EiEbVnlIJLea1AG29/GmOp/maVnQMh86OPZ08XfUvOcHDG/jI01zbv0liFC4JMtXsmmYDq81JYdPdWrBA5Q5bB0XHQFFiHvBWCBg6ZLBffHITQYHjfNmI8IrhleJEUNHEO+v1t9ZUahMo7X1q/R0/SAedo1b+25hlAzreXO4s4c6MW0cIF3kGeUgRCEhRQTchyR1sJooHF0qq1NHTU/VvXIPpBIHNntnJoR9btac4IL6dP3r6O5Y+WrXNdwxKj974tBOPkWOsAjvTcq1G/fVKr6+1u1dDeWp54BXTww==</e:CipherValue></e:CipherData></e:EncryptedKey></KeyInfo><xenc:CipherData><xenc"
		":CipherValue>w2VV1SJb1dr+T4UhsHZdqzPeY8evw7FzQI3hVXu8YMstxeDtvfri6ESYusWwp5NBbWfrdO5IWIPb88uRLyX+83zRKtL9+nhaJ3dqrnGSX9MMqFcIylFf4v3vH6OH9oTs5KeDyFBwC03EkkllQCVnIb5dFW4Q2Ov7u3DfaJ/FqCP34CgEElTBM/fHWyOX+EWsWw5HcZQEdXgxmq4LxtRzTOcjxv7LIVC0hoCnN728h4z/uqPLvSzZg4/L5zoe+p6RHJwtvy2ccg1R7f6jH4AY1B95p6MUtX/jJ5WTo1s4OO53XDxKNZrtnayg84sRhmv48jrcTd6iMemZ1tJvx0HH6BMMF6AQCttbLPtuj/gERWAfJh+H8dwTmMzJVZSh3kv2/MmfR/EPXWTGBca9DN+ECskbuSKwCRNYXgwWmjAyLzSUT8SPOLRmwDqZ/hth+8sRBfj/"
		"JRSbvaX1olHrBhS8E542QLLJLtuMulK1YPSIGagjuOxqviV7BHxRaMtNaw+6+IRfuAJT6iFbKXI0GtFAvhwFQHqU2/sFRv9ybJSG6gtmxqSXTnlYxHhToJ89c/ahtk2zHKF/bRihPSKGbRKPe5ARXqRmbh03kqZhMKNeewU9eXB86+sjk13e33qh1iIfyJKpXF+pjfTI4i+L5+xKOo45QA6Xo3S5bCqN+fyVkX6/pstLvjgLjKfkvE4o4g/LoIV0gSqjpPTK5lStCt3tNJ2BH2LUhntcgdOwKJbKvjtswHDzz8EzDttIX4T1UMfPOF/cHmBvoWykRQoZdOA/V3XSHO0CgMbUpZhNLlmpvp49xv2/80iMNndUk1l/vD0itKd00xW/2lgp1DaGRAjrzdGZHtUWHPLXsNnm7/NyEv/A8eaD9jWViKESe9dG3VnyfgrQDFvgiS2u6nsTwXCwPZVVmZXmGa7xlx/TNcg9CBVwE8Dcn4qvE9r+"
		"97h3qKQvMtQ680ciA62xHji6wIxcrKrzVMwc35VgW6aNUIih+B7k53bpstxXWEs4kY4nY4Wuwdg6oCTMtLbla9qQ3qw5LmVYdbi2bB814dnMx21PUX+5KEDaqfg0MxhjCiMaWh2ClWoxxLBmGWAURvtAn2MnwwbdxcUE5eqfJE33SEsD1yQOphunho9qyXZDU2O+1+lW1hLfhwxSGX/JHS8ZD+JEXYDX0MFlvtklZbc+vpBHsh66+l31XoIqnWsyMKyZyMHQg4qKrmQBwX1jnxLQs61/u+KWHv9JiWe2wFKQiqHoRFI5KeE+tftDNRN33tavrKVv38riR5LHRvvoR4vkS3D20oj0mQ0uRhYX0VvhsVSDAwYc9g4rM4rVHvnQ2NjGVa5ZtnTusd3vupWfH/IumjHkToEvO/XZy7YCf0chzSEaQ7BbjZuby6OWFQDrSZa9pZO8UdbBOlolIGzvVSEHPPpxHiEoHNgZ6aigZlXD7/"
		"sDOYefnoaNdv5qx8DZQnkse+Rm4Gr9SMfzUOOy9CxdIeJLIt5rGlEH7D0kww8ftoszLCFRLzMtVZKbNdatD5ZXeWRAtUpDFsxT2tzN/qWUc8IhC/BLZKEXMs2bl4X3ejOPZ0aURHAF39kKC5Be7FDHAEbuDON58BPzMq79gBlgphMKky4MOW6ij4qdiU3zxW4c27RyB6AL2B6JKhPQhcMIMz0W0P7FOD4QbwCT8IY1j2/Kq7HrE+O4rolSJiBPfY0IvCLnRRqbqWnqS74GJuAStEJ8KanH7o+j33w3SVUhUaVuCwyf/+KsfXjI12H367Y/RoR9MvTj5h1qaIo0wyeUj62iKfGMRSfrw0Aq3aNoR0ziJwOi81ChuPbmK7zSghiTnXyaP/nuDrhbIhHRcjt8NU4jOa8C1Aj08OuLNjj64pBA7IxeErRyma8GAPQdUJCKe9M7UnG5WX9RfbvyUG65cfyn63va7GDFpPu/v/"
		"XRAgnlddioa20iHy9m7j53oOeu4/qDWGW0MARIdYIYjnPxyMPJn0xcQ5ZwFlnLQz6scDhhbdUPrG/kwRTSoELDlAE3ALheZaPf9BMWcD2LN37nYQg1GzCFsdhoj02GM9dLYRCFZYR14R3bK3hPwD07f4fszjcLjIEvApN79Ias6/ZGNCtpaK5/lDbeHXIjNTPFMKEHb6EKSFpYIWIlGJbNnodeRnwt2Pn19B0m1rxSQq4I8Bd9S6CtJW4EIruQsf9AcmMjP8njj5bmmynzPuPS7GPpG7mzE4BfODleWIEjBv8Ppaap9DgAbOIVhf/wmlDrsi+UsCoJLfWbxHMA4z8ejqivxcTWslldSKirCJkTQYpn+u6WOVTP0tRZgY4A8DAFofih59/rU8ButaFiPWtcm+WMl5EZo2HkNxbhW9kDFYn/iTrsluuQAA26jq0kRdh/VmySZ6NPXDqWosEFhfPgb6nqDt+"
		"DQvqQBtuSsgdYan5mSIDAT9WBgvvn+jJo/F5yHTV23XzwaYTZwOIXyDerjx9fCLeWkwSRCCd3i2YS7+Btl8YIkY+e3DM4t+TUieOuUiafJc7PPTl5l2qJSmKejGSHVfsciD7jM46zSIFcTN6kLk/DLPortPT9ZIE3PZE+Ov96cDzAjIxDScliBZZ+FUo5sx3wiFhL0ja1qP3FD6g28t7HYkj+AT7YGehmQ3yqA9GFaIs6J2e4ZBETIMWH/kBb4SC2qOH266Mr8LWsk+JZadZjbYNt5qi3lM7BDUzGDYC6LUfJzxpU1de2d7KYJk+Gk2DA3TAm7sCX23cBP5xprv8TqEfYsLzs+DwTw3pYllRPazM11K9RYIaBKgmLDrmHVe/eaUrloRwNO8NMCmrFy4vHLlpUh2vTiVxXTjWguRqoXApThrE6YG3SKZDuTQq1FOQaLXZ/GY9NU+DVsV+"
		"pigMwFvzIfJOHg47AJY7XXh1Pk7A0MJ4kfhsFnVtFgzZEWwtkPqnuuBMELmzstje9ao+85cJPrDNm5/deXRd04pj7OPWqu9FwHwpQz1LtIODplbZ+4ER0ew9M+owRLTXwqqkt8b56JTxaGNis8Wm+tziQOjC5KztTxCHp9XlHwY/GFbV3++eUdlHx2XG7di7CKjQG5ZFh/MkvHyFv8V958ORl9UibbCeSMi4D8XpPCrL3PSV1NxJZbbkL63/KD+g2Nob+Wk/23TGY8M+WaIj8CvR9XxY2mrC7vnATcbkBxCYq9awsFega1WUJRcIJl4MyUtZ3VpMjoxeTmsAPs+7AUy97ngJ5U7lwf4PvVW6dwy4M1t0wLsNzoV71lG4Dq9FqYNbIV8xUc5otQ7OXwUVRbcEnKkm7aI6M6dHDNT9HpKzBqu20hDNpXIp7LGkWmmB2Exzf3x/w+"
		"6Bm3SzOUadUSUOLhaFbUzHIHDhlLNUzZKOrTVTtPelbIsZ1s7jDE91hyItG1IJZB3hbZqGSn6Z6Rg5lM9e61YmqdzGkQF45Hzwn2cUyrcnUs4HntGXBWy23X3IVVNZlTJqtbepDzBBBzjNXFTPN5EIrhoSsGnsmNpCWnILVvPJXv28PXd+x1oGTvy9IAtNv/OVGs8TlYJG/2BxED7fXaTUR/X6M6CpYV3z2uiqFblNEeXMKZlYKKz5XiXWWGFegG9vs9xbtneBGTZXz7NuJsbswLi8ZoPtIpJ1XwctkyILIVFHO0cMu9Al1EkIEkuKXIAyFuwVy5vH+cUBVBmKu8qmcE7qIS8duHUHv2wPl2yDatnCZ6SSH7+OJHxahy6J68rWsMMGNja3eQNISYOwGTC37tC2oZNkfiNecLy1/u8pNm/bmvdbNxr/id7k5GHyjs6pA3tHJye1auIXfy316ASpWCqX0hdpVsA+bZLV382c+"
		"bk9ZWmwuql2q8CzA1NGfmED7Dy2mI8G4fWimoLt/s8wui6MaWIBWa8keFh8p0MggGNt/HDaxfJDmcKmN5cYTGRnJpNhOq8vPbWNHJlssXpiItwgM7vcIe6/a/ztumkjJFam3jqGgog4ga0mA31uA+Odb5JHh7A+CDcWVVEvXK1NQ1HtJBrd3y1Zxb/37hHL4owJ1370uQg2+ZZeT84zRGpDv+XAFmYZ3tXT2qCnzicwPh267s0FS1L92Zs8i1qsvJKeL8MxwR0EJU+N4nEfYWW6lQrSXMHw9Ap1MSpbKfusbx7eyl46l9LCLi/vshrAgZuDF072D9EiL68n3uv56F2Eriti9pLMKiU6m/ONLpszOqPxGZ6l9aacaI02WOQxaMxxp36zrs+gKIAZYeGfZV7P0xpBtfLxbt+gX6hIWIUIRi1VkvpnhtE5sXUIxnBAOFtQsZ8ftkWhpL3bKU+9xD6yErvv7dhzcqvbA0o1iGo2IcJ+cYfA8AJ"
		"/1M/7+qM7x2F5C7Tjbe1c/XNJK+0+MyBIST8m2RzBz/r3a2mqmzmawTWGj2WeTWL9JKOcTMUIRaf6x4ieNmdQVQdAas/fWg14DzWGrhLaWD1z2yw2xbuOnepuYMsArAzYVrGMsFpZc9IUeTo4tspQlRoT0FlNGmX/LBQ8QHtsJ6f36F/8cQYU6EKox898gnzb4qvxFoHhU41A0BZkzTFHIZcL2hUa4oLDLFHPqtcggNSlemoDPIbmsHJ/A1LS+BruYfxTTh1HJgIoXCdwNU5AezsegvJgPyTe9JTmBmUOQZ/gewI4WAL6C/BusVHa4p5tSTkZ0oYyfiah6vupY+1olSfQCAoE0cKMBwsRHxIVq3seJaKzJHVfDb81SBMbpo5vPf8s++"
		"KcaTwBvuaQPPBDDTJyBiC5hpPJHp5asDfXhN2x3UI1RpLsqz6uo56rnqLMm0YXCcGNnXCAXCnwmYVBNT63ghCiEdOYLzZNeQyE0NmvWT9GT10fVxXMpl5pGmy9DCPE7sutHQp+YrsrN+7ULsVdjT6c7PRFPzRG04Gcc0tjhnnLpoqTqmzTzEI2YD6zA9QVvpJ6IJp1agIUVnKJZjVImjTr6DLYik1ZxVMUK+DKjCf32AhogXxfxNBc37OsG8SjfRfE+aI/GaISFWbGuS6UefWLXXHQPUpAgYN6XbeVJtbEDrzl+Ax7rMLxDnQGjMUceP9ULekJwJCb5yTZCrj/YmlommgZt73z0Ugc+VH7PEj6mZLIr/hWmA640NQFML3FZNAoSu2j/NRB6QD0YItrDedi3xZlxfN3nIS4LSpK7MY8IOa8ZL4Ki6i8uB1gafWhnFr6tEIT1eWyfPgrYTkElgNE0Qq9kP7RtdSSSNJyKpyCoJk/"
		"prnRfM2W7UTJiEDPxlBbIIxk4xYp8XfDCM7DeCpocic1A0cJgxbh+FrvpZOI3azmeFwxrzN1kcFia+V/6IboGxLxXkg0j+K70xhLbO3G42jl+f81K1knMZSIXta5aRaJqme2HqsnfsW0f151co1Gm4U3kUeLsLQPyeXF6Bw4PoUQpEPuoBvUVlD2a43fUOG7r+R5miCV6u+UXiupC0kO/TmCjWIyyenT6Gtxb5d+6VxVV+5m9JIYTp28e02YnaSaaxhPIt4CPT/M2dXzVlxmNnLHiuavFfVlZjOEmiy6G0wjlnPEShARYwt+RwaBRNkz5zxk2boda6E0i+SdmIlxkb8RxCx/n9ppMkdt8AQd8XZta9/5m9T0DD/6MguwPxWzoZW78JvNLVqCX6IjrYhIqfpNuJMnrKjD5VqjAiBvfmStJqeEZCH5RrFGkf/"
		"rh6U00a8r6zbVoj3Yfen6ktcYwSjl54UqWlxFcZIcH4vEdaS92eBgrzt6vrmX+aAVyKPkIkBKkTpKdLiOyODMu+QrTs6M119zEJmRJoWPwU+fgfrV4hnnEu2PPNBVgPLwOsRo67QoZ2akaPiItNHJQ0F6CLH6UWoEDCUb+d40EY3quFNbTFVN8cJXptGQnzha4XTbWSPexAjHBGBeA1QyihxAEkgmMkdlA2waELAyUXiUffN6YxarzpXf1CVfjimpbHTkDFd8rpDh4sLqt8InLSgNgKL3B+Q/MNYY3bi9uzgTf8RVdeFxwB4Mgjc4iJ2kehgznI/BwjfXenXKojNEeix9e52xsowZsmFXRGvSNZDHNbrhfzpgM3GC6aSnPVlu3D1uDct4Efu3nFW2L4J6dWGbE9eFlzENvPGzQKLqSGV7fz2bcGhVXRHdQYMPTkOekQ2w2hoXRy0+"
		"h3WUv1vmqTZoY4PBzwhwwm0r4Ddady0A0U4tO2J89lu51zRpuoSe3Tt8t2JLtbN0Fs+ghvS4ujGvlNdK3mrzc/hSMEHkLTlXhGzRtEhVovLLiYylmz1LBGnKRipe+CB45+S+M5rrhV2GZga4OgLrnexzeZwjSNchlcUi/N7Diw2AgFFPO17vQRkUqIOTsns5UpPK/AQ7Tu9nepmyCaSk6jdlcCXMAs6XngG3L30r3b+Gj97GUTBqE96FTs0hp2GC7BL+DTnHPpPo1z4Nq3+C/PmnzPwmOvpvz/w2d6gZDf8VOVNKSs2uFD74NPd8NcoSs3rcz43b+7cgzsuF2T1MQ5aGswc7RVLxeXJgJ0aCBzs5fdyoIddVjmFVxkY7t1hZlqRFkGOF/P2/uieqBfSD6xV8aN1J8fLa6tGkNw66iCz77QwwePaGVYQJZZzOj5nGb7f+q+s9GIrWoS3oboR6ixQu5BpK/r3WFoZx82IXWjAHjipx/DtU+"
		"RTkm+lLLGdNOYV9exc8Q5mWGeXmdkZE9paT5aEr3T5TxC3SXH3IV5nwKJDxZ8pMgnEqMIu6szUpUUHE2tdg5IUNFiPiS8DOqbMDOpLeOgx/RFwRyg5oc9d1TiFNsLOGh4ZzxrJnqvyGHQbJ+l2IKoIfTkf/4hzKmcq7ZxMXATmadqToYHPzR+kx6T3fC8TI37O2in5h2MM+7NjGEEqRUj7GUSRuzOjN4tAh10UwDjLm9Squa3heouKd471nm62rHjq2SrqepJJ2HyMax+x0=</xenc:CipherValue></xenc:CipherData></xenc:EncryptedData></t:RequestedSecurityToken><t:TokenType>urn:oasis:names:tc:SAML:1.0:assertion</t:TokenType><t:RequestType>http://schemas.xmlsoap.org/ws/2005/02/trust/Issue</t"
		":RequestType><t:KeyType>http://schemas.xmlsoap.org/ws/2005/05/identity/NoProofKey</t:KeyType></t:RequestSecurityTokenResponse>", ENDITEM, 
		"Name=wctx", "Value=rm=0&id=passive&ru=%2fLT4-CMI%2fdefault.aspx", ENDITEM, 
		LAST);

	web_concurrent_start(NULL);

	web_url("Treeview.js", 
		"URL=https://lt4-cmi.stratacare.net/LT4-CMI/Scripts/Treeview.js", 
		"Resource=1", 
		"RecContentType=application/x-javascript", 
		"Referer=https://lt4-cmi.stratacare.net/LT4-CMI/default.aspx", 
		"Snapshot=t71.inf", 
		LAST);

	web_url("AJAXCommon.js", 
		"URL=https://lt4-cmi.stratacare.net/LT4-CMI/StrataWare/Common/AJAX/AJAXCommon.js", 
		"Resource=1", 
		"RecContentType=application/x-javascript", 
		"Referer=https://lt4-cmi.stratacare.net/LT4-CMI/default.aspx", 
		"Snapshot=t72.inf", 
		LAST);

	web_url("StrataCarePortalHeadScripts.js", 
		"URL=https://lt4-cmi.stratacare.net/LT4-CMI/Scripts/StrataCarePortalHeadScripts.js", 
		"Resource=1", 
		"RecContentType=application/x-javascript", 
		"Referer=https://lt4-cmi.stratacare.net/LT4-CMI/default.aspx", 
		"Snapshot=t73.inf", 
		LAST);

	web_url("jquery-ui-1.8.10.custom.min.js", 
		"URL=https://lt4-cmi.stratacare.net/LT4-CMI/Scripts/jquery/jquery-ui-1.8.10.custom.min.js", 
		"Resource=1", 
		"RecContentType=application/x-javascript", 
		"Referer=https://lt4-cmi.stratacare.net/LT4-CMI/default.aspx", 
		"Snapshot=t74.inf", 
		LAST);

	web_url("heartbeat.js", 
		"URL=https://lt4-cmi.stratacare.net/LT4-CMI/Scripts/heartbeat.js", 
		"Resource=1", 
		"RecContentType=application/x-javascript", 
		"Referer=https://lt4-cmi.stratacare.net/LT4-CMI/default.aspx", 
		"Snapshot=t75.inf", 
		LAST);

	web_url("jquery-1.4.4.min.js", 
		"URL=https://lt4-cmi.stratacare.net/LT4-CMI/Scripts/jquery/jquery-1.4.4.min.js", 
		"Resource=1", 
		"RecContentType=application/x-javascript", 
		"Referer=https://lt4-cmi.stratacare.net/LT4-CMI/default.aspx", 
		"Snapshot=t76.inf", 
		LAST);

	web_url("jquery.treeview.css", 
		"URL=https://lt4-cmi.stratacare.net/LT4-CMI/App_Themes/Default/jquery.treeview.css", 
		"Resource=1", 
		"RecContentType=text/css", 
		"Referer=https://lt4-cmi.stratacare.net/LT4-CMI/default.aspx", 
		"Snapshot=t77.inf", 
		LAST);

	web_url("jquery-ui-1.8.16.custom.css", 
		"URL=https://lt4-cmi.stratacare.net/LT4-CMI/App_Themes/Default/jquery-ui-1.8.16.custom.css", 
		"Resource=1", 
		"RecContentType=text/css", 
		"Referer=https://lt4-cmi.stratacare.net/LT4-CMI/default.aspx", 
		"Snapshot=t78.inf", 
		LAST);

	web_url("TreeView.css", 
		"URL=https://lt4-cmi.stratacare.net/LT4-CMI/App_Themes/Default/TreeView.css", 
		"Resource=1", 
		"RecContentType=text/css", 
		"Referer=https://lt4-cmi.stratacare.net/LT4-CMI/default.aspx", 
		"Snapshot=t79.inf", 
		LAST);

	web_url("StyleSheet.css_2", 
		"URL=https://lt4-cmi.stratacare.net/LT4-CMI/App_Themes/Default/StyleSheet.css", 
		"Resource=1", 
		"RecContentType=text/css", 
		"Referer=https://lt4-cmi.stratacare.net/LT4-CMI/default.aspx", 
		"Snapshot=t80.inf", 
		LAST);

	web_url("global.js", 
		"URL=https://lt4-cmi.stratacare.net/LT4-CMI/Scripts/global.js", 
		"Resource=1", 
		"RecContentType=application/x-javascript", 
		"Referer=https://lt4-cmi.stratacare.net/LT4-CMI/default.aspx", 
		"Snapshot=t81.inf", 
		LAST);

	web_url("jquery.blockUI.js", 
		"URL=https://lt4-cmi.stratacare.net/LT4-CMI/Scripts/jquery/jquery.blockUI.js", 
		"Resource=1", 
		"RecContentType=application/x-javascript", 
		"Referer=https://lt4-cmi.stratacare.net/LT4-CMI/default.aspx", 
		"Snapshot=t82.inf", 
		LAST);

	web_url("spinner.gif", 
		"URL=https://lt4-cmi.stratacare.net/LT4-CMI/StrataWare/Images/spinner.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=https://lt4-cmi.stratacare.net/LT4-CMI/default.aspx", 
		"Snapshot=t96.inf", 
		LAST);

	web_url("close.gif", 
		"URL=https://lt4-cmi.stratacare.net/LT4-CMI/App_Themes/Default/close.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=https://lt4-cmi.stratacare.net/LT4-CMI/default.aspx", 
		"Snapshot=t110.inf", 
		LAST);

	web_concurrent_end(NULL);

	web_concurrent_start(NULL);

	web_url("ScriptResource.axd", 
		"URL=https://lt4-cmi.stratacare.net/LT4-CMI/ScriptResource.axd?d=qoinGJuBo2HAeW9E_SNKGok2KMfuVwttU0_XACw6Q0OvVVV8CEZ5Uw6go4Y5MccErB611t7TECTKKU1H-w1iL8CZCmbjjkeND759b10He9ZpDj6y5x1GWnTCKL4kTQDuI8-iZzYCaNFGVwMplZcoAIqibis1&t=42a7acab", 
		"Resource=1", 
		"RecContentType=application/x-javascript", 
		"Referer=https://lt4-cmi.stratacare.net/LT4-CMI/default.aspx", 
		"Snapshot=t83.inf", 
		LAST);

	web_url("WebResource.axd_4", 
		"URL=https://lt4-cmi.stratacare.net/LT4-CMI/WebResource.axd?d=odcXXG8e8l0dhtmVSGjjcVLNyuwuB33eLZHP79Dqj7ZU8mQ7oWRYkihMDIwNR86bQZ5tPC8QFtZpU9xAddStoXT91a81&t=635328527960000000", 
		"Resource=1", 
		"RecContentType=application/x-javascript", 
		"Referer=https://lt4-cmi.stratacare.net/LT4-CMI/default.aspx", 
		"Snapshot=t84.inf", 
		LAST);

	web_url("WebResource.axd_5", 
		"URL=https://lt4-cmi.stratacare.net/LT4-CMI/WebResource.axd?d=dJbx8kTcsvYEBhrUnqMXUS9hN9gbbxWbuCqtCZaicRJzGnox-1F79d45IxdGgJzLY_HFl3VP_lriIm1oWYPERGo1DrY1&t=635328527960000000", 
		"Resource=1", 
		"RecContentType=application/x-javascript", 
		"Referer=https://lt4-cmi.stratacare.net/LT4-CMI/default.aspx", 
		"Snapshot=t85.inf", 
		LAST);

	web_url("js", 
		"URL=https://lt4-cmi.stratacare.net/LT4-CMI/WebServices/ProxyAsync.asmx/js", 
		"Resource=1", 
		"RecContentType=application/x-javascript", 
		"Referer=https://lt4-cmi.stratacare.net/LT4-CMI/default.aspx", 
		"Snapshot=t86.inf", 
		LAST);

	web_url("StrataCarePortal.js", 
		"URL=https://lt4-cmi.stratacare.net/LT4-CMI/Scripts/StrataCarePortal.js", 
		"Resource=1", 
		"RecContentType=application/x-javascript", 
		"Referer=https://lt4-cmi.stratacare.net/LT4-CMI/default.aspx", 
		"Snapshot=t87.inf", 
		LAST);

	web_url("StrataCarePortalImageViewer.js", 
		"URL=https://lt4-cmi.stratacare.net/LT4-CMI/Scripts/StrataCarePortalImageViewer.js", 
		"Resource=1", 
		"RecContentType=application/x-javascript", 
		"Referer=https://lt4-cmi.stratacare.net/LT4-CMI/default.aspx", 
		"Snapshot=t88.inf", 
		LAST);

	web_url("StrataCarePortalSearch.js", 
		"URL=https://lt4-cmi.stratacare.net/LT4-CMI/Scripts/StrataCarePortalSearch.js", 
		"Resource=1", 
		"RecContentType=application/x-javascript", 
		"Referer=https://lt4-cmi.stratacare.net/LT4-CMI/default.aspx", 
		"Snapshot=t89.inf", 
		LAST);

	web_url("HeaderBack.jpg_2", 
		"URL=https://lt4-cmi.stratacare.net/LT4-CMI/App_Themes/Default/HeaderBack.jpg", 
		"Resource=1", 
		"RecContentType=image/jpeg", 
		"Referer=https://lt4-cmi.stratacare.net/LT4-CMI/default.aspx", 
		"Snapshot=t90.inf", 
		LAST);

	web_url("WidgetCommon.js", 
		"URL=https://lt4-cmi.stratacare.net/LT4-CMI/Scripts/WidgetCommon.js", 
		"Resource=1", 
		"RecContentType=application/x-javascript", 
		"Referer=https://lt4-cmi.stratacare.net/LT4-CMI/default.aspx", 
		"Snapshot=t91.inf", 
		LAST);

	web_url("fader.js", 
		"URL=https://lt4-cmi.stratacare.net/LT4-CMI/Scripts/fader.js", 
		"Resource=1", 
		"RecContentType=application/x-javascript", 
		"Referer=https://lt4-cmi.stratacare.net/LT4-CMI/default.aspx", 
		"Snapshot=t92.inf", 
		LAST);

	web_url("ScriptResource.axd_2", 
		"URL=https://lt4-cmi.stratacare.net/LT4-CMI/ScriptResource.axd?d=pYjKwjlIYNOiGfjnCorqneiF3fUPQOUrjYDRESxZ_gFaobTaX2CSUw9CnbDgZpm1HeEYY3-l4wqorZhj-JpunoIz8uFBw84MutixqsCWEGpPaQIEs-PsX6bp9PzUW0WxtpwB--TYjObz4CTTx7M9oLh7gBC_p55qf_VSOawkrHusMxfA0&t=42a7acab", 
		"Resource=1", 
		"RecContentType=application/x-javascript", 
		"Referer=https://lt4-cmi.stratacare.net/LT4-CMI/default.aspx", 
		"Snapshot=t93.inf", 
		LAST);

	web_url("js_2", 
		"URL=https://lt4-cmi.stratacare.net/LT4-CMI/WebServices/WidgetService.asmx/js", 
		"Resource=1", 
		"RecContentType=application/x-javascript", 
		"Referer=https://lt4-cmi.stratacare.net/LT4-CMI/default.aspx", 
		"Snapshot=t94.inf", 
		LAST);

	web_url("strataware_portal_logo.gif_2", 
		"URL=https://lt4-cmi.stratacare.net/LT4-CMI/images/strataware_portal_logo.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=https://lt4-cmi.stratacare.net/LT4-CMI/default.aspx", 
		"Snapshot=t95.inf", 
		LAST);

	web_concurrent_end(NULL);

	web_concurrent_start(NULL);

	web_url("bg-menu-main.jpg", 
		"URL=https://lt4-cmi.stratacare.net/LT4-CMI/App_Themes/Default/images/bg-menu-main.jpg", 
		"Resource=1", 
		"RecContentType=image/jpeg", 
		"Referer=https://lt4-cmi.stratacare.net/LT4-CMI/default.aspx", 
		"Snapshot=t97.inf", 
		LAST);

	web_url("edit.jpg", 
		"URL=https://lt4-cmi.stratacare.net/LT4-CMI/images/edit.jpg", 
		"Resource=1", 
		"RecContentType=image/jpeg", 
		"Referer=https://lt4-cmi.stratacare.net/LT4-CMI/default.aspx", 
		"Snapshot=t98.inf", 
		LAST);

	web_url("EOR.jpg", 
		"URL=https://lt4-cmi.stratacare.net/LT4-CMI/images/EOR.jpg", 
		"Resource=1", 
		"RecContentType=image/jpeg", 
		"Referer=https://lt4-cmi.stratacare.net/LT4-CMI/default.aspx", 
		"Snapshot=t99.inf", 
		LAST);

	web_url("button_bg_grey.gif", 
		"URL=https://lt4-cmi.stratacare.net/LT4-CMI/App_Themes/Default/Images/button_bg_grey.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=https://lt4-cmi.stratacare.net/LT4-CMI/default.aspx", 
		"Snapshot=t100.inf", 
		LAST);

	web_url("expand_blue.jpg", 
		"URL=https://lt4-cmi.stratacare.net/LT4-CMI/app_themes/sigmundseamonster/images/expand_blue.jpg", 
		"Resource=1", 
		"RecContentType=image/jpeg", 
		"Referer=https://lt4-cmi.stratacare.net/LT4-CMI/default.aspx", 
		"Snapshot=t101.inf", 
		LAST);

	web_url("ico_claim_history_w15h15.gif", 
		"URL=https://lt4-cmi.stratacare.net/LT4-CMI/StrataWare/Images/ico_claim_history_w15h15.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=https://lt4-cmi.stratacare.net/LT4-CMI/default.aspx", 
		"Snapshot=t102.inf", 
		LAST);

	web_url("ViewExceptions.jpg", 
		"URL=https://lt4-cmi.stratacare.net/LT4-CMI/images/ViewExceptions.jpg", 
		"Resource=1", 
		"RecContentType=image/jpeg", 
		"Referer=https://lt4-cmi.stratacare.net/LT4-CMI/default.aspx", 
		"Snapshot=t103.inf", 
		LAST);

	web_url("icn_note_red_w12h14.gif", 
		"URL=https://lt4-cmi.stratacare.net/LT4-CMI/Strataware/Images/icn_note_red_w12h14.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=https://lt4-cmi.stratacare.net/LT4-CMI/default.aspx", 
		"Snapshot=t104.inf", 
		LAST);

	web_url("pager_nextpg.gif", 
		"URL=https://lt4-cmi.stratacare.net/LT4-CMI/images/pager_nextpg.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=https://lt4-cmi.stratacare.net/LT4-CMI/default.aspx", 
		"Snapshot=t105.inf", 
		LAST);

	web_url("pager_lastpg.gif", 
		"URL=https://lt4-cmi.stratacare.net/LT4-CMI/images/pager_lastpg.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=https://lt4-cmi.stratacare.net/LT4-CMI/default.aspx", 
		"Snapshot=t106.inf", 
		LAST);

	web_url("icn_note_true_w12h14.gif", 
		"URL=https://lt4-cmi.stratacare.net/LT4-CMI/Strataware/Images/icn_note_true_w12h14.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=https://lt4-cmi.stratacare.net/LT4-CMI/default.aspx", 
		"Snapshot=t107.inf", 
		LAST);

	web_url("icn_Billnotes_true_w12h14.gif", 
		"URL=https://lt4-cmi.stratacare.net/LT4-CMI/Strataware/Images/icn_Billnotes_true_w12h14.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=https://lt4-cmi.stratacare.net/LT4-CMI/default.aspx", 
		"Snapshot=t108.inf", 
		LAST);

	web_url("pager_firstpg.gif", 
		"URL=https://lt4-cmi.stratacare.net/LT4-CMI/images/pager_firstpg.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=https://lt4-cmi.stratacare.net/LT4-CMI/default.aspx", 
		"Snapshot=t109.inf", 
		LAST);

	web_concurrent_end(NULL);

	web_concurrent_start(NULL);

	web_url("ScriptResource.axd_3", 
		"URL=https://lt4-cmi.stratacare.net/LT4-CMI/ScriptResource.axd?d=a62vIxyk0y3WJ7WPdo083YosPYGbPw4UASX_0F9_w8NmsqP0nLKFDnPBopAG0lquDGnmo2GsbR0wYbpdc7Xe8EfAI8QI9tBypsuqhGRxWz8tXzgnwLBrFMD4RLBB-6bfFDNaNnr-ZA1emXbWp4SQUQCiWwY1&t=2e070b50", 
		"Resource=1", 
		"RecContentType=text/javascript", 
		"Referer=https://lt4-cmi.stratacare.net/LT4-CMI/default.aspx", 
		"Snapshot=t111.inf", 
		LAST);

	web_url("refresh.jpg", 
		"URL=https://lt4-cmi.stratacare.net/LT4-CMI/Images/refresh.jpg", 
		"Resource=1", 
		"RecContentType=image/jpeg", 
		"Referer=https://lt4-cmi.stratacare.net/LT4-CMI/default.aspx", 
		"Snapshot=t112.inf", 
		LAST);

	web_url("ScriptResource.axd_4", 
		"URL=https://lt4-cmi.stratacare.net/LT4-CMI/ScriptResource.axd?d=3gq6O3O3nGwfttLG4Je7B12cgkxbs3S7NPdjHpwHMq__1DjaW76hw04SMWxWyfyok0DUEdqE5elFEpB-Fa4fZqYBt2d64nRW--Z1ILVu-RdH_XXTNUf8juhfWP_EDcMM0kGvt-igZGc9re-3IR-ovHxWf_c1&t=2e070b50", 
		"Resource=1", 
		"RecContentType=text/javascript", 
		"Referer=https://lt4-cmi.stratacare.net/LT4-CMI/default.aspx", 
		"Snapshot=t113.inf", 
		LAST);

	web_url("Configuration_SecurityGroups.js", 
		"URL=https://lt4-cmi.stratacare.net/LT4-CMI/Scripts/Configuration_SecurityGroups.js", 
		"Resource=1", 
		"RecContentType=application/x-javascript", 
		"Referer=https://lt4-cmi.stratacare.net/LT4-CMI/default.aspx", 
		"Snapshot=t114.inf", 
		LAST);

	web_url("jquery-strataware-adjusterportal.js", 
		"URL=https://lt4-cmi.stratacare.net/LT4-CMI/Scripts/jquery/jquery-strataware-adjusterportal.js", 
		"Resource=1", 
		"RecContentType=application/x-javascript", 
		"Referer=https://lt4-cmi.stratacare.net/LT4-CMI/default.aspx", 
		"Snapshot=t115.inf", 
		LAST);

	web_url("ScriptResource.axd_5", 
		"URL=https://lt4-cmi.stratacare.net/LT4-CMI/ScriptResource.axd?d=i2Avlgjjm_CsdALWesKSsO3r1WUONihu4tZzC-PXDIAkbsQvY65xKFglc9wTSZj-eLlL5jXp_ih59miYL3vZ655IQw0QFyXOnvdib0rcKsZt4imj9FvJ9LOYu4zXLUB0iqbV5r_mynbLmaj0lwV63RpOun81&t=2e070b50", 
		"Resource=1", 
		"RecContentType=text/javascript", 
		"Referer=https://lt4-cmi.stratacare.net/LT4-CMI/default.aspx", 
		"Snapshot=t116.inf", 
		LAST);

	web_url("ScriptResource.axd_6", 
		"URL=https://lt4-cmi.stratacare.net/LT4-CMI/ScriptResource.axd?d=KoOcWRxhHiEbHE1ZT5T8d9Tr8jGQ7aXMvTT7SEtlA3jf6eV64YgGZM8Itt_hjNjA2s2T0NapGQihgNfdotPi5DbDOrCqMOfQwCaOVY17iAkb4rwQzvBLkT3DX6h9MV8s6IzvQbaSmCcK2h-f_1NoVMtVDxM1&t=2e070b50", 
		"Resource=1", 
		"RecContentType=text/javascript", 
		"Referer=https://lt4-cmi.stratacare.net/LT4-CMI/default.aspx", 
		"Snapshot=t117.inf", 
		LAST);

	web_url("ScriptResource.axd_7", 
		"URL=https://lt4-cmi.stratacare.net/LT4-CMI/ScriptResource.axd?d=49LO1JraDeXcs8Bau28bYV2MKoECUG2eKD3HVkVgq86X-NTitE7MbsnNfQ2pIoSJ-NHQz9xAEG3S0WjXeHaWO6CT9yl-4aHvFwJZ6qi0A1wb5KxSdAEB0DDOoc87TElW2-qe-zrPuoRaTpkWOvfdGjQqwo8rjbIkUenpO2hIdy0NTnFh0&t=2e070b50", 
		"Resource=1", 
		"RecContentType=text/javascript", 
		"Referer=https://lt4-cmi.stratacare.net/LT4-CMI/default.aspx", 
		"Snapshot=t118.inf", 
		LAST);

	web_url("ScriptResource.axd_8", 
		"URL=https://lt4-cmi.stratacare.net/LT4-CMI/ScriptResource.axd?d=eKVemUnXQPGvHz-yR9dNiDNXBUVHHBq6ObuMiTl7cDqu2cCaumNKm0PIvzbyJ2xsdk_AaZjpkoycbTX57MiNUyeoCIwhYTVhMv33Xh1cl85rvt0-2zXLk9SxDKQeYSZiuoAveEkhA2V4yaQfOMnXZlszI1o1&t=ffffffffd7a56d62", 
		"Resource=1", 
		"RecContentType=text/javascript", 
		"Referer=https://lt4-cmi.stratacare.net/LT4-CMI/default.aspx", 
		"Snapshot=t119.inf", 
		LAST);

	web_url("ScriptResource.axd_9", 
		"URL=https://lt4-cmi.stratacare.net/LT4-CMI/ScriptResource.axd?d=AK71URqcSLuR-N7rtWca-hLooq9ykB4YexaaT7SFZT9e165mxmtFrzi40eofshUsoKoQn1TvROiG-HBzvW580X5ssWAMGL226O1ZAm28WS7w-RFiIwZe9tHPfatnY1oCseGYFNyv3toEVX51cD6G44GH1aY1&t=2e070b50", 
		"Resource=1", 
		"RecContentType=text/javascript", 
		"Referer=https://lt4-cmi.stratacare.net/LT4-CMI/default.aspx", 
		"Snapshot=t120.inf", 
		LAST);

	web_url("GradedBlueBar1x20.gif", 
		"URL=https://lt4-cmi.stratacare.net/LT4-CMI/App_Themes/Default/Images/GradedBlueBar1x20.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=https://lt4-cmi.stratacare.net/LT4-CMI/default.aspx", 
		"Snapshot=t121.inf", 
		LAST);

	web_url("GradedBlueBar1x32.gif", 
		"URL=https://lt4-cmi.stratacare.net/LT4-CMI/App_Themes/Default/Images/GradedBlueBar1x32.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=https://lt4-cmi.stratacare.net/LT4-CMI/default.aspx", 
		"Snapshot=t122.inf", 
		LAST);

	web_url("lightgreenbar.jpg", 
		"URL=https://lt4-cmi.stratacare.net/LT4-CMI/App_Themes/Default/Images/lightgreenbar.jpg", 
		"Resource=1", 
		"RecContentType=image/jpeg", 
		"Referer=https://lt4-cmi.stratacare.net/LT4-CMI/default.aspx", 
		"Snapshot=t123.inf", 
		LAST);

	web_url("min_blue.gif", 
		"URL=https://lt4-cmi.stratacare.net/LT4-CMI/App_Themes/Default/min_blue.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=https://lt4-cmi.stratacare.net/LT4-CMI/default.aspx", 
		"Snapshot=t124.inf", 
		LAST);

	web_url("ScriptResource.axd_10", 
		"URL=https://lt4-cmi.stratacare.net/LT4-CMI/ScriptResource.axd?d=zyr12Del4F2ZWyV9L-fObD2TJWQwhqwB8silwXen4VsUSg9W26STP1_TMz_3BD0TdaJkJu5rJa4WBI4Zd6DQUhcU1WC4JJKJG6Xjnjx_-fK1ab61N8Mqi2p2cpJRivuFmvr9nGjKo0c_Y6k775fj8vHcgzc1&t=ffffffffd7a56d62", 
		"Resource=1", 
		"RecContentType=text/javascript", 
		"Referer=https://lt4-cmi.stratacare.net/LT4-CMI/default.aspx", 
		"Snapshot=t125.inf", 
		LAST);

	web_url("pager_previouspg.gif", 
		"URL=https://lt4-cmi.stratacare.net/LT4-CMI/images/pager_previouspg.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=https://lt4-cmi.stratacare.net/LT4-CMI/default.aspx", 
		"Snapshot=t126.inf", 
		LAST);

	web_url("sprite.png", 
		"URL=https://lt4-cmi.stratacare.net/LT4-CMI/App_Themes/Default/sprite.png", 
		"Resource=1", 
		"RecContentType=image/png", 
		"Referer=https://lt4-cmi.stratacare.net/LT4-CMI/default.aspx", 
		"Snapshot=t127.inf", 
		LAST);

	web_url("ScriptResource.axd_11", 
		"URL=https://lt4-cmi.stratacare.net/LT4-CMI/ScriptResource.axd?d=Kv9zfOChpcPOkKGBCJIGb4kA86w4YKxOWeVg3d47LKzHVlHYPjEsLnXTf8mhfYeRWk3JO0JT4Ouxs4f_nZoceeXWDLOm6Q6_wndj2_VgJPROBzFiDDqUaRhCL-5dOyy-X2rJiiQ4eJ8BhJRQ69pmvQyo8hU1&t=2e070b50", 
		"Resource=1", 
		"RecContentType=text/javascript", 
		"Referer=https://lt4-cmi.stratacare.net/LT4-CMI/default.aspx", 
		"Snapshot=t128.inf", 
		LAST);

	web_url("ScriptResource.axd_12", 
		"URL=https://lt4-cmi.stratacare.net/LT4-CMI/ScriptResource.axd?d=VXqm9p-n5QqaY6lVMfbMCFCQanW9uecG76n3MvPASTruKiBRjONEe02P_oxZKjHVBHo-fH6FwmUG5VMgx0DpNcOM0a7USVmkXXH-F1t4WbJ7-zM4XZTYLldCICMMXEobwuj-abLki0L01iESpP6hEDDKkqwuRWP4YyzXbyUVLs_PAZ6q0&t=2e070b50", 
		"Resource=1", 
		"RecContentType=text/javascript", 
		"Referer=https://lt4-cmi.stratacare.net/LT4-CMI/default.aspx", 
		"Snapshot=t129.inf", 
		LAST);

	web_url("x_blue.gif", 
		"URL=https://lt4-cmi.stratacare.net/LT4-CMI/App_Themes/Default/x_blue.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=https://lt4-cmi.stratacare.net/LT4-CMI/default.aspx", 
		"Snapshot=t130.inf", 
		LAST);

	web_url("icn_Billnotes_false_w12h14.gif", 
		"URL=https://lt4-cmi.stratacare.net/LT4-CMI/Strataware/Images/icn_Billnotes_false_w12h14.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=https://lt4-cmi.stratacare.net/LT4-CMI/default.aspx", 
		"Snapshot=t131.inf", 
		LAST);

	web_url("collapse_blue.jpg", 
		"URL=https://lt4-cmi.stratacare.net/LT4-CMI/app_themes/sigmundseamonster/images/collapse_blue.jpg", 
		"Resource=1", 
		"RecContentType=image/jpeg", 
		"Referer=https://lt4-cmi.stratacare.net/LT4-CMI/default.aspx", 
		"Snapshot=t132.inf", 
		LAST);

	web_concurrent_end(NULL);

	lr_think_time(11);

	web_custom_request("CheckSession", 
		"URL=https://lt4-cmi.stratacare.net/LT4-CMI/default.aspx/CheckSession", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://lt4-cmi.stratacare.net/LT4-CMI/default.aspx", 
		"Snapshot=t133.inf", 
		"Mode=HTTP", 
		"EncType=application/json; charset=utf-8", 
		LAST);

	lr_think_time(9);

	web_custom_request("CheckSession_2", 
		"URL=https://lt4-cmi.stratacare.net/LT4-CMI/default.aspx/CheckSession", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://lt4-cmi.stratacare.net/LT4-CMI/default.aspx", 
		"Snapshot=t134.inf", 
		"Mode=HTTP", 
		"EncType=application/json; charset=utf-8", 
		LAST);

	lr_think_time(7);

	web_submit_data("default.aspx_3", 
		"Action=https://lt4-cmi.stratacare.net/LT4-CMI/default.aspx", 
		"Method=POST", 
		"RecContentType=text/plain", 
		"Referer=https://lt4-cmi.stratacare.net/LT4-CMI/default.aspx", 
		"Snapshot=t135.inf", 
		"Mode=HTTP", 
		ITEMDATA, 
		"Name=ScriptManager1", "Value=WidgetContainer56023$Widget56023$uplMTDList|WidgetContainer56023$Widget56023$MTDGrid$ctl02$chkSelected", ENDITEM, 
		"Name=__EVENTTARGET", "Value=WidgetContainer56023$Widget56023$MTDGrid$ctl02$chkSelected", ENDITEM, 
		"Name=__EVENTARGUMENT", "Value=", ENDITEM, 
		"Name=__LASTFOCUS", "Value=", ENDITEM, 
		"Name=__VIEWSTATE", "Value=fbSogrn8N+msnTA4VItBYlTSxT7PWACFCcBR1ryxOgZBxmuuxVtG8wM6WZxq/dm3zf+8oWKU3vVi1d02XBk2yLW0kBBO8Awsd4/CyY8yy1EA9GQSA5PHfJedmqRmhiJoQaNPi2dXr8YHcAdaWXzYnSkFdocwP3QGsVoPlfXRaCnMGyW8HxpmsRVdaCDUoNpNDR34szpw+Ru+zrql4y9Kjwde/f/VkiLzRxcHXHVs+y7Ph5siTxB9/uAqqVrHGkcELIIg5Ei00l7bMPzoqVzK169nMosuGc+pgryE/QLbKILtxckcu8dxWPsFie+N98Sq341KfvTK8UjpY4ve8+qUed7jQY9EWEkLefPkl6r4lZc191qI44EgtwrYsOhleFZFdYmnGi2s6i20exHwbYcgVLlTnYBMhBgpAxoifoy0u6mKFi5FlL03SpG4wvvq/j2GlaIzA3RNgTMRdlJ9OUOZPM1bFE+"
		"muuQVVq+mTnuEpPbtx3JCBjLOIDB4RBe5wCs44O9vMxeia6PJiWwPvOttCdK1UvizF4migwLjL6ecZeNpWNHi8UVo6d/l9ga8e9WmcWWSo0mc6lDEVX01m588WkSq3KwUABsgmDIxr/mjBXOjo909iGuN6FVSYpxG7ixN45EVhmNUPi/TPndpFRuTQgcQJNEtAvde1AhMk3CCKTlW2dIl6kfEMPrI1mGc8GQW2cMj9Ls+agJh+I7Azh2Ba46V+X/C6928MjBD8GtUgOoJa2hCU4+KALM9/R46XALF93MrksLvipgQFHLewK0OBD3pxrrotmL+OaxPKwm+roHWFYoLyakQp6Bi+UQHtoiNPWiiFBG8lGmSMrjq0g0rRBzQjJOD85168OpWkmb/0C9DZx9ce20GCLzUo1ft2G8urYJ69agcccP2OYzZYpNWN+"
		"6NPYkEkFBvHGUJWshWbDB1L97EcRtAPAjjrkEYxHsN4vBiwcHJqKP0MRYvAz+kNkdMnf4zd/DZ4PdeTdpn3SjR7vopolK+AaV+QHAYmBGlmcplw1Z6Zqemuz1vBlrtYSDY/JGQJPZOvIf+NQUGZu4sK48om3zVEDCXgkGB3pgMhqhs+VvJ6iJpywE9352zedmdvCTRgt4f/taOxz3pnWR7ashdJoHVKYOCvYXCUt8Bp6i9fXS9OJh1qBrUJadrLa7ISJzGuUuxMeNBq5q2bNkfJ/+E0OG6Gpd4hB83L+b2I/v2wpfOdb4gqwcMYIDjTTpzNxitvvEbk6e7b3KiZXt6eEJ31k8DOJKWJlKTP78aBACx3N1K14xiGrYL5CNxCXlgQj2hAX4Xw2ajEAN+"
		"DBiNa39cZWv6vNpnMhUCVP4FtCFQmj8O2QEKMacamDhxicMHmUPTtVnhM9iEa9M6iR1p8y1KTer9S8rqFXhELiGJAC3qZKhofAgosLc8yGKYtPFYYXqyLoZ11eLrwOtiWeLH3gS1b8nacnwWnUsr96kXTrMByd+C+RpDdmXtw40SApfCi0EoeBvL8Bcab5MUB1/5uW5C9CeP6UZM+hY+UrT78YUJNRbE4z0dV1OjkqSXNd6auoH/fV14l3dSm2Gy2MtZjf24XxZQn52+rJ0zuX4WdkVeK0GXlRcgQDKq81LFwQiXvHQfbdq6WZHM6M2xekPbU2q9K+8KQrTA2wUfeivLfqbHH+PxbgzcUebBMw2I3Bor2uQsTCzdYVYGDMQhiyEeMyxQ3ClzOfeKCOa5eeHgjY7jhvthQLvo8iOA8r9Nq/Ds/Zy4zOCQtzr4Lg+FoUWLW+"
		"uDLTafId0EXkGZBTKtMaizDp2wCdDOOoUU9zuLFgLa86dzQmsWiMmOll1CxX2kgLcsEgCj7Xr9O9zmdub2n2umf1PBPSOTpABR+40cH+gE4lo0zCFqgF1bfxo8GbT6EAnRJYLdNhvQpeUMYBTFquzjtD91gLWaPsK/7WEvtafUevLODQ9a6dInjUfFtZYxW831yfirQNlcmFAkKz9SFj5WVYg2EP7JuewFKCukXTD7NkRaFW5UgsKI4cnwqO9nYISXl+7QCd6NZLUQkd0FIzxiYUxv57+C4gKAmDK025+21aHunoxWCHYSRvu6yqFdihOaaQOLhx3EQ++ie+/7DpXzhDcqTZi4qoCCiCKwvAHm8v/2A87XYvxawOCbYSgmdIP1OqjVck5bYj0GI7vqozi7GC+SFFvXeEsgdYvFK/yFnVmV5Amq39qo2l649a2BwjpIUaM0R3nKSsgbfY6cqB4L/"
		"1W9mAwSBFXICWS1LqENrkf1AQhPS0HaAnz59o4HMtOTyaY5WMTi9OkUARTugzKqCnPA4W7dx26KImgYhu7eIRRnQpCgXH+q/WMdCO5R61HQrVKptNowXBBj6bXP4nUIbZpdes3/mzv/15PRweNfORWD1hljV/JqHEncQ/1QYFDeO7dalEGhhcevKD22vkRX7PJlOVwWw47kph2WlRqC4biNf3fEiB7YLt/CyYOmbDjwxt9RDgJa3y8QYx8uh/1Osb3bhSV+YudikD4wrJzEw6pL6oYZkKJKXnCx3R7pcUfCsLadAge7Y8D41Q5hP0oBbdcrfyMAw9dcfOJVpvpG32zo7eKatS8uKH4rrT9PCDyS9GftqXdFdcVfd4WTgkZT7UdOsv+"
		"0VEkmfAFwDHDVDWrNBtaBie3xP1glJmMWyZICu7mSb9Q2t3dXXZhNEN5nzyNmCdJGImomSF8LkZcyg1IR2LRfWG3a4q2fGRFfMdGpfVaGcTiF2I53nv4ZTVI1OQ2KTjrESXeGYyEqa0b4YAgtZY/6R4PZeGglN9PCQleATdcikVf+P/dk3hh8iDiMKuko91Fqe3alq0ZhX2c9TfUioeUP1hgxXa4v+Fv2Dm+vU6ecvfpM87nlwz36p3jiBbkP1IX1lWBc/8FCyzzM8T/yQPBCRSv6qbvkrKBq63rje77q/O4vUNzAsiEewtXex1URenZeU4IZsPfgWM+PergwCZ3FJdlfUQo1+lbZjDv9w5XUiZRr1gp/YbhQ08R/j3NJezs99fiRbEIM4pOmrWpJbqHPspxDDhD03bSSe+mztOsuU4cv5T2FnWxVJ6Q3TlxrnDiIapNE3Tp28HlZCXuM0HbvtBo2nrHFA3DTJXSPgRVSh/"
		"xaQuDpbLLxVQH4gmfxy8xsE2fq0EDvbpmuD9sPix+j1FyoYzCGtvdKJS7g81FcFnLxRTTxC8p7d4TvFtlalAP2/khonbIAag4FGI85LpnC/QmQhCBJOBoKsmXcnGNkq02Zwpiz2JnCh/Rs4gwVg/I5ZqhJ8esygGOBLxp1TWx+jobWcu8kg3PfCZ0583rndVNzWiArCStkL6ptBZsRyA+S0trTw1KlrawO+dyol3ZpNwjcOt2FCE2WjpZmXLA/EDtaiEUPZVaOGRAworDMgIeE4tnw2/pwKLQM/cCEd7aoddRdhNCJ+anYkqYphqRWI2Uk3lDWoI1H21WFE0JlGVvdWqi9hdGg39y+1T5Jh0D/kmqpdZuO+XHpTxOjG9AzKjk14P7HM2+tb+qBq7fCG4phuvtkYg8vjsFZoNw9hhAOaQrTUDdM72pB3LlQQX1pM/8M+D3MgZX4zFOLRQpqZG8v1nN2Oj2xg/"
		"j3TdosUiDavJYDNOvzxpNi35EZvYdS7hsuK2N+U+cMeQqbdwBO/2zfzpFvI5t34Icix3aJ0C0nkjAUYKOnTac+ZNyeB0aqkdvBWwuo0ZUALDKzCO8PX1V15Yup/OHnBivNGffdTD4QG1DzR+oeAmc6GSJBFk0qI8tkL7/+eifBpbhSVoQfchxaVl1Ypy/1jwiGo6GJ5iosyZylfhX63T3YDM7GPj5+e7PQ5Eh9BI205pVB6kcvbO8WppE+MJB5/lpcMKPQPPjy6v/s1hjWqUf8JtXVjKK9NMv21Z2lSwlouVGMt/BqHbG0ufIu0ut17bKTkz5TcSpFhJdhpbbNwLOZ/OMxQPOGSRiW7AjHzCgvK2nOe1ufFgdEoWPCfRTJvwYU+WmVosPE4lWGr+k5HATRcfUmYdyJxZ09al6Sjoxb5xi32eUYfxXVZyk6PwA5U6LomBOzQpTylD4LrTNJrKI3KCVyyeHo8zFsuaW/l+"
		"sGWffTdapjvilsD9wFq3eVJYGFxZ1gL501j65GZ4qSFx8NpbxY2iDNgqbz0474AukJ082JqINIIgd3xXImXqlw3HnNcnZ4p173ZKzZPadU25vPjku3E8YGywCTsbo2GGZd3uR6aIeRr3qwSVzjaNStBUapHp7r1diyoeDXqtAGt4yy3WO2D8KydakNqOaPtq2XyL4NYOdqEu0TPRVT81FClQvMNW5rEQJVAEecl0PmKEu/sMGOxl/gz4NxCJS0w5XOczFM1QXMoCNBQ9qDoAoutjJLAyjsjWn3ldy012c594l/l0kKKrM/brv74KeEx2drQ/60qfCr7CiMkOxKujU0RSnmMaPwcs8/tIwEtXwS/zi2LhJHjL/qgGtF9UUFgpnW0NuYPFe3eQmQKKG/C1T8gRY/fUOM+/0dEtLI49N7GVEApDYwgOwmni11lp63e9cf5SsDhWiTaUeEKN0lBuQFd0QEVJv+"
		"o48iln6BpzRj2MRAsu4VgaP8DTCNUdf2nQBxvPe0xf5brEFRyp41Juf2FHjiQ6HlVlHTFH6vMRUxIPbYU5VWwPwPJ0RGjaXHshGhvAw5IMNN6tG51/Xf4qaEYNvivhE3ii5dIHU5F8yg8xj8tgOaxJ566+kyYIBkHCXQQunBv8FzMZuieFwlJdCPl7TvES8aIauVi3I0aNcur/GMxX38WB6RhsX/GX/f8NwluBq7wcm+4H450C82JHnBqVjk0dLHoWOGJrkdNYoGAWpHOophZs1IeVzJbuvHM4DXCPmrTS2mZ4Z7ANd96ZG4NtbeCuv2hdlx+MTdaPPjrfuym30LfpCxn3aM9TucxdSP4SVKI4hjsc/Pb5s0T5Aq1BVwbFdMWdQYFx3aB49Uv4cwhR1Tq6YvabnIRYo32/sgf/"
		"f1EyM9chlXmEB9KsSOR8H66w7ah6wDm7in5OzCpdVsMUG6H7FN62av9tkgqXoMr7pUNcEvfYKWSIYyUO9hABivWSoJC6LzdJZVhPHoKwkYrz2tl8qK0e/1QgOg59O0u7SsnKQNSb3Ovb5H2iHBp5K45QQKoOzJqOFOZKhPvjTrUuK2maFCQcv0im5tmy242rOEa87OFQuSmAoLt3DtYy8fOcaufoJMi2zbfStHonvkMh8UXithG7CHCbEepqPZO42o/tYZfbI6/F3kgbGbU/5bP1WkDJA7xCGgY255FZmKStndqOsytRETLDVMLH3j9eR26BAKgwCHNmcowNLbhx3ckSBOKvIhounKpjVvZtCr5ai1HJL57I5iGyGx4yPNrE7yNxEQil8R+UFR4ibMULu3WzeJv6YHOlR7JFhrEP8AkSvkX77ALPa0qPJU4Y2vrXw4w0WqRHrrTp4mYhO5HOVrf4LAWImde7+"
		"wXT7rGMYFDq9dmy8gje8j5MsgozRv0DjQajgp2gELuLkQJPiO1WxPu7zcOoRZlspMUyXNboqyFBbCJsvpdISzkLjhJx3qfcovLBNatdG6s534ShC3M4ciK5/1PdfOb/s2Nr79B0siFa3S2ZapcT0Ic/r0zPBmFQey/byq3T8YonAX4Zt+5/MOIja0NgdIZLrkSUYX7J6tR3Ria//KErPRj/mHH18y6VnI93nR6IcHy1NK+5FJgZwY1BwooaU1QcEyVu5etQTyGRNBQPRrU3bAJ9XsAcqRBPEuEFW9GxImdX6ROWy+ku3/02VD2Si1S5GNGaEkQA1RhQz0yjdPMAz8QUltTYGOrMw1K1pdj60Az5+Gbc1IRydxCgJbPISfIPkkGZ/w79I2c9i+raBwjCzIAxvqrgH69lwq+1g3Ig+142hLp4d0xcwO3H/"
		"ZbuuTbBCdWwsHzNfpe4Sd3M0p1XTGJVljvVLRfDnDmichvULin28SMqloeltZCYW0oSWLEciX5P5InOxKJjR1/jwxahH8VKvo9p+U1s3pdyGKqCL7CbzzxA62Xxb1GlH9tak5F43J/eSu1HXyD7w6B8SE/MhEGFXRrp6wmDbQFotp2TscLM63+QtvtuVyeByS9i2/T3v88mFNUYE0s411DYdtGSXoFvAXxlpw8L6ynBD9RNOiXyIme13xk1lsdGjDe5IhSZyOEmciSCWRr+nV5nWYnNMAQN6+hBeVW79pFkmNYVGXV/Mh4JCAPx4NJvG0pxbMrvBedZmtGMCQUkn9HFXTYR6/Dq0VjlbXjjIFYTbVszIvQpBb5YMZTEv4qT03KDxVKOeSlbIAFOJ7vQtKoxkK3L3B96Kn2y5+VY4SgJ0EJe31Ezs7STSb8TRbCZIQ+ZPXPR7/"
		"HviUqEGJTmqn25S49fOqN0MJ3rM12achFsag2bW49PkV9ZZQMYvatDQBgB1+/m2N55Nj/q0UfDniVasnRmjzMapRDGmnRFNNf7f5EW23ZGKp67HU1Qr+YKQi7I0/ldbB4nNMLIk6Am2u27FW1/0lI3y3FcygtvVbhPHHEQJnQnJCAYaib1fXtSnCQn9XgUItTPGTLm9xbQxTMKYnbe/LT3DCdbbTPZMNtGNx4x0FbIRt8Rf02ZK01JqbrSHsSFJ+ugS3qIz+qAojQSDT4onKUE8rTGZqTBKdTcj0q8ykUCebwyLPq4DWZ8ncwDk0AnBcgQMbG7hILkuxSQhMlrlp8gzXIBLaenQcKczvA51MZfXM6vs5UjfNwBpqkIHiJdIqqMRSpZJVRHrpOJgRnYwGuPjLjNwhOlafALl7Yuln978D/Q31s8pFwoQvCUnPE8p7M5x9Ox0O5n3/TDEOo9ibxFeCHECjmy/Hml/GrBqKk1Mhqyzl2OLwVd"
		"/8iOByifE510eVYBaqh0Ztldadf0hUMJ0tS7itrInAHRK4xpwBsUGyiRB6q8Jp+lyXCkPQGhW57Ex/LuULpbxx8wNDjT9mP/MXhNt/gRnc81cnwO06EiXN6lsYzBshFeD1GgyU9h+N2tson7vWui2mRTgzKHPeyLiQoc2xKZdxP5qoZ7BAGSDUwPhgg7FlJOI3qFU6HfJZE4rYfIe4+C+0JivQEziGHRdUPXDhszzamfwo+zKnty0JFOcRJz0vcpuze2VeR2agRAmKnozt9i0ZDEkeLpQ97x3i1a2EuFcZnfu62v5BVGUyO0nVsfx6Kh6yQ5cLCA60nhd07XmNfUxQmWqxhnpFh/670njSgi3oUUxov8iYcJM1Nyz8NfJ723P9cAr/q/L8KO+PAjgcAy3cZWCbE8rRhucZxXsaG61D7rJNXf+1fxaEC4sGZbJd5DOZUYnPfsMCBVbvsBesftra3HcmZnp6mVNkO93BwU6UAfLcykIATPig"
		"+6AB2F1x7T6OquGrocvCAUw2tx4Gbxxhuuqnz7Tflb1JLxuSlmoEKl4mHw3PU8wEtABMmeKW1vTlOfsW3DxdrF3VGvTKQgSrkpwoLll+8aTwrltXmTeBjTO8x5ix8KK0BlJTa1WdTvgQx7wyvEum5XKVbP1VwAsqF5UIeBZbkXxNEurWg9MwrQn70GqNg30GbnaTV/Q6DRfT0WiUUaGdLhV+dUMMIgQ+4lcQJKoxy36N03kI9B1ASLMA9jXqlz2QteBNFy66NLOsObxX9eFZGINezCOx4uF/51EZnymSzjjSMWbfhLKRq6PIceVfqiKyPDSiZntqBMWPzpvely3hL6k6RIbLcsjXP+nzWEwBU9TBeNYkffWJ84JOOTWDsvIxLEdUuiR9DntRgtNfs5P3Jt7BQxm3jtoJF7HBt2bXvmG29qDtPboy2sm+4dhWaq26wLPKCmlc1Yg/tT/EQabuDbnHH0x0oQ826dMTkjrDTfj0V0+"
		"bd2jypIQ33lZR3Vs6xNv7L4Q8yUnSLTGcmFkqh547XT/3dqke4rUlNPBdcuwvTGrEgYakpxJcEfmUqnRA/5Bz0Y8U4koKxPT7KyYrfIBrqT6YUiNgavpcuiEWUfe9AsvKzruauJDtla63Sy4/cx3UAyadlWbZKjeBcVlUipzBaBgLjWgKE4TLuJas7s5AmYDdbQZHE7RnY+pOya9OfF1IdeWNBUDgOcq3EUBzEmmVEb07GbQYjHPve6rNF4cnMaYWV/nJk1rt8OUkkpKYHYaBo2BsbnZkp3YcjYGGTLL/KjlV/MT2L8KR2J6nhPEwH8j/StJwCMYwsKj6lsBbWc/WbDhNcj+Mapj5dzIwVUQdNoDLXCemPRT6JplOkOjuoQt30kWuvJ4g8DIW0j3ZF6F4XI+PnIJYMrwzYxeGxl2Q2xeuZC+a0dY79Yqpe8uhtMfOvsH4T9L0I78v0sUKo6Ki/XVyw2To2279vyQEQJ6aJM7+NfPpftP/"
		"8D6R2zetPsUzebq5SXBfMZZ21UNd8+dzUZdoznVocljSNuFlTb3xZHTK7L4HQW1tF/3pZM8A4e8AWSddZopxSjv7RadZlO4fBrbusiHpDVpqIvFNPsyf8LxNZuVU6heIONfKcNYXy+UkdwcxYLD2IMi9DpiXhH1lVXM4UuXFZD/B5AeldqlfMHhoX/3aCKBwysG4JCmGrSyCOlJcyXTEU4I+kDjRb5DfVof2bo+PuYWnYYhjesZIjWvG6nTO7RvOPQ9sePTAmMXdlHL8sZh9uxS1yaja7BED1nVIbVpQviuzXafpoDwTM2LkNeZqgrFLIfykaTHoH4RHGVjJTQpDf8iMO+UIBYPpEliTkP1oCUTt1vHUiXa2hZuc1Drnpi5+wegNJ2BhyV4wZeWnpFxwTmSHjn01nDzEE0enc2Bbfm+IIyyRM5UMwE18YL+N4Z4j5G08T33EkkFiPwh717CwxVzXSxPu2vVSc0ILewyPLSZj/"
		"1CfgbMSoeg2tqo2xwnjqktpVjc6EUgT1dL8Vh32cpnndIaMuyExov5Y52L0SzBW3CTSa92F9DriIMn/gxVOQYYGsEVdm4z7QWxJx7ITP0UJIZehZYXh42QPsKYxyF6LcjD7P2/aU1dfEM6JrTr9Rk0hFH3gvX08VMTLXZBv1XWB6duuN1JlOQ+upUbwInsehi2bH/XQNTZ5Z0VWFsXvxRJks2r+2csy3HEa7pPeW08/ugb1vaZ9xNPUFH/DI/tXBfzoEMdapylh/nQcNR9dB5DhUwNjGmJVvnVOwvR9QiAOKvb0dwOzWM2kuFgYrMPhHPmTxkgRo4+RHmM2bcX5wny0m5mPzCICfCEPn9anfwW9uNRZW3oDWSlglNJVyqw7jp4U5KrXo1NHpf8wsvchE1P4nqcvkOaToG3nG5GWGFQo3dYpfoEa3VYe7zkx9nizKnS5o7W1jIwDMYpeLJ/D1TZN6/"
		"cr2w4wO75lnEawcPYWxACkQHqTRGRutYVNwI6m+YY3YUlDi/ZVuy3y12mHI76/o/nxSZ/FjAnOrRJr0hYdLBKd4SaBaFyRO1k5VVpPkGTOxGzcYjP6R7w6+YA/MhkUxTicOeZyhDoTKiurxpkOFF5V7hDMgNjTrfTQTpNvMdf4wXwYeZnKPxK6syjHsRjcpsoI36+DPX08qIjmQETYpbx+qJl/YG5pmAhw5zJVwY2T2nlB38FizG28tEYkB2nddpBUr6xS7z21l03aggpuIWsa5DvURQ4sHwiHlxPVegtiLlQmk9zlght81qXlXCxMrGQrbOp5GvHCoGkPiJrnoJuZEQj9JweYP5dYw2AMwUMem1GBYPxClDK95foNye5+D9TMKhwH3GEn75a9mljlmn0OTLptYO76wbbLsJPL0jm9ABmOJXr70OFwKZn17i4kZ4DsKzpfrATkZjZgq7O+"
		"UwyxjzJou6mIPOi3itDv7dzy9iALdVTmh23V483fc21LNzWStuLBpLStXak/z+LbLN7rW7D7uvH2thZgV+RlfCsMeedem9+Ne4MUyz6n/hNxOFkvQ/HBxm6R87XpO59oW/4c3FYiIKRdivRilPrfZdvu60iSi3aQOQNUSvNQZHMesEtDL4+Dq9bZLfm6gWpdShX2MUvk6zhx8q+ux0f05UNw+83iIHVAWqs8AWjI/Z7LUkzFwGvJaONIUDb1AEr9Lk4bhpvuf+bejYP8QpxddcVO9mkHDZOEnAKmWfbVWnw0N77RYidDl4q31oR6fwrlVW47nBbvlBmfFuRjhPfgX1fxdyw6BAHHY4vYI2yxkBPJea+gRVHI6V7eT6o5TLjCU+Vf4+7EzeF7t+A7Nqhxt5yKx8FzVFAm/2yVFzzznV5Q2jrzQBT6l7j7ATrRnbgYmOkqfztj/r8vrfso7FPDqX0WOY0G3KOhpW5d2kI8vxSEusdpsjC+"
		"P2HgL5SDunm8jbBBPuHtLiTnyTvO5mpiKN6TkYZv9NbtdMzIwyxMBqZ4K2xt5ecNnPBSdvhWlrBRAT8GCWbazJK2qlsigL4rbKRFsV/dbuGov8PrijukUJybTpkp2LdbvJcX+cQ+ej/TMicwgTz/HeNWYurT/hrYAQ6/V+zqWvP4jU1L3pGNp7SoMrlOoo1OTF8/BmZUzBqb6dnDcugcN4HNnYgDgw4t9s/y/GqWvma+JaCuJl/C+weepmZgy8qlRL8slSX0wljBephMe8KgYbXBPhArqJHtsBBHgTK5J2YMgR+Wy8NNEV0zrAxjNfvj2/nX8nMBzPzk1u9wiVpm0DaBqlg7q64QJ/tPslWUpd5b8sIUe/8sMKjGfljiiiyCRQeSbEflDOXQ55G3X+f7bV19Pbts47WNUFU6NWmw8XLMHP6H1070saOzjI953TW56RkkoIexfq5urmV6z3Qb4rGj9Gudg71DI0One5Efp+"
		"NSvUPjYX9LtuyvBML6XCCvyODZdymQaVUZ8edSmDFn/AHRWDNZXricOnK1qpzHVtn7KkXpERfPA5Q6NI/i/kAGViEX/x/Y8JIf+E6sstud1Lk1G5Y485DIya+GHYp5pO6Vrisr9fflP391ZXPCk/S5OvaNb6nCLs01cx9002LdEXOuicIBJ2Y6ocrUcayx5LbFYe3CV5LD+S3pRIHBwmUIxnfkgfEfR3NIJ2ixi6uVT/3KdtMyGzbFME38KTckgxomUKxu20UR0LidGCRK5wIZlpp1BYCYv2x15hjjjj0S7p+mdDN5oQurRHpmGVJa1vzSfk4tWQb4UmMtIuV4mgL6wicIPqVkuMSiZBD2jWAYfbxI+0osBdAjk+MgexEDgNidLIE5JhyI7qBb519zz0tg7tXOqac7pkZH0fAc1zF+"
		"4DHlUERwtxonBTAzifkVC5aslCWiehbevzCfCh9dQnwRXzAAdNVERktwqo2Z1B3PuoqWMofLL1fADsntUrVL1Nug0Zo9bfBUYHOVDFtuAxtHRLZN0pwb4FlklBt/jCWeNctv9rHV0D7EKXEDPqsuCy9h8T4Fgo6u64SV1adAWmtzhufwt1qV7nWjJqQ8bIbYtCe5u+122twWbrzYlpAI9fTsWiw9nZMz9qfTmevcAgTgojrcy+CDZRj8HwzAWoWD07xN+sCJKHPL4hIRzPHcx3NM4uaWTEh20K8i+2/00Zu9jzomxuAKpFp4YL55lB95V8L5YunPuHv2BtG0+lVXT9gpsD4SUIEqYbuLp0SBps8V590GqnxEjchoON/1y/jIMIo8Qop0+vkZ/cfoNaRx2/oM1pmroSJdBaXVaUSS3OncYIz4EXHVmZIrt7FmkKPTi2I+VhnPMLkycSnYZv+BNP74kX0BN0loyBzm6FXzVW1V/"
		"CbHcg0oelYjRtivd/9kQuORX+Ng00r4Eh2ppaZjrw22znzzC3HHjZbcq5Vi3t2mUVxSAhkYD8thHzhlcLZSsVhMS945vmtEVfS8Kk1HgReIHPH10/WHlJjddTOPZ4psoYLYFJumf/tk6TuzhD+jIeD1VWSonRf0UA83gJP6jutIPdqNlGfO6Gi8MEIHqIrkYk9xeZfKwxIv0wImpWAHdNAF+U/AK0wFIto0T3p7HtkfT/OeRueoYD7YReelfT6AILRFTzHPqLEjU11TsMsqLOSJ4+DnO1nNwN/xPwwyA0YsSAy+I7IWvS2YeiqucL/1055CHMak+56seocxKZLszz1r1OKCLCXflt3jPY65u/BJ0tzRXaVvjvn45JrlmmaBAbAkZvDaDU1NeF+NMzYTaUzYgfMgTQ7sYipbKFphFHtoAwTVW9S4JaTIyMWkyFSaqAJzyQVZ+"
		"CQHI3zJa2DPM5AlcamIUztD5elMW7lz811oqSEOSW32OzvshslUyilkbXVy5ptyalWE7f/vcJ/1634rDa42LfIszuL85CU3EuoiCqeeQk/Lg3vSjvyRZyBiY1ncqztvYXrGDzME1CdVfgDMwSObpujm2inHMyPJY6mHu/brKd271T8YPXmwjnvfJplli0pPNpTIRsfga2OEGcmzVQLeffiFRRl4016cpbVPEX/XFHbXplKv14MboqfCCs6L3Ee7afZISpd9KxhtGM38ogeyR/BKpxe82J0CdLqOMYXf7wXOxx9w0Yu7ChQxngyjoO0KdFUfqJso0UiK4EyascOnE3EfYDn757QwY8Wv5laKnccHXBU73uaclpFeJZra72ddIXyJx5qo97E9eQxzdnkniQxgviqOi8tiDJxKfODAUH+"
		"NTVL2l2OaSAnaMaWp3qg8jOHLVDyDvwt4CaPVM4Phd1wjfDNClK7v0k2mMwlyMXSwNWGaZm0yHyBHvpdsja8s+rFUv7JYmBgX4+ThbZt3Ua0IiH1wv4pmYAWmkYssS73ClgKQg5iDAaO2PsDhCIV6Fm5KXBMQmEW7bJn1UonN63hh5pl8Hg3Li4Yxrz6AMQXwhWHcw1N6ZWxv5rUJmK1fPLkiKhOkl0AQCZtCd+Fqx9B2e1mASqM5XPv31uGZMxphNtTQDTHMg94bACh9GF73+mX60b69mJnJa0XWE/MerL+d0DfF2H5N2FtWiyW528AUph0ZZ95zwGg5J/AbtUpVe4ksrsYBPoqNSb4h/nYlP/PbuTMjfuC3Omq9OpwZlV2G/r9lQuXMcFynEuHOclZh+ESv+LHpkMCu1zFguMWtY894PlbF3rUJmRltCwAxLXeXkxQDucje5FVHi9d4k+"
		"drTgoT0FBCKX3fvZxnEUKusaGbCzZ1IuPvjSos/UlP6kumVsRYH34/+UYmW53VJI6zq7yMQPrqNr0XOqorAWeMgIGwnR4qkdI+mYMv9T4xFoabE2VXIQ81busPyh7RbyqSctpjnW5EEA2YhPEb/pyMgTVjTmN2lpf4iT7I/dUM7dk4D9GYMICdsVvX9CSQEht10QRuZ35c5ktwuUTYVUCzKXcgs8Se8Ck/zYvTV18LKy8KiqXnr3tZmFgHB2MzjgFwkU40CL9xeCFrYKLoxUnp9E9aFs8xPRIMlSzpEfuY3RVR6E1Nxdw9xNSfKY/tXrXcJZA25oiT09s5hqPXgSL9yyiykKKuIwivozYZSFVNtBqZs+EK1d3S+fOv7jll+uJISbOATx4UhiB/rPCqVU++UnSlelX8eWI6L8YYYRsTdJw5eU8pqO6atgwKKNV/1/Ut4YCovtvD0qsH6gMRa5ktxRQQghw+Mh/xIuxtJ64H91oB5GA2/"
		"AhmdULSnkqmTvprQcLr938IaeYFHTgUclRoIb4rohTS2+8QCu4cD9V0sfEhwHKhgCBCZPqyXiqLRQDJ6mcf1zUx1xDR2MGIyilxbh9nwh6Gt0DGFClbiIZVYBO/LrPeUwH1nncA+5mHNf4mAeZ0iGk5sz5BXG9DEZuzpOzsF32vdqjH1bz3NCw8Qwr5o3ujOTtmKHfYUe9mhHVbK6sfrAord7UQPTzoTBlO05S4MVyl0BIgoGpF/yGYUwHO8lS7tQ+NwpvAIHA5PmvgBrZk3XXJunQk3XjchpZzePT3sEok7iQoyKAReNnXQgyYiuzQLCdN9Fg+iyUdN4Kc6m90TSARGJQm4CSyoJVPnPJIZBRqT74ogWrLnDBKN3Q7kqoun74TJT9yPMYxGvCxn8qEJ6SwgCkyLH4lnZelurVxEN0rxISPHQSBld7tjzWgQ7drXrzMqn09x/x5DujIJs1Fh9g5Vf33s0ny6dX+"
		"rHgdBST0Xu1nDxIVMAmKv4dubmRI7f8Y9gyqFFDiKG7Rd5EyfhO1A7gQAhYye2mNlaWMiQgF8ucxPTTiZHu95wmfcHzBPgjJEMAIYj4bsiwrDpQEg6ZovpwjXDKb+8i0ejny367S22kVydAcSUybdFhWAm/QtVmo81ox3rVqb++bsk3+HYtxy+kOvbk3Jq3re1kpZn8X0BN5FBFpN5EgUAnK3Eb50TMf8Zx4sGAu0g9eTNciSDLjptjervlvXNHxBOXOu1AsdqwQQB8S3Wj9PhpUSJiEsKT8a1VEVOEaGZeBgmMCOyNGCiIRx5jiVszMYBFT+MVkNusCKkOubDFyysnmFEItyu5XvcyRcMJono70nQe5O+I3bo5GeE3s9CW7YTOPCQoB+L2J/+z6tU4eeGEFNPJI7MwgfDpNJf/4pWFXiAfEPV2TtTk11EO3GE8XmxWOvAgGEDqG/Lj3by18sKHfn6jgCWLZJSygWp1wddUe+crJJQLLL/"
		"UQcstUlWve4qjWm+it/3pHcI/Yav0GeSF9wiHYEYeORetG9lY07E7J5KqSnTuYsKuzsW68cNVLOMGjxHfdNAVIHA2392Qe9I7RIW2VJRh+7AdFiXJbIxpXXDKyn/2VPePHp34BQYUux4V2pRtfc2+qa48c044oWJMypGl8h3x0RE7amz5ykaKFybUiqoUAXR60lX9oWhgidDLvNSrvleKWJDQf4kkcFl80sqimdO0fYQstW9pVanfy15hjr3ewBerZjjTIz98s4TQZBcsxnuuJyTEfpRqAZSTpsSQOb8CGgTBF0zN35Binq67Y+jFPHsDiyrb0M/bZByL+tLpi7g8B8UVFuhzueUtRhVLdIpN1PpZchM6cC2/5kSap0D3aotFnlgWLUfFO8x/a9aVEFKq5uIHcts00tMttVI74Vhm+PmX3+zYpPKv/"
		"47lJwx6ogjX631L16zhrtVOFkOpB24iOOg7p0h36Kxkg4Vsx8JOMX7wlYFNxs9AhRSZoNxSFUT+QL8mqIMJvcpL6hgXgnl+lY0cIOdcaw38k2BqlsMP9PXTQ7BW1Fqov7Px2p0by9KDeOnVMifqc0qOK2+jbEBmWS50zz+fbMVlwx9BNdtIFp3a4jgCptuDY/YHyFH21Clv+UsdrdGhy/Eo0KtkVlEF2YHMoFKQSce7bCV+VhbuGZ8RAo99NJtUlFZxINVYxalWf4zFcWDUTPKxEKl6Prv+swWvN3CUwuDckWer/izEVCoIqaxvEfSBo/u0wx4Dgop5gZfv/Tp6l+3mi71Wkj9cl15HEMZVYGJC2LTERlYGOyfgrtumAxGkx93JEJfS17/LktinewQkleEjBB6C0FMtl28bFQyioKTaBgMLw+hq0ExYkSjDKsShPkt07uSCH1szhVpfLYaedisBg5N9J/tipV8EA9X7FhtEK7ixTjv/"
		"31vWofQJU5Grt3d1JvvRjgKSyoMn0C2P9acfKGKIAlIKAwYTEs/01CjbXSXT9WNWnC1YWiAycmQuPDoTOu2Ao1ZcpbaBADSdaw86q8tz/on9v8+gLJ83bT9Zp4k6ynFljaav0fbSuB/xKq8ce8fw6+3JONVgb+RFiaVji2C/Z5y4lIat8JSitXI7/J0Pd8VDJl5f0QImwpmqZI+o7hxV6RICfL4XeYeZIPix3Prw13I+Y7ra60AoZMk03ZWb5bT7w5gp+yjuVqC/SkZsB5YK/k2BA388C++3hENINLQxeiiShHvjD2stpZ5jQNwWGeJh9jvaOUFENoPj2Nk9BIsVV9ktl/Uve9OqmIqkguc+oIi8RSdzW+dm8PQoSH7sp9xStk923+LYzju7Xzs529vo4WJcLA/ZIG963GIQotuBLi9Ol4GceJZkxuW86Tivsb7kPFgHeTGk/"
		"ufsQvl7IMvLj7wLpB7XWfzvngJbn5DdF72XmHFPhCIp8nDRCZNw4K+WSDlv1/NfTNCl6Fxs/TtnfOSMHnW2WuHI9+7KvwVk1VjSL4WRhe1Q2UUzTeuHCB9JfaAWCKjPiFk+282EQDH/VOXw38IR9K/CiJoYnNblyA/8nbIFky5bOZR6RWaWtWvJ9vvC9yyE+6eXBhrnp6wcmpNQgRMuUrShEB11yxXD3EfeTboVjfUo5oxQgbxVeDyhu5ZT+k5QTp6T7n8WRq1p6570eRILHAD0odTUpOMvYmmyezgyZQPsoFqG7p5NT7zahFXBwsp3GdijtdmX1VB+k3mJun8MfEFVhsm5qDdniqngj78FntcnEeXZ3EEhJvAJRt5/gi7PSIT0zwjB70IYASwdilkoS7ihq0kefKRBAi2aBdoZWgP4mcqvKsul/8+pMroE6RMpmEIenmABbQslOgp6ufv1o5PB64iRM/BO7pUNQEIsUgqWwuM8n+Qs+"
		"9zZOAxhLhdr+F1SH5wvC2T39fcnxfdYx+K9994cjXqmm5BSSEaZCkzRJYFCoYP7oePzg5j3DJ0GXjQnppBNY6hsVUebBY1pqfwOtzfKcdDhG0fFp+Uzo2huXXz4XSxWDxih8Ooo0TNQEtZwmWTFI4CVPWifPGfkrMP/FSH5Qc9KA0pWOUa7jsEYRbzYSa5JE8p0+Yjcnftepp4+L/KZQjFCD+Vnezzq1SGDjNz6j9kuDRRvQD99UbdTRZAwfegnNG78NloVC9sGd2zDgPWnXnL6O+I005FVhzK9NYOCbOeF4sJG5McOk0ZuoniS2ZMyImbWDxqOYGBHharLoJqX1nuwM1cIei8dkeU8wX03Bn+HbA6EZb8iCFJezpwX4sm17NelDUzeA8VxmWXYJBdlXIGcU7Vd6Xvb81/HfNZIRhUdGwTqAog94jSvbzjfek+O8A8n3H8sa6VORwWlK8/I0O9cnTL0INlT9P0afptVmmqDqWm/"
		"EDCNVgMDuXlhY7ciTMlCbKBdO6/TfRzl0tYMoCinhN+C4AU7KvyhPxctZjrMj0ra+yi16e+pHbqel/BYoj6vNkMOsQSrR/HrnZTAot+r6KHv2NnFUdN3ct+C76gNHtK0gb9Ez75ag2OAgxmtlOXR48Xq0EwWvD0gPLvC1vhwwNJLqpdUd0GKdZi/6ZWMb5J2YQhjloCZx8cpEI4p07wAxkN/zqEQmZrxIMxNx2Qs7YpxaNKQMc8OseiI55xqQ3lYc5myqm1o+zP1+rztsmDsRe65dnYeCSemuTU6hW5MACIi1TGV5sy8oXojgbSEMUfQd6gA0y05ZAbo91WqoezlMQGxBjRcg+tJmaieXgkRgmp0Ri33nruNwzsbfEsU50PE0fSjQpttY+voJUiOBZXFq+Vh+U8sPL3jjwD1v+p/cpincJTiazcYR9d1IsY5hw1/mrKX7z6PD7NKAhr7ojYC9hRgDSmZUj3p4KQiRd/f2uvmuG/"
		"h7f1yoRt3MZx2oYuwsudJvWQbJWKnrZ/cA2srNmeM0Nj00Wz1lrk1yjlfIJE/c62fKIdhLve+IP7uVht6fZJN4xCR1lRW4aVYc2fRgYg2WXWEzAstpol7+/BHyhLAtbbqlLtEewze0Uh7Ei6w0Jf/5hhwdoQgEGwvfFSf9DR0t1hg8mQJPhR2iw63aAmSHKwvLbn/CBI38eE8SBwyhq9rqFN5U7f/iSgOLqHlcLr2CET6XykhdgW5u9Pj3bexwDjLiPqYdTHghMUY6M1+bZsY8Dx/aTDBUUJaFQQom8bYWaPQPU82WbUTdFqdwAECYWPnQX6D6rv5EGxxntXM2glVvJyJkqs9PBPqSV+kNdHoO15u0lVpXtmlprdSCrurOBzKsIlQhseDgUXKWcMMHFUPfg3AaVio4e7lII+4fapZs02BfF2p3wiDfZeQVL265r9XBow2FWSdrVYhB+2a6uVZ4C7GHHfPpBYaTNreQfYEgtWSush9qCOu9"
		"/QKEr5NncZb4e6kL7WgNcwuMi/AOj3t+MJP1w3WdboD0jA+GnKCX775k7chM1h6KZC/ljQBsr3TvdVyHD4N2NWiqXPrY8yNuEVBjW7L7OXIOH+9s4d1yP9xHb30Y0kfoHJUtWU80dNbvGAZVXreGl1h1DenjQnhcqfC4UoQXx9NF3myuamI4avbeMBRfZWVn31w4q+5tmDV5kqOFUZBBz/GTrNMmHK5s+fJ/LXfAHcdPOaq0G8VFkn+xM1zWB6lsg7gq2zyEPuElHLCQPN8QunJKFv49bw2jsRhPSFqgHePseG1zaEopObkziptF0S3U6AoDQHq4i1TyQuSCAAhWdg7ckelUUcNOBhNEToX5b0VECA2u3vDih8dPAQym5X9n2ddgOOWzPbbt9phHcuydKfhXns+tJO78Md8kZkF91U9jY+"
		"M1c2RBOklv0tsvghdR12wu11jCyrpDcqL1sIwo0b0LUT1vvkrScp15oRN9BOfKPmmNsKcZHbM0Q9WC5oBgedhG9NlyS9sZogoTbb/q37jZ8qnoLXmVNkgYUhJGzeIiBU+iO4iutSEPUELHB1MTc2ts/zv8woPvyM/TUXojPWIkvXSeBYxpnf6xZxZPtKcOa0fqxRZfGqvLlzQhlgsJvF6SIukTont1tFqcoNE8v1MQ3FXdqRfIBV+NOGFTBlV2cMZEvYEaF2p86g6o77LBAM2is2lJN1wfwmsmN3IRGCkatAlKYCI22jQZqi4rWqKtjDYsatw7ZSlOYiL51FgDED5aTBId3HcwtdGWQ/k68WYqPIjYB9TyA2UpoBspYeDrm6ef35A5AAvJnBV3kTNUpOwns61Flbuizen97ISEVHMfUPouFfm22AVUAsAmp3XPXI/P6LaDpCiuw3fUCSdyqHTcPCMKktfUnoYSUZQDy7SeMI+"
		"15jvd21Sw9Ufbfr+iRDmJTmeQESNEvW5oyR+OHn6cqaQaUQN7teHuhDC0LHTaREDSrrvvdmM1pXe1r6j3TrdVPdWzrC7X+tsNzhxm8kHPxAgkIpXy3p8k3/peRoxNHtCsd/2eGJLN9KLBDVpwRBhsNhQ5hdfT/ciktQ79ahrqKiks1gzLofSOiQq+OAY4AEn7xH4Oz4kHQZi1zfPHRv5kj24V2uClodpeeVbmQakxF73Zv0U8bx7BndFEEDxlSjZ137YZkUw1IAAtZer7qM8A0dmheHyAEHPC9CN65TRYA841iSGS910lVwiixe3aaixAJyy1izT4rNqEdiYSLKYAvOvWU8e1URv1aeiQv1NQ+cgzpOWa8dkxScxqOiwBRK0hK29X8xgoOFU1L+KylAX9sUpltw6p4RWoLi0WI/FR8SO41NBu4jTJzRa1YRaAqioGxlOb+JuOrs1ZDJZrM6VZfVL/UOgO+"
		"pzWw6SGdIlKiEplOCHLKpaImdi6jITAEF4jMtye69oywVXdBv3Ere79inHXkRcmYJmHjDT9Gh0U4hVTKUA/knhjPhYT2rmB+lIQfmriM6xp3TMJv5Mx1ALe/WYunEJkNLDp4EmY/FNwZMsHefMU3RNgki+6o1yioKjHDYXe6EPxf6y0/7ySNKvYOVRH/6G5QiS2jPGB0VPuCsFXpl2hn1HlmE67N7j9bOGiBHGP03QQVSNIzDOurBUgnHtKpRvntvz80aZirCHaNAOjY07r9dDcYxsOSnUziDs/iGa7/8bLOA1FYcp9K4IX1MnLSNbNb/fL4C1Sf7sbQCeQM7D6GrtXnVSsj6aDhYOUJSPv+4lwLPFinBqjMfY+tKeVGk97pRL3PSsOTfvCnbevRv3V5wSQ0V7A57dWR9PjbRELiO0YfV+0tCmqEMgPgth4vdIsYYbEJfK+GN5WKPeg5R7+t6J66IHCZe8Md/"
		"lvtWeqtTXMIHs2KYz3EejO7pPT4oV7xPnQ9edFipRFI0/Q/h2nwpzkYkN224cPMKQzhV1meMMTZdnHL2thiDyxt1rA7TrpCE4rjm7egpAuON9h7m9IiPc86rFeG7ppiuVCdYDLAyRzjl8JZr5eMvOdIo7euLH/JAGtBSETYkKvcgGi7mZy2D+2Yhig5zajikYuC4E/TRCGcfb8PrRWMiOIq7IxQXwMtKPHL2wtpfkS2ZBD0MLeVXAB8Zr7sZAYhQSbaXN5Db7oSwB08L+/VEnWN8gTJB9wPJIUbg+t+mFvYMEt535f8DLknEOLYB1Q/1XxsTEImR4BH/cKIYiQAsTUtKT4PKeM9+ws90ue/0wX+TOpGQj87d7l6aRPkYcCuEIiHqDkZfpfbAA1lSuv6xk0qXIi8sRuamlPqJgBVW5aHSm5d2Tv8EoWRsO+fvTcWff1S+"
		"QacyxZZy71O9NcWIrBAz5mOphCYiSCkgdmMWbq6ML5xId1RIDdxHrlfHUVTe4zU+YXhfzLA2s1AqtiyoZ9GP0DLQ378CLB6O90+jGdYNppXsCwQTfKTio00ROeK19Fljbgl7M+MAOvQnEL+b9M21j7Ix9Jn8IORKip/7ESE4hdXaRUW92+/t2eEyudOAN0+bPrYTV0vnKNdTajPzTkkXfqhIxCUDUVnTk0Olj8llC6K0gWMAy6QYEquAmU56g6md+7aDrpolnz/HEwpYLsFlsX1F/46fJRr2CG9uGOYyoL2KoGM7xi1poSR3e1iMI2rZACuxOfTEwrXGfNvbk0qaMgrIdUWuRJuaK81YlDxPTB3CT1lTGqSEWQ0m1W4rfmM2Su4KztXLUbBo34lE/T/NO+HdlDHlBBfHqyddAVVUZxTckW6rMHPhybOfVUcz25wKM/2MBZFWZmlmAIFhHGjqIIKih/"
		"DVaEH0pCyjBaxMmoj9jQ6D0swLciIXh5vlH49NFuvtfUypA5LSKf35aEdZIRh0tALBxCBgr6KGgHcoaRPe8/BFNwOetxicltHewcnwiRdfzNYhEgykEDaJfiIbmDnBOLkOd0LWRkv9a2BE2fS7F/mm4oNfYU+MxG/VLZ2uE7GYqjszTeGc5OHlVFAhWmNPLfq6xokJ4ZsFMeMgT+lcVGHgIHBQZqcGFAK3DGGzCHBEIVHyxC4wlwecQ0nnXLwcBFZWnqObPZ7slRTgjoW4tjvqQ7RUnNUscyJ+uAa3aVC/nvPYc78UZu+3L2Zw3z5UqPb5sbR2QFXmy94t7Aw7/anbhaFzuMKy/mcOMnaHQy9hpxWEmRxoWieDnfhRMjTZs3CaO8vdGhC+fV7ou/Ta4ld5w+BunMBGFyq/HiNn0g1KglFyDra18s/rdSDuUASuB+PcVzBaTXqJIoJglTdnqfD/"
		"DAgWoCwlNhih3jvemV6QkJ9J1wYCsViM3W7MiZHc5NHZklQb5l8/ea/cf/RZI0ntu9Zngnz5I5tCa8GBeJU4FbXbrlLLiCUhoKF0QxvLLG+jqUONKPTPGrTyvcAmEkFK+lYNjru4VpAtsfbPT6CvSu/YeoPgXxi/ae/Ab3UM6T4/Xodawb23KQtHfg4Hh1xKzznOgG+Ti+mX8ZmbpzbLmMWwQxN4CODkwod78FMk9TjdEqqhT1Y9OXSV9l+qQeVGFf3pF1XpXUNffxPXzR2B2mLX02bMOnxDQ1/i6xjVGteh22ymvAWgTq3CVDU4OBOR1Z23Jkvi3IUTpSA7nRY6WnYT7Dp0mIb8qdAk7NzU0JGr8oppNvncmSY/++8LX1Fy7fzg35o0qygXVstrcCLKupjUqdyo/vJE00zdhJH1in7Znk3qFHJVdNtTDTI8vFQ05+T6ghdQL+"
		"bfT9LlJOPtCTNKXD52tq1riQwMgJdkjI9pvZv7wKWvXjmb2p+oTWR0UKHzouAKiuvJv74+o20tXBlxVsQc2aP+uQ+EiyodXt/cTjNfkk9EJlfBWw9Fzphrep2QLKNAgKw4UxV7wQGmDocMKkCciTbyaTbZ2p+RDsXhVenUywkZrMHDxTYBBEdri8Pi6Ns458z0B7UR92EAwHlA8kRWXkAFvdcrD/jScK5B5UPelafTPws8WvP6qyg7a5KHeMhHJCJVM1Rec9hpHc1k9DElTz5zDOABcaBxMEDj47zGSti8RjjFSDT98qfD+wJ1tA4wUmuxcyhzCSvEmaETjeAuMcj4JksRUHrilZeMIlqPnVQ4SZ8919W08MEY6z4O2NwiKp1D3q+azZ1khx4VGIOTfe2CvA93Cq4DTAWJzt8BgRk9vqPCXJI4wykiJ+4tiL28DU0CMJ4ZpzJlHFwl4lzBinIQh2pf0edh+pxkNXbn8wpNugDpJFASpV/"
		"8ONJ1AYNJnhAIkxnZJwFlKbHvwy1ECL/TGEoIJwJ9k5rYcNJUjVK9FS5qFTVCxg053WHRiSYYBXvagvyQSSZFEviFIWAWU9HawfKV1TOAkBvpprrNemjc3pmYw4VmdoCEobZ5Eqe+b9KthnlvRm88ZgYAKV3GqqNP6MxHJe4Tg6eeT3sXsAGMBowFcJin7jkRjScXkjIsb7GlgeaK1VeDzpMJ1erIZrOKD1GbOfnSBN8izf2Zc3Pi/8WGVpoc0ieQ2BzFs0itEBYbDA5dU/sabiQiQgGRxUyJ4KTm3/NI4cV4oBIdszumVWvyVY+Wulg1iJgYAQDNnFxqnRymOkWO/kt3oaQPyz8oUemq916ahg1rtmpH2CHHoaUmU91Kj9imH5VmS1IS5X3oNVlE+9X1CvnomWEdRlK/XWCcmiXgffjAQXTDLatWHW6yHRe1EkFaGFaLEunQsrdQoLQQ8ijHGc154E1MvckH+p/"
		"KadrOkY0jlhpIrRDp2QvyQUAtkkKA38W5tz2y1GYHArUWz05MiQo9CVKMi2oSDUKry1s7xOLvyix6w6HLT8vT3TeFC9AhAAkX6OMSx+j84db3tgMUuVaGDmHhQ7T2PIkoAcadofxtPB5bnPtAtbClkTtat4lfWyferpoGF+qsAJCaO10JG8AdVzdRmPzcaWsgIYdB8mSjvr9PLiFs5VuZ0vOz0NoOK4tlDSWJz41/I5m9L+bt1AGPZUfSAvw6yyc+7YuOo9fyXgYaqqnjtscT3lgUZ7b4/fv1Jv2jNKNISqnbNVg4akO0HLMp4gaQ2FRVvW9LHoTJJ1Q8+rfureg4W3fepmB0J0V1pySWHrstDjSX7cXbgSZwuXfq8h8wVDrwOibz6RrwmBaRBFkjhDbBTZ7sHUQB2CF5q987y9FRulznsAUGLuFa+34Yce6g7n5bMGuI0/C4hlzb7KkIEcubmcfC4A38/"
		"gq164u20fsAIn1R1Dt6QRyQctO1/pIeyagZm5xp0a+8dHKRWIxBVnLW+tXd5IFR6HiZ4HWFCi1rVmnQuIXlHviTwV7VenuC6RKQZLSwQvTynLmblMrcYNEu4v77icEHj4r5YJ13oiY4pGpAIBjPOe4n8h6te4ckAY2Eo2pY4bpP71mffpVStppfyBer2VAZYSEFHaSFZ8NHUVDkxxk8pDyaoHR8PcBQDF86bIDYCLo5j7rumOYjV64KbbfAME2ysTDmKUonjwmaD6kCeJK+Ev2inQnxJl0xNIh4CudmMM83l/TXjx7dD6QuMZv4V2VB8nSFXqZSYl9FJgvyZPPQ1YaQx9VP5FZIWGOTSmOJRzJybtOzA9ueElNIzNroznvwNi8SqZ1ml4XodKZBuum/"
		"tshE1sLfglflRbYEU95trUyA5W9JvdEKU59nV8oeyh6rMwBw1Og5Lp3iHAtNBQ92k52tcWYLnnEoa30jkOYGPydBQnXl6MXe7qVjzBC4xO1q5+OHlmD/qp1i7BA/4ezW9ylPjI6L0xyH38VO4+MGA/8T0PzS0yrS4JN5YaDxJQ933l4eIN2aqnKMj1oyN5zt36t72gzMOyReiyylIWB0FcfWKgZf59Ib4I7HMEQDS9Z/nRAMd76VOwlSxxfluwuqhWa1lN8Xd81/XCtzoKvqJmNkMQf/TFQIRUhYGm6KClE6DmoOQgLG+e4sdGkmaH/n82zaL4WDlRA2Rh+rZdnhlq4wD5Uq/pXmWFc2DxajiSyPHGvL8Xt8vp7W4EF/t25OrphYO4LcEuFbFL39ohja9GEDr8aD5Dnu8AQyUR7PXC0VfG724Cx9xHWQLw12EYzse+"
		"mPsWuppqCYew3NfKgke0Ckxd4Tp8X7bun4p0p0tfBqcU2Tquwa3xgf89Gkar12NryzT8CKMF99n3oWj3xJC3DaLbFc6QbgsGKsgICaha3IXtDk/3Q4TAs4veE8bkAaMsmSeKyo/Oj4SwpMJN9FlIXTPqSYf/slAj/dPR1BO5/Ka+EcDzVSN0s1Zpf8UMgo7+Fco0WpySbw9VhGowY5Rw2RbZBhpOHV2zTzPjg+a77qfStEkvRt/V2paLrKsy45EFFKNG2DE9DFNghWQvs+699v9RK+e0pZAd6yzxzZKQ1hqafudwWvkg25tlk8eyLY/ekF+4BZyUL2zxw0D+PSkbjGOJx9IxH38ETShoRPy6VC8lEZ1Rbx0Mcf3mlkWXXrJZwRnW92z/X/wxOwivCvzgqrPqtCM4IHcZ6uW7ZODD8AIapzLwrHtnlKDkOOfbXhEprk+rE7/E0V4awUQBDUIGXcJ7enK1fyue3/"
		"4jyJeyFzHBDCBopf3Vvs9/+umSWOYDcfNBE/8MfMIp8lp7AsB843s83OUqS+LyLa9JXnKcLjY7yeu1seJ/ZKzi0IChk81Q8c7/3SD1A/fCFLInfCt+vBYAm7+ECSTE2pxHFOfDB+iLCxbc2VGltBMPZe1ERRb8PpDiG5Jy38We4xxDEKcmbhsbgtRQRWbpTHwMC142Ag4X/ZgNh+x1Rr9vCL8h3wj6r0RsncEvQV2KZXqmbUskTgKcBXVtCOqNPkj0EzOFhG2bfa4mXf7wpK6RYgs9dUYbWRNZsXmv3zw9PdWzQHZIjCI1JTgdMBjPS8VSmRqruL6TEdo+9tSP1ZxQu6daAFjFN248v3CXQpyWMy1LCguiPBYPr5S2tGRbJf6+j4UknSkt2yUBiHPZSokClF75FFA8WpKMzCTTynvrqVw29FgpjSGmYf+UJ4EZWS7tG7/"
		"Y8BmzhAfGHzr8Ft5PGr89V7FqNOBC4qJyWtHeywKar2aCxx0fRtu9jfNYwtmWce6jxehacZuvB0URMfGFSCzOJIKgZsk/fmQr/BLUCE3E9E1qngw/mX6G4TYqSj94gJ8CDOcSxGEH/kMwNXjxi+YVAaGXdeM3IZIHhR/0xiJXzzOqVfoaMX8Kt4m9AC54RV6R6Efk7yD9GqcXPMXeQK2XM6OsptZxyeywg+bXia57CwZnMotoYeA5Gye/piWoz6Cl8X+Ds/0U5vBJdc8bBmn2Dm3UNkMPToRDVHmLrTqwYS5JsodyOPc9UjrvoT+hUaqqAyxfEL+O2I5IIq9KkSyECERRj41Clur2QYvq1bB8cw2+I2PZmxPbQh5iAL/kQ9kDE6dhrgJqn+HvUJmLq7rlJ0iCNakiv1mi10CaIkiOidhf4ytb6r8YUbc/cp8XSIxmc9ac65rav0mhg+"
		"NCCHYDWB1YuZxj1tYGIqtXfMnrypNBZkF7u8F3g4YbaiX5gdcPH6PONjkrfE3vDeMuDFRqLaJDanDrR17hkHuKR+BY/e/Y/sF0y+TBsigl9NRiMOiIZVart2tH8/oCrnYy/YrFQ0GvL1tcp6YtEcvpktKRowaUg0+lE0sbuEuBeqdLtEsZWfKLyzKTMuACZ/QeEiU6kPYBmDqi1WuSlSz3V4pJs94Y3RoJQLr3UyXdmqgMiyeJ8ZFNG/p27h3tyVGi+Ottvm4WLlf5+XSuYDWVFic6yW3cZcMCK1R+t2owRTXLHG/ayMx5u2fmVhAskUSFfG4Pc/TbkEq3QMCdeehS8vViKHOCwIofNs0Lxys9f2WRBnh+ygc/68xHbGBrduCcqmIN3rtczU7rJrsBEERYZGR1V5pmAFij3mV/8xL8+j7RuR3s7iwR7kAPpbqEGXtut/eP1MEWYQiao/"
		"VNK2Yd8lhOLjfUcE0IX9ISkAUUYdDThAolZhWid/G6KyKJM8MGvystAESt7IA8yVex7AFE8P7SZy7sVtDg4BXxQrULCpXCFUjigUSfyw9CM8tmELJdCPOU58Xo/lcogB+xLxQxVRte5F2BrHh4JHkUXGuGdd6j8qa+YtBFBNQHah77jI543VZF/3Ig1wJVRwdEUSGiakaC7y6vUFeQP4t7I0IBKheixT2D+ncEwA8ueLtzjidpQ3Hoo8nwH3TIwCRAdZG0xebUxiHTBoeqE8815jyZiGlcXMgcTBK+kH0r7tQZq9mJIkbxS14o6jX4jXRMjRfmAHTLp8Eu4JT0L3MLeEjDHQfdNwA2OvveDU1tl4+w81hB0BIBiQcI/0I35eR1XRWz/224WIVMp7r2OdONrl969i9BxDgrcPMkPSx6H+CuR2wSPZEw9ru/RP+XWHqHfklBen1FW6wnHsoEdOWokTi+"
		"piHc1XEUwxYGBzaYDuolPNtTO6C4tPGiMwm4yDAonnbL8g0IvYE4xYYWjTE2EYH+MDzl+JB/q5DePEiHZQl4FMxOyhpdEGjnoeYnUjmCmSQbrDFRPbyMXxUQgf/R/jsKXP4tqSRrxh8maRZxWuK1ZrH2fOvmEYlrGNVxOYQNwRrDG8LLtNV59whJHI0018+jLltH4gsrGOhD3Nn1UPWXZFuPkxvZfzT3VawdLeaGDugFpgnf+YkxxGDUa74b2KW++EvL5Bk82pKD8kXx5Q6LR/jEz6ZUCdZ9Tj1S+QP84K8MxxX4rL1jEtfOzwR/EQEyXanSDxBDrrxhWrjQqSl39Xme4S3PElzK7vlooKyPkhprWXqtRepc4VYdDyR7W2PU55EE2XB+i7Cc1Bsb8gB55UnZzy2C9qVlzwz/MuVGQnzs+8m96g1MnhO+R+"
		"EuzjE1NFd0Tjas6PCgppwr97JNGg4EtgdNQCBUufTKIhr6j2ZRrYH8ygbYEh3p8ReTzW3Zz+e71r8pdkNzI5IS5yoXFDJs5DOn00AT", ENDITEM, 
		"Name=__VIEWSTATEGENERATOR", "Value=856594CF", ENDITEM, 
		"Name=__VIEWSTATEENCRYPTED", "Value=", ENDITEM, 
		"Name=usrcErrorPanel$ctrlPrefix1", "Value=usrcErrorPanel_", ENDITEM, 
		"Name=hdnScrollTopDefaultPage", "Value=0", ENDITEM, 
		"Name=WidgetCloseParameters", "Value=", ENDITEM, 
		"Name=BE_CurrentBillList", "Value=", ENDITEM, 
		"Name=BE_CurrentBill", "Value=", ENDITEM, 
		"Name=NCCI_CurrentBill", "Value=", ENDITEM, 
		"Name=NCCI_CurrentOriginalBill", "Value=", ENDITEM, 
		"Name=ListOfActiveWidgetIDs", "Value=8", ENDITEM, 
		"Name=WidgetContainer56023$Widget56023$hiddenWidgetID", "Value=8", ENDITEM, 
		"Name=WidgetContainer56023$Widget56023$hdnNeedToRefreshWidget8", "Value=0", ENDITEM, 
		"Name=WidgetContainer56023$Widget56023$txtSubmitInfo", "Value=", ENDITEM, 
		"Name=WidgetContainer56023$Widget56023$BillAssignmentInfo", "Value=", ENDITEM, 
		"Name=WidgetContainer56023$Widget56023$ctrlPrefixMTDList", "Value=WidgetContainer56023_Widget56023_", ENDITEM, 
		"Name=WidgetContainer56023$Widget56023$hdnScrollTopMTDList", "Value=0", ENDITEM, 
		"Name=WidgetContainer56023$Widget56023$hdnFilter", "Value=0", ENDITEM, 
		"Name=WidgetContainer56023$Widget56023$hdnSelectedFields", "Value=|WidgetContainer56023_Widget56023_MTDGrid_ctl02_chkSelected|WidgetContainer56023_Widget56023_MTDGrid_ctl03_chkSelected|WidgetContainer56023_Widget56023_MTDGrid_ctl04_chkSelected|WidgetContainer56023_Widget56023_MTDGrid_ctl05_chkSelected|WidgetContainer56023_Widget56023_MTDGrid_ctl06_chkSelected|WidgetContainer56023_Widget56023_MTDGrid_ctl07_chkSelected|WidgetContainer56023_Widget56023_MTDGrid_ctl08_chkSelected|"
		"WidgetContainer56023_Widget56023_MTDGrid_ctl09_chkSelected", ENDITEM, 
		"Name=WidgetContainer56023$Widget56023$hdnApplyODG", "Value=True", ENDITEM, 
		"Name=WidgetContainer56023$Widget56023$hdnBillsAssignedTo", "Value=58528", ENDITEM, 
		"Name=WidgetContainer56023$Widget56023$lstBillsAssignedTo", "Value=58528", ENDITEM, 
		"Name=WidgetContainer56023$Widget56023$chkShowPending", "Value=on", ENDITEM, 
		"Name=WidgetContainer56023$Widget56023$txtControlNumberFilter", "Value=", ENDITEM, 
		"Name=WidgetContainer56023$Widget56023$txtClaimNumberFilter", "Value=", ENDITEM, 
		"Name=WidgetContainer56023$Widget56023$txtProviderTaxIDFilter", "Value=", ENDITEM, 
		"Name=WidgetContainer56023$Widget56023$txtDateFilterFrom", "Value=", ENDITEM, 
		"Name=WidgetContainer56023$Widget56023$txtDateFilterTo", "Value=", ENDITEM, 
		"Name=WidgetContainer56023$Widget56023$lbClaimStatus", "Value=all", ENDITEM, 
		"Name=WidgetContainer56023$Widget56023$cpeMTDFilterEdit_ClientState", "Value=false", ENDITEM, 
		"Name=WidgetContainer56023$Widget56023$hdnResetGridCache", "Value=0", ENDITEM, 
		"Name=WidgetContainer56023$Widget56023$MTDGrid$ctl02$chkSelected", "Value=on", ENDITEM, 
		"Name=WidgetContainer56023$Widget56023$MTDGrid$ctl02$hdnBillType", "Value=2", ENDITEM, 
		"Name=WidgetContainer56023$Widget56023$MTDGrid$ctl02$hdnOriginalBillID", "Value=57743376", ENDITEM, 
		"Name=WidgetContainer56023$Widget56023$MTDGrid$ctl02$hdnClaimID", "Value=4461880", ENDITEM, 
		"Name=WidgetContainer56023$Widget56023$MTDGrid$ctl02$hdnIsCheckeduserId", "Value=0", ENDITEM, 
		"Name=WidgetContainer56023$Widget56023$MTDGrid$ctl02$hdnAssignedToUserID", "Value=58528", ENDITEM, 
		"Name=WidgetContainer56023$Widget56023$MTDGrid$ctl03$hdnBillType", "Value=2", ENDITEM, 
		"Name=WidgetContainer56023$Widget56023$MTDGrid$ctl03$hdnOriginalBillID", "Value=66251112", ENDITEM, 
		"Name=WidgetContainer56023$Widget56023$MTDGrid$ctl03$hdnClaimID", "Value=11606359", ENDITEM, 
		"Name=WidgetContainer56023$Widget56023$MTDGrid$ctl03$hdnIsCheckeduserId", "Value=0", ENDITEM, 
		"Name=WidgetContainer56023$Widget56023$MTDGrid$ctl03$hdnAssignedToUserID", "Value=58528", ENDITEM, 
		"Name=WidgetContainer56023$Widget56023$MTDGrid$ctl04$hdnBillType", "Value=2", ENDITEM, 
		"Name=WidgetContainer56023$Widget56023$MTDGrid$ctl04$hdnOriginalBillID", "Value=28271718", ENDITEM, 
		"Name=WidgetContainer56023$Widget56023$MTDGrid$ctl04$hdnClaimID", "Value=11364408", ENDITEM, 
		"Name=WidgetContainer56023$Widget56023$MTDGrid$ctl04$hdnIsCheckeduserId", "Value=0", ENDITEM, 
		"Name=WidgetContainer56023$Widget56023$MTDGrid$ctl04$hdnAssignedToUserID", "Value=58528", ENDITEM, 
		"Name=WidgetContainer56023$Widget56023$MTDGrid$ctl05$hdnBillType", "Value=2", ENDITEM, 
		"Name=WidgetContainer56023$Widget56023$MTDGrid$ctl05$hdnOriginalBillID", "Value=61726885", ENDITEM, 
		"Name=WidgetContainer56023$Widget56023$MTDGrid$ctl05$hdnClaimID", "Value=11607987", ENDITEM, 
		"Name=WidgetContainer56023$Widget56023$MTDGrid$ctl05$hdnIsCheckeduserId", "Value=0", ENDITEM, 
		"Name=WidgetContainer56023$Widget56023$MTDGrid$ctl05$hdnAssignedToUserID", "Value=58528", ENDITEM, 
		"Name=WidgetContainer56023$Widget56023$MTDGrid$ctl06$hdnBillType", "Value=2", ENDITEM, 
		"Name=WidgetContainer56023$Widget56023$MTDGrid$ctl06$hdnOriginalBillID", "Value=28756144", ENDITEM, 
		"Name=WidgetContainer56023$Widget56023$MTDGrid$ctl06$hdnClaimID", "Value=11993699", ENDITEM, 
		"Name=WidgetContainer56023$Widget56023$MTDGrid$ctl06$hdnIsCheckeduserId", "Value=0", ENDITEM, 
		"Name=WidgetContainer56023$Widget56023$MTDGrid$ctl06$hdnAssignedToUserID", "Value=58528", ENDITEM, 
		"Name=WidgetContainer56023$Widget56023$MTDGrid$ctl07$hdnBillType", "Value=1", ENDITEM, 
		"Name=WidgetContainer56023$Widget56023$MTDGrid$ctl07$hdnOriginalBillID", "Value=0", ENDITEM, 
		"Name=WidgetContainer56023$Widget56023$MTDGrid$ctl07$hdnClaimID", "Value=13504276", ENDITEM, 
		"Name=WidgetContainer56023$Widget56023$MTDGrid$ctl07$hdnIsCheckeduserId", "Value=0", ENDITEM, 
		"Name=WidgetContainer56023$Widget56023$MTDGrid$ctl07$hdnAssignedToUserID", "Value=58528", ENDITEM, 
		"Name=WidgetContainer56023$Widget56023$MTDGrid$ctl08$hdnBillType", "Value=1", ENDITEM, 
		"Name=WidgetContainer56023$Widget56023$MTDGrid$ctl08$hdnOriginalBillID", "Value=0", ENDITEM, 
		"Name=WidgetContainer56023$Widget56023$MTDGrid$ctl08$hdnClaimID", "Value=13504276", ENDITEM, 
		"Name=WidgetContainer56023$Widget56023$MTDGrid$ctl08$hdnIsCheckeduserId", "Value=0", ENDITEM, 
		"Name=WidgetContainer56023$Widget56023$MTDGrid$ctl08$hdnAssignedToUserID", "Value=58528", ENDITEM, 
		"Name=WidgetContainer56023$Widget56023$MTDGrid$ctl09$hdnBillType", "Value=1", ENDITEM, 
		"Name=WidgetContainer56023$Widget56023$MTDGrid$ctl09$hdnOriginalBillID", "Value=0", ENDITEM, 
		"Name=WidgetContainer56023$Widget56023$MTDGrid$ctl09$hdnClaimID", "Value=13504276", ENDITEM, 
		"Name=WidgetContainer56023$Widget56023$MTDGrid$ctl09$hdnIsCheckeduserId", "Value=0", ENDITEM, 
		"Name=WidgetContainer56023$Widget56023$MTDGrid$ctl09$hdnAssignedToUserID", "Value=58528", ENDITEM, 
		"Name=WidgetContainer56023$Widget56023$MTDGrid$ctl11$ddlPages", "Value=1", ENDITEM, 
		"Name=WidgetContainer56023$Widget56023$hdnPendDate", "Value=", ENDITEM, 
		"Name=WidgetContainer56023$Widget56023$hdnAuthorizationReasonID", "Value=", ENDITEM, 
		"Name=__ASYNCPOST", "Value=true", ENDITEM, 
		LAST);

	web_url("ScriptResource.axd_13", 
		"URL=https://lt4-cmi.stratacare.net/LT4-CMI/ScriptResource.axd?d=jUre5LaIARUmPo7A9Dp4yMUGAtBw0nOCMQd64tzbAFza3SmNwwA87w7JMR8xxyBJqz9UZp03X4dBbkEQ6I5AAy1l5E4ALgJL0_05YKvWRooUuMbsxUvt1tBaKzDwHBIoLv22nA2&t=ffffffffb2e917fb", 
		"Resource=1", 
		"RecContentType=application/x-javascript", 
		"Referer=https://lt4-cmi.stratacare.net/LT4-CMI/default.aspx", 
		"Snapshot=t136.inf", 
		LAST);

	web_custom_request("CheckSession_3", 
		"URL=https://lt4-cmi.stratacare.net/LT4-CMI/default.aspx/CheckSession", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://lt4-cmi.stratacare.net/LT4-CMI/default.aspx", 
		"Snapshot=t137.inf", 
		"Mode=HTTP", 
		"EncType=application/json; charset=utf-8", 
		LAST);

	lr_think_time(9);

	lr_start_transaction("a002_Authorize_Bill");

	web_custom_request("CheckSession_4", 
		"URL=https://lt4-cmi.stratacare.net/LT4-CMI/default.aspx/CheckSession", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://lt4-cmi.stratacare.net/LT4-CMI/default.aspx", 
		"Snapshot=t138.inf", 
		"Mode=HTTP", 
		"EncType=application/json; charset=utf-8", 
		LAST);

	web_custom_request("ValidateMultipleClientSelection", 
		"URL=https://lt4-cmi.stratacare.net/LT4-CMI/default.aspx/ValidateMultipleClientSelection", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://lt4-cmi.stratacare.net/LT4-CMI/default.aspx", 
		"Snapshot=t139.inf", 
		"Mode=HTTP", 
		"EncType=application/json; charset=utf-8", 
		"Body={\"customerID\":\"35\",\"loggedOnUserID\":\"58528\",\"assignedToUserID\":\"58528\",\"bIsAuthorized\":true}", 
		LAST);

	web_url("DenyAuthorizeBill.aspx", 
		"URL=https://lt4-cmi.stratacare.net/LT4-CMI/DenyAuthorizeBill.aspx?caller=MTD&Type=SaveRequired&billID=&clientID=7001&billReviewState=na&billMessages=&letter=&isBillDenied=false&isBillMessageRequired=false", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t140.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("menuzoom.gif", 
		"URL=https://lt4-cmi.stratacare.net/LT4-CMI/app_themes/default/images/menuzoom.gif", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=https://lt4-cmi.stratacare.net/LT4-CMI/DenyAuthorizeBill.aspx?caller=MTD&Type=SaveRequired&billID=&clientID=7001&billReviewState=na&billMessages=&letter=&isBillDenied=false&isBillMessageRequired=false", 
		"Snapshot=t141.inf", 
		LAST);

	web_submit_data("DenyAuthorizeBill.aspx_2", 
		"Action=https://lt4-cmi.stratacare.net/LT4-CMI/DenyAuthorizeBill.aspx?caller=MTD&Type=SaveRequired&billID=&clientID=7001&billReviewState=na&billMessages=&letter=&isBillDenied=false&isBillMessageRequired=false", 
		"Method=POST", 
		"RecContentType=text/plain", 
		"Referer=https://lt4-cmi.stratacare.net/LT4-CMI/DenyAuthorizeBill.aspx?caller=MTD&Type=SaveRequired&billID=&clientID=7001&billReviewState=na&billMessages=&letter=&isBillDenied=false&isBillMessageRequired=false", 
		"Snapshot=t142.inf", 
		"Mode=HTTP", 
		ITEMDATA, 
		"Name=ScriptManagerBillEditorApprove", "Value=uplOkCancel|cmdAuthorizeBillSave", ENDITEM, 
		"Name=__EVENTTARGET", "Value=", ENDITEM, 
		"Name=__EVENTARGUMENT", "Value=", ENDITEM, 
		"Name=__VIEWSTATE", "Value=/wEPDwUKLTcyMzE5NTE5Nw9kFgICAw9kFgICCQ9kFgYCAQ9kFgJmD2QWAmYPZBYEAgEPDxYCHgRUZXh0BQ5BdXRob3JpemUgQmlsbGRkAgMPDxYCHwAFRzwvYnI+"
		"VGhlIGZvbGxvd2luZyBmaWVsZHMgYXJlIG9wdGlvbmFsLiBDbGljayBPSyB0byBBdXRob3JpemUgdGhlIGJpbGwuZGQCAw9kFgJmD2QWAmYPZBYCZg8PFgIfAAULKE9wdGlvbmFsKSBkZAIFD2QWAmYPZBYCZg9kFgJmD2QWAmYPZBYCAgEPZBYGAgEPZBYGZg9kFgJmDw8WAh8ABQsoT3B0aW9uYWwpIGRkAgEPZBYCZg8PZBYCHgdvbmZvY3VzBS91cGRhdGVNZXNzYWdlQ29kZVRleHRCb3goJ3R4dEJpbGxNZXNzYWdlQ29kZScpO2QCAg9kFgJmDw9kFgIeB29uY2xpY2sFSXNyY2hCdG5CaWxsTWVzc2FnZUNvZGVDbGlja2VkRnJvbU1vZGFsRGlhbG9nKCRnZXQoJ3R4dEJpbGxNZXNzYWdlQ29kZScpKTtkAgIPZBYCAgEPZBYCZg8QDxYCHgtfIURhdGFCb3VuZGcWAh4Ib2"
		"5jaGFuZ2UFXkRBX3VwZGF0ZUF1dGhvcml6YXRpb25QcmludGluZ1N0YXRlKCdEb0dlbmVyYXRlQXV0aG9yaXphdGlvbkxldHRlcicsICdBdXRob3JpemF0aW9uUmVhc29uSUQnKTsQFQYAFkNvbXByb21pc2UgYW5kIFJlbGVhc2UNRGVsYXllZCBDbGFpbQxEZW5pZWQgQ2xhaW0KRXhjZWVkcyBVUhZTdGF0dXRlIG9mIExpbWl0YXRpb25zFQYABDE3NDUEMTc0MgQxNzQxBDE3NDMEMTc0NBQrAwZnZ2dnZ2dkZAIDD2QWAgIBD2QWAmYPEA8WBB4HQ2hlY2tlZGgeB0VuYWJsZWRoZGRkZGTi6s6XwfCX6mgBXRJ87UpQ1WDNBA==", ENDITEM, 
		"Name=__VIEWSTATEGENERATOR", "Value=A197D016", ENDITEM, 
		"Name=__EVENTVALIDATION", "Value=/wEdAA4YOsDrEcUWbhJ9Q/MI2iTAJdBJN0YJiYAJilMjAa+6jyhH1WboTuAhks+Vxxjaf3/6SwstVED6/FJxbkfyVTky7cUmdDMQkH55Z7HOxIV+UdxgMUDt473V2x7AntAvBxFpkCGTBeW5K536O8uRGE81bX9XbTg8rjYKu59ZKdSQ2jk7F8KLCK7ub7qwkidjVbFe4JywQjVyHS7kdmwQ0wGg6gFOB1svkmzTfvwc+MCSGEFlLkbNn+GX8wq2MgDghVL0bEdGOUI2pTA3mE3ARnCq8010SeF4YJo50wh7v/Nsk6qqpsITeWlBj7SkSyYELC2KRAbb", ENDITEM, 
		"Name=usrcErrorPanel$ctrlPrefix1", "Value=usrcErrorPanel_", ENDITEM, 
		"Name=hdnScrollTopDefaultPage", "Value=0", ENDITEM, 
		"Name=txtBillNotes", "Value=", ENDITEM, 
		"Name=txtBillMessageCode", "Value=", ENDITEM, 
		"Name=AuthorizationReasonID", "Value=", ENDITEM, 
		"Name=__ASYNCPOST", "Value=true", ENDITEM, 
		"Name=cmdAuthorizeBillSave", "Value=OK", ENDITEM, 
		LAST);

	web_custom_request("CheckSession_5", 
		"URL=https://lt4-cmi.stratacare.net/LT4-CMI/default.aspx/CheckSession", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://lt4-cmi.stratacare.net/LT4-CMI/default.aspx", 
		"Snapshot=t143.inf", 
		"Mode=HTTP", 
		"EncType=application/json; charset=utf-8", 
		LAST);

	lr_think_time(9);

	web_custom_request("CheckSession_6", 
		"URL=https://lt4-cmi.stratacare.net/LT4-CMI/default.aspx/CheckSession", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://lt4-cmi.stratacare.net/LT4-CMI/default.aspx", 
		"Snapshot=t144.inf", 
		"Mode=HTTP", 
		"EncType=application/json; charset=utf-8", 
		LAST);

	lr_think_time(9);

	web_custom_request("CheckSession_7", 
		"URL=https://lt4-cmi.stratacare.net/LT4-CMI/default.aspx/CheckSession", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://lt4-cmi.stratacare.net/LT4-CMI/default.aspx", 
		"Snapshot=t145.inf", 
		"Mode=HTTP", 
		"EncType=application/json; charset=utf-8", 
		LAST);

	lr_think_time(9);

	web_custom_request("CheckSession_8", 
		"URL=https://lt4-cmi.stratacare.net/LT4-CMI/default.aspx/CheckSession", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://lt4-cmi.stratacare.net/LT4-CMI/default.aspx", 
		"Snapshot=t146.inf", 
		"Mode=HTTP", 
		"EncType=application/json; charset=utf-8", 
		LAST);

	lr_think_time(9);

	web_custom_request("CheckSession_9", 
		"URL=https://lt4-cmi.stratacare.net/LT4-CMI/default.aspx/CheckSession", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://lt4-cmi.stratacare.net/LT4-CMI/default.aspx", 
		"Snapshot=t147.inf", 
		"Mode=HTTP", 
		"EncType=application/json; charset=utf-8", 
		LAST);

	lr_think_time(9);

	web_custom_request("CheckSession_10", 
		"URL=https://lt4-cmi.stratacare.net/LT4-CMI/default.aspx/CheckSession", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://lt4-cmi.stratacare.net/LT4-CMI/default.aspx", 
		"Snapshot=t148.inf", 
		"Mode=HTTP", 
		"EncType=application/json; charset=utf-8", 
		LAST);

	lr_think_time(9);

	web_custom_request("CheckSession_11", 
		"URL=https://lt4-cmi.stratacare.net/LT4-CMI/default.aspx/CheckSession", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://lt4-cmi.stratacare.net/LT4-CMI/default.aspx", 
		"Snapshot=t149.inf", 
		"Mode=HTTP", 
		"EncType=application/json; charset=utf-8", 
		LAST);

	lr_think_time(9);

	web_custom_request("CheckSession_12", 
		"URL=https://lt4-cmi.stratacare.net/LT4-CMI/default.aspx/CheckSession", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://lt4-cmi.stratacare.net/LT4-CMI/default.aspx", 
		"Snapshot=t150.inf", 
		"Mode=HTTP", 
		"EncType=application/json; charset=utf-8", 
		LAST);

	lr_think_time(9);

	web_custom_request("CheckSession_13", 
		"URL=https://lt4-cmi.stratacare.net/LT4-CMI/default.aspx/CheckSession", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://lt4-cmi.stratacare.net/LT4-CMI/default.aspx", 
		"Snapshot=t151.inf", 
		"Mode=HTTP", 
		"EncType=application/json; charset=utf-8", 
		LAST);

	lr_think_time(9);

	web_custom_request("CheckSession_14", 
		"URL=https://lt4-cmi.stratacare.net/LT4-CMI/default.aspx/CheckSession", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://lt4-cmi.stratacare.net/LT4-CMI/default.aspx", 
		"Snapshot=t152.inf", 
		"Mode=HTTP", 
		"EncType=application/json; charset=utf-8", 
		LAST);

	lr_think_time(9);

	web_custom_request("CheckSession_15", 
		"URL=https://lt4-cmi.stratacare.net/LT4-CMI/default.aspx/CheckSession", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://lt4-cmi.stratacare.net/LT4-CMI/default.aspx", 
		"Snapshot=t153.inf", 
		"Mode=HTTP", 
		"EncType=application/json; charset=utf-8", 
		LAST);

	lr_think_time(9);

	web_custom_request("CheckSession_16", 
		"URL=https://lt4-cmi.stratacare.net/LT4-CMI/default.aspx/CheckSession", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://lt4-cmi.stratacare.net/LT4-CMI/default.aspx", 
		"Snapshot=t154.inf", 
		"Mode=HTTP", 
		"EncType=application/json; charset=utf-8", 
		LAST);

	web_submit_data("default.aspx_4", 
		"Action=https://lt4-cmi.stratacare.net/LT4-CMI/default.aspx", 
		"Method=POST", 
		"RecContentType=text/plain", 
		"Referer=https://lt4-cmi.stratacare.net/LT4-CMI/default.aspx", 
		"Snapshot=t155.inf", 
		"Mode=HTTP", 
		ITEMDATA, 
		"Name=ScriptManager1", "Value=WidgetContainer56023$Widget56023$uplMTDListButtons|WidgetContainer56023$Widget56023$cmdAuthorize", ENDITEM, 
		"Name=usrcErrorPanel$ctrlPrefix1", "Value=usrcErrorPanel_", ENDITEM, 
		"Name=hdnScrollTopDefaultPage", "Value=0", ENDITEM, 
		"Name=WidgetCloseParameters", "Value=", ENDITEM, 
		"Name=BE_CurrentBillList", "Value=", ENDITEM, 
		"Name=BE_CurrentBill", "Value=", ENDITEM, 
		"Name=NCCI_CurrentBill", "Value=", ENDITEM, 
		"Name=NCCI_CurrentOriginalBill", "Value=", ENDITEM, 
		"Name=ListOfActiveWidgetIDs", "Value=8", ENDITEM, 
		"Name=WidgetContainer56023$Widget56023$hiddenWidgetID", "Value=8", ENDITEM, 
		"Name=WidgetContainer56023$Widget56023$hdnNeedToRefreshWidget8", "Value=0", ENDITEM, 
		"Name=WidgetContainer56023$Widget56023$txtSubmitInfo", "Value=authorize%#%%#%%#%%#%False", ENDITEM, 
		"Name=WidgetContainer56023$Widget56023$BillAssignmentInfo", "Value=", ENDITEM, 
		"Name=WidgetContainer56023$Widget56023$ctrlPrefixMTDList", "Value=WidgetContainer56023_Widget56023_", ENDITEM, 
		"Name=WidgetContainer56023$Widget56023$hdnScrollTopMTDList", "Value=0", ENDITEM, 
		"Name=WidgetContainer56023$Widget56023$hdnFilter", "Value=0", ENDITEM, 
		"Name=WidgetContainer56023$Widget56023$hdnSelectedFields", "Value=|WidgetContainer56023_Widget56023_MTDGrid_ctl02_chkSelected|WidgetContainer56023_Widget56023_MTDGrid_ctl03_chkSelected|WidgetContainer56023_Widget56023_MTDGrid_ctl04_chkSelected|WidgetContainer56023_Widget56023_MTDGrid_ctl05_chkSelected|WidgetContainer56023_Widget56023_MTDGrid_ctl06_chkSelected|WidgetContainer56023_Widget56023_MTDGrid_ctl07_chkSelected|WidgetContainer56023_Widget56023_MTDGrid_ctl08_chkSelected|"
		"WidgetContainer56023_Widget56023_MTDGrid_ctl09_chkSelected", ENDITEM, 
		"Name=WidgetContainer56023$Widget56023$hdnApplyODG", "Value=True", ENDITEM, 
		"Name=WidgetContainer56023$Widget56023$hdnBillsAssignedTo", "Value=58528", ENDITEM, 
		"Name=WidgetContainer56023$Widget56023$lstBillsAssignedTo", "Value=58528", ENDITEM, 
		"Name=WidgetContainer56023$Widget56023$chkShowPending", "Value=on", ENDITEM, 
		"Name=WidgetContainer56023$Widget56023$txtControlNumberFilter", "Value=", ENDITEM, 
		"Name=WidgetContainer56023$Widget56023$txtClaimNumberFilter", "Value=", ENDITEM, 
		"Name=WidgetContainer56023$Widget56023$txtProviderTaxIDFilter", "Value=", ENDITEM, 
		"Name=WidgetContainer56023$Widget56023$txtDateFilterFrom", "Value=", ENDITEM, 
		"Name=WidgetContainer56023$Widget56023$txtDateFilterTo", "Value=", ENDITEM, 
		"Name=WidgetContainer56023$Widget56023$lbClaimStatus", "Value=all", ENDITEM, 
		"Name=WidgetContainer56023$Widget56023$cpeMTDFilterEdit_ClientState", "Value=false", ENDITEM, 
		"Name=WidgetContainer56023$Widget56023$hdnResetGridCache", "Value=1", ENDITEM, 
		"Name=WidgetContainer56023$Widget56023$MTDGrid$ctl02$chkSelected", "Value=on", ENDITEM, 
		"Name=WidgetContainer56023$Widget56023$MTDGrid$ctl02$hdnBillType", "Value=2", ENDITEM, 
		"Name=WidgetContainer56023$Widget56023$MTDGrid$ctl02$hdnOriginalBillID", "Value=57743376", ENDITEM, 
		"Name=WidgetContainer56023$Widget56023$MTDGrid$ctl02$hdnClaimID", "Value=4461880", ENDITEM, 
		"Name=WidgetContainer56023$Widget56023$MTDGrid$ctl02$hdnIsCheckeduserId", "Value=0", ENDITEM, 
		"Name=WidgetContainer56023$Widget56023$MTDGrid$ctl02$hdnAssignedToUserID", "Value=58528", ENDITEM, 
		"Name=WidgetContainer56023$Widget56023$MTDGrid$ctl03$hdnBillType", "Value=2", ENDITEM, 
		"Name=WidgetContainer56023$Widget56023$MTDGrid$ctl03$hdnOriginalBillID", "Value=66251112", ENDITEM, 
		"Name=WidgetContainer56023$Widget56023$MTDGrid$ctl03$hdnClaimID", "Value=11606359", ENDITEM, 
		"Name=WidgetContainer56023$Widget56023$MTDGrid$ctl03$hdnIsCheckeduserId", "Value=0", ENDITEM, 
		"Name=WidgetContainer56023$Widget56023$MTDGrid$ctl03$hdnAssignedToUserID", "Value=58528", ENDITEM, 
		"Name=WidgetContainer56023$Widget56023$MTDGrid$ctl04$hdnBillType", "Value=2", ENDITEM, 
		"Name=WidgetContainer56023$Widget56023$MTDGrid$ctl04$hdnOriginalBillID", "Value=28271718", ENDITEM, 
		"Name=WidgetContainer56023$Widget56023$MTDGrid$ctl04$hdnClaimID", "Value=11364408", ENDITEM, 
		"Name=WidgetContainer56023$Widget56023$MTDGrid$ctl04$hdnIsCheckeduserId", "Value=0", ENDITEM, 
		"Name=WidgetContainer56023$Widget56023$MTDGrid$ctl04$hdnAssignedToUserID", "Value=58528", ENDITEM, 
		"Name=WidgetContainer56023$Widget56023$MTDGrid$ctl05$hdnBillType", "Value=2", ENDITEM, 
		"Name=WidgetContainer56023$Widget56023$MTDGrid$ctl05$hdnOriginalBillID", "Value=61726885", ENDITEM, 
		"Name=WidgetContainer56023$Widget56023$MTDGrid$ctl05$hdnClaimID", "Value=11607987", ENDITEM, 
		"Name=WidgetContainer56023$Widget56023$MTDGrid$ctl05$hdnIsCheckeduserId", "Value=0", ENDITEM, 
		"Name=WidgetContainer56023$Widget56023$MTDGrid$ctl05$hdnAssignedToUserID", "Value=58528", ENDITEM, 
		"Name=WidgetContainer56023$Widget56023$MTDGrid$ctl06$hdnBillType", "Value=2", ENDITEM, 
		"Name=WidgetContainer56023$Widget56023$MTDGrid$ctl06$hdnOriginalBillID", "Value=28756144", ENDITEM, 
		"Name=WidgetContainer56023$Widget56023$MTDGrid$ctl06$hdnClaimID", "Value=11993699", ENDITEM, 
		"Name=WidgetContainer56023$Widget56023$MTDGrid$ctl06$hdnIsCheckeduserId", "Value=0", ENDITEM, 
		"Name=WidgetContainer56023$Widget56023$MTDGrid$ctl06$hdnAssignedToUserID", "Value=58528", ENDITEM, 
		"Name=WidgetContainer56023$Widget56023$MTDGrid$ctl07$hdnBillType", "Value=1", ENDITEM, 
		"Name=WidgetContainer56023$Widget56023$MTDGrid$ctl07$hdnOriginalBillID", "Value=0", ENDITEM, 
		"Name=WidgetContainer56023$Widget56023$MTDGrid$ctl07$hdnClaimID", "Value=13504276", ENDITEM, 
		"Name=WidgetContainer56023$Widget56023$MTDGrid$ctl07$hdnIsCheckeduserId", "Value=0", ENDITEM, 
		"Name=WidgetContainer56023$Widget56023$MTDGrid$ctl07$hdnAssignedToUserID", "Value=58528", ENDITEM, 
		"Name=WidgetContainer56023$Widget56023$MTDGrid$ctl08$hdnBillType", "Value=1", ENDITEM, 
		"Name=WidgetContainer56023$Widget56023$MTDGrid$ctl08$hdnOriginalBillID", "Value=0", ENDITEM, 
		"Name=WidgetContainer56023$Widget56023$MTDGrid$ctl08$hdnClaimID", "Value=13504276", ENDITEM, 
		"Name=WidgetContainer56023$Widget56023$MTDGrid$ctl08$hdnIsCheckeduserId", "Value=0", ENDITEM, 
		"Name=WidgetContainer56023$Widget56023$MTDGrid$ctl08$hdnAssignedToUserID", "Value=58528", ENDITEM, 
		"Name=WidgetContainer56023$Widget56023$MTDGrid$ctl09$hdnBillType", "Value=1", ENDITEM, 
		"Name=WidgetContainer56023$Widget56023$MTDGrid$ctl09$hdnOriginalBillID", "Value=0", ENDITEM, 
		"Name=WidgetContainer56023$Widget56023$MTDGrid$ctl09$hdnClaimID", "Value=13504276", ENDITEM, 
		"Name=WidgetContainer56023$Widget56023$MTDGrid$ctl09$hdnIsCheckeduserId", "Value=0", ENDITEM, 
		"Name=WidgetContainer56023$Widget56023$MTDGrid$ctl09$hdnAssignedToUserID", "Value=58528", ENDITEM, 
		"Name=WidgetContainer56023$Widget56023$MTDGrid$ctl11$ddlPages", "Value=1", ENDITEM, 
		"Name=WidgetContainer56023$Widget56023$hdnPendDate", "Value=", ENDITEM, 
		"Name=WidgetContainer56023$Widget56023$hdnAuthorizationReasonID", "Value=", ENDITEM, 
		"Name=__EVENTTARGET", "Value=WidgetContainer56023$Widget56023$cmdAuthorize", ENDITEM, 
		"Name=__EVENTARGUMENT", "Value=", ENDITEM, 
		"Name=__LASTFOCUS", "Value=", ENDITEM, 
		"Name=__VIEWSTATE", "Value=i8b6eDpFGw8NYLBTXYJ20+fF14wY7S011jEvQPP9UJrHBjqt636Z4a7RO3fZMXjSqDMHLUpe97ILpCOcxRhh0+vPmAgZc83bZuFPquKUnnPmlHKG5VcDxnu4zaS60v3A6LUMJOjoCgyNtacVSXSdI+iGpcMObCB/DiFY8CyD/arxTZnedn3uZx37+t9neS068qauf/Bm/Hmg9dfqyDwSCok6X4bYhQsCaLu163q06HoOcEDXEBecGw0iW5EFUVAu16jTz65LXMLH+T9HammVkOLDGUKGSJIiQuTt/hDT5TBMnb8IuD+Re49TyjKS0OmCp/mnYxJ2BQV9ZFybcWIo1BYoJiHxFdi4s66wM27hVvFO29Hv0wO4GxPed2zHRwtaVAUXFRnDbWNG/JToENhkir+6sQuOrz7tpeMs8MehNNN3/+fQWmodob0Wa1tEu+"
		"a5KfwiXiC8CG0xgY396bgfqKXT3RoWqBOrOW03Mz5NUcdtKSumQxi+nfZdAlQtPmxv7+KZd2P9kZUYHRFxoh2B9sS2SX+PpRx/m5ZdrowAOws7/NTBglWDTRXq7odOkkMsyBId1SCcrjiacu5SZovqVjyqX3eOYZLvQdHJnwH/Z5RRgvOX5aNRD4rfGxKTIR6GmDogm9fsNbnS8aqim1lsx7J0ciF0BgT6kWXnO5wPQUoE9A8LPEcrdxkNWZY9hmdcySdGRrvzUF8HZstBQSAkLQ54WKyWOTaA9wWP6m866R8lZoYkqat5jVR5b+B/ReTWIXXUq+57Lfq0FSc97q46yuN1vRKhXjOnJOufiUF4XhgVz78WeUnzFdBaT7XGlthoR94MOorTHEOVo1J3ssL52prySNs0fVsFveIZbAJ0rldGdGRdwp6kauO+Ew6wCyX/KPMtvOAD/"
		"VSXeNkpXq4QHUy4Gtzggy8dH6DH5RhNvOl15KZVJqSEuUJtkY67j2LMYHrer/jwqUM4Pxx7wqlxRv/egXe9hIPuDyLLyziN5qqtoUNWtdL6j056fVlZaxCocxhZGzcyrsoofLQljebsta5z8q9ymiO79C0Vmb4XqYVz9O9DAqWKl/Tlg+plbAhjoiESS/v5jHhgrIFRmBYnutloMjj58iLCUOFwjpfKt/bijceeZod5IXZnBd2zZvb4VtvC/tKqgROjPuUS8IJ+AQqa+xkXxu1sWdR/vQPbEInyy2/F191fO9IOtxUU7JWVnCFRwW8BQXRCizc4ljiYM5hjoc3eaG8NgfZjMaxrWD6DNYgqIUhV9FvZeB3r/LVwtMiiii7Sk4VmDDmHdPdARKrSfEkFZTbmhxvVT0NpF2R4y3PDgTIyIQ0cQLR4pFoEYitqGZSRl86TkQfFbgKUDYvMRBy5eI7lO1RdEOGbG/"
		"1kUqMn8K4QvPvbOdC0l1qgb2LEU8lpd+KFGA7VGr/+ZUNq4MOxQ3zHYkg5jz1lD8+GAaCJ+wagzc2mAJ1bUc6RrYVyG1ohwpJMAUPdyBSrBGtXzsfKSZRWQGi0mZC2oE9DVjDPQKA/IG45F9ml3FVLyCv0o5C45NeIb0Yb9t++pqec5I7g59SPARX9W8Vjz3FMPrTYlFqfc4RK+rn4PaHQmeIotRF9mfXL0s8p92wQAUXBa08dSj4GPRcVWH9g75ZmY8CfVLRe+IZzsgug5SJmaZLCaoXC76qkbcpUYdSAvVgXs5ObUby/XFb6iz1PKL8zTwbeX7FDfsqsAscUohirq/Gzvnz16iB0/WfsEj9W2Bid7NvOUndiV+gLLyraY50kZ8OcVaMvvsvMZFFWX7AX8bi1B7tb1I0J4s1/eXQFszA7U/R3v02zEor1M8Go6HitIdKylCKuHJleuW0fYMPFfX0J0yOErrMUQCOeV+"
		"T4XAIYzyJqdSBDwkK+G1x68L/9tduRFAF07dcykK65Sncd85GFRhvgdWN8HKSfNMdrDuFzEXBaYDtuGgzIsNkgLOfIoLjPhNMG6r6wqoG3jurZc11BLTXkH9N0EBaEipdWfosTbH64wDng8Ivk7qAh2P//q8q7XR1LcB4GbxmJnugoOLpxZ8jgxAneyQ8R5THfyKC9UJ8BbsBO1m8qCaviCrGie1gEpUeMKB9NhpJ/8nZlxar8HQprYkE3zYOibmpcmA6RsWVlWgRXMgJWTb/AWxwc+q3UZehJZapWxnEvhCg0xSj2c67W+0/XpAmA5tSbqmKbl49j+/7eIwOvyy+NGq6fdyBgz8y+euqLi/vTOvJcycyfwMOftGYJvdZR/ErpxUFoJCNdD0pzRK1iYyDJNYwLaMKJu9dQdfisiWceEpu+q/btxGh6N1p+vUfXFPlIVz3XIjP+"
		"JWlaZ7cyOwuChaUYouhi1NAiQJ2toG18gPixc9Guu5iRk3ZBSmwWdN3jk24DUkYVpxT4P0+mba6nqC/EkMg0ldPv2pPBiP76iFR9q/QkcpS58rnOQzfpfqJ8QC5bOvRg5O/0IiuLvdyRbVQTKyQpExUp34hfIf5/+7R8dUXsb5bOmPg59Lhl5mTuAWmgUoWosAH+PwcnioCfbycwkTrTj4qFd9g0pVHfm8JJTzcc8nITlekpXAv7g/czFwtC/tENe5+pd5ISuzqDgeqTcRLIEcSjEbfAQXGqJnsa5b+Ziiv2slXjVCmUKCotUe2HNUFtHiyZGwgb+AZG9g/zjJNetT+fY08rd1PaDH0s9EyWfGg2ho+m/u0HCApfUdAIMwAtIY1P1Fty39GnDTk1iMlZ40zom20O+jOOc/xuk3XQR2o7yNDVOjTwF9ZP3tshvIhs6f7q57xS4Qf15LkXZGlLe2h89ApOPkUoqB9M/feL8h046iO4c/"
		"PkJRo3RYTVVq6WMugT0dCEhS6RddVK7oAiql8iL15rwZFDmO+KaRyuLeN38KQ3n5SnxIkFBaGjrazTpHQ8/FeyYImRXH9P7e6hHua+KQuIWUNcB6TRW8PWWeRSTrRaiMn3SBiwq1e92xFQsqDbmQvOHdOKtd4WjAiJXnOvoqnByFxWI5Tcy7kChPn4k+xFbaISrsA+d1UtrxBk/aWKVhGqJR0JJejJaY3x3DpEdJklkaI2Ze7aLEJOCfjR7Zd2MXfFBCUp5ccPCy8NtGRd28Gz5NU1jV9AN1J7012jzMzX+wD+xXJ0TF5FyMGdiCl1VuFDHO+ASKYhiAXkOeVG22ZGiQe7pitWL5KbfobE1zoOHXgj8P9WaHshpLtG/4fmLmiw3GeIQp9Eugy+45aQ0yN1864gLgISFkEXdaTvMXJUXLGk1169ydN6GMwLWmZUIHNtxl59dkakBK7f0IxDSuw9HM4cV2GoKgTqhxZwLNzF9nTAu/V++rk+"
		"sB3jooyyoD+nD698FiWml6sAU+EC4Ky7IosdQ0o/i0vbweGD/ZUmkaa4892uAy2GVYJDAkj9XRoMAnn8KG2eBsZCrj6m4dkIfS5XyoFIJBH+QzLmw6H17T2/DcMaH2mJFp8JPilfKTM0cPqqIGKeP5HUQ9N4i3in7WrUFb2W4rVvQcYdc2KeVMVaf8njW930t84dVPWRCYolDd0Bkd2mg+6F0O4WElMNGXoSkdk27V31kmpe0+Hsj8QNVPrdefvfQVc0sTxy7Lb3JwQc1C74H+JTeW3+RohLXviBHZOKHP1492saHqmH3LeFKvwVNxtQQyGxjDf5M/e7YS36cL1VXt4WfWrKMwRjXuWTHVJIswzbI04a8PeZUbx42XRhJqCEOJxyMKgXNqmVc9Sh/jWOgy7Vfr2Td+RE5lNqz9ekoxJ1hL5NxsKB5D0CS1/3tizPRko61n+CnrUaHmSMcJCeAJ0Lbj/"
		"DMJR20Ei8kuzmB9kAiA6curuvJVlRm5nqsh5K+EH4hcRgJOkixjfyCcwyfIfXp8lq0YeX/LwB5ccPp4ldzSSbpJsf5O2QnRNY/gaecUq4G3Wc7eizO/yEIfzgd3gWZbjmkzjX+/E9P8HaKtIAdGJPz/i2nk3BPBHNpMIIMGjRszOl3wdE/ysY6r/1YtF8VA9F09w/O/KyEEebs44zc68zmjMj3wpEO0KKoB9aDQAzY4uikZlUy4jrcTIROaa8psC7pN/2H0MRSN6Xv6mGmi1pZCL3XT+5Mh0TPCsWctvQ42zXIrh5kHUD8n3tIUH5F/2UsSZqE5uhp2+51zdx8StFpSZVH0vjAFVVE1yM2WxgMr39INvAKXw2THvKlwJUsVI9bBlFWr05rmfZFhvfMtMv3iZQ1pVAjNbofWHAf7A2+cZAqUCl/2tIi5YQnzaBhTMXmQkFIvkGogYoX7uuvLMi1yDrIDDZCh/v1R60FsK9gN/"
		"MRpVm4tjOfQUEnJwF0O2SDE8k0GPrfs9ijQKsjcJgClcvjvUUuUmvwPepQMXrPUZnC+6oeAAu6onjOEU0Z7Y2EJgQe4ZdzgU5SexVh13E7Pne4U64tFTs8n5p2q4PwE5GNjsswvC/bExKi/kUWFhoEC+/G6QfURxHeuulPDsP2Uc7KtTU/sSwQQhCxq8CFCb8NYj/O3RUraKs6vV+f8OtlOWNQXUBP42uAOuCbGERh/KmdKyonOp/lh41WpICk3h6Py/Ddxdik/UX8B/6ZftrJ/5PQGFnexVePQdAjXu7adSF+MozxlMayoQ/QF8En/2p6oJkNbIJ3JN/JUL5UoJZ6lBOtEeNrEIwUAl0TuDk/vi+1q2yb5oeFKbH/VxPckUumtenbdBB9y/Ts4wEy+xvkWSRiwyoMAQVVVgEQCFkUVr0jCfzlq9BdJH2WUxGHJ4VfSYcqV9Zo8PuV5CPYUZBJX+mZ9sCeAH33Z/"
		"ONrquGH6cjOWwCPu4MAWO74vd2EjK7wmPIAH97iLKzQ8s76CrXgO/+7FrtTFOiQzn54xMTyLpncqO49oVtegteLysSMmOwE3X0Dxk9gs/ukXJPRb05LT43rbpK4K9cWOHHfZpm/HpMt/0g3XxxJZ6jaIK1WzaHUxQ80+MFaOENZ2zIAo2jSlmN5CVTRv+FhHW6qRUzOacD/NQqT2iQqhnWg0YanV3QvISTQj5zKNfAgkph8t7OUduzsBuP7QCH22vVb9y0VWavcqZop0GjyFi8jr0WweCwj3sPl+aPKbZycrLCbSFPsLpzvFxlUb7xOSOFDCk5FmEWF1tF/zQ1dTYgaWsDIy3DCZgoe1Q0Seo2qxQy9QUvZ3jpg0FL73etyOCkl+uI+"
		"tI5pLBcIngMwfTz6hRG7t4lgSCXxBYn5B53xBC3ygXY8WQev5gCGFXpbO3uWiXd3SQdC3iaFWOmSwY3LI7xPdEbC1rJgr0IG20lOWpvb0UPd542lbnZVytgGDfpvtIhsVv97ztFV5g7MPQBFlQ2DWrMnMZFYPtWsoWnTMsskrzuW128unnE2aEUKAGSPkSUnCOs87a7w4ciC9K8FmjFZl+fiVztt8LzOblgPzkpoOIT3wI1+dc5Rf39jVZc/+Dw4wy67EYs/jT4m0OceMlg81DQLmkRXtSx5h4ZWB7gNIEXyHCiHUX+fxf6J6crmYPtQtlKnN3gA3u0Zd0hlwM6itpxq390cfK4haSL1fv3FqZNVraCHIuGr+WxAxLtmaEU7C3fiSnhfoT3uCl8SyTrWFRaO5S+6CPK56A8lY1vwC0SYIdGmhV1SMT5OaA5PhpuibwjIWzk68bSF9QGoC9jJk5vWqAfCr8tjwn8W505o3hb+s76Y/"
		"akoXWJaTUJHweKMavlCt/EvJea8An/SDV4nH5Vyhiozge4WwFX0YLI2WCfhGvxklGrP1lcaBaNndu4d6jMbYKK/FFvAtXFBCOIb4oBFVlkLyB4tE8hqJvSwqrg2OBbPNKbaomVlxlpA/FrR8LHzq+zn7TDIFKpBg7aFhxPBwXkaFp2wgTNAqMc40H7X/d16WlIZLmbi6r/rlrlrBH6NGNpgYq1PcEa1/7cz3SIY2PMxW9TmdKC+Hz/XpOZP2CdMP1mIYUf35jaAHPrWInfCNvJ1i3btYYeBKe3fY27bRrkZuqRjABZP5CTrQ9U42fhhTTuVigP++D8vyTEGEBCgqosx/Ma/Pfnm+1cqbmGf5eSXZhy3+C9WOs520t2DI0zddrPtywRg49N/pkv5ZPVRr27b9reo24ti+"
		"404l6w8bJGae4KX3b9jAYUwntmy0Xl4DQ34ftmIzZsajOVQqVM5XHakqWuvEIashpVDflXxRCqxnwIIvqoPGr897u+p6Jz1WwI/GC+G/ARCnFpQDz2mmSw2qzm2H4uMkICCufTwaLlj+jKNvRusWXlM3EDqnvEVjwq5fYk9eWheQ+903mNgZJiMkhwjyQu8QrEI242oCLb2RUIqZE28ZYA17ZN9lWbV+1QP2tT9O0af7spF4e+ipMR8g17/qWRF0QEcUeQgyjHEbDSX3CbRFVTfpoNX9poVxNaLeJ57iNfw/pSgbIF4CKAFXvIpH6zu5hOC70lUPoYE3MBgWDj3CcqxIp8ZUSNJu1wDHMJ88ak3Z874ifotXkQ3+cibZ7TXS1IxQ1FKeW7mTCibKVBI7KlnPuva/L99vXPqLAsTG2OmJQ9D8zLFWTO8FnncBXBkqxj5C0qzeIFQtmVsZcA0pqcHomhblBBpsmDT3/"
		"Kv3FP5elBdLJFAV0RSXYi5u0ncdTR+6jIkAkEx2Jx99UIPbZv5zZYpKvDN2194+MxdGX3BQsr0g3n6EN+demiorWEqLohyknnsfmiMBNDiRAlaolS5C/QCu+xDgaqdB/xnQvaHH3/O9B5b4nkVxVEbM/e+nn7vx/2kII9Q1BUjhg29TJYkp4k5vSEDGxzXq92rqsi4W79WXKDfsCQK7eyI4WsN+wtYk6J6/iuLGK+L40s9RAYLFby5ofaTqjS0uN2FVp2F0hxRoFrKSG+ZHnLs9CBYGNjvhx9HgLV346WJJ26iS8/NZI+6DLBqpnhzw+1yRhm1fCqjuot8emdxGfStLvFEDyvQuPqrR/+HCRU+NEZ2x/eXdiH9wH0FQxS6jcwsopKWCnsbSN5ycrfeTkN+C3HckNqvY/1CgrKuLkClO96sAMBI6VSGpdQhDcRIc2LqV79iEQSc6RiqqLlvKMaSV+"
		"M2Ko1h9zSisdXOmqdjRnEtEoOk7YyiY9aKtwSVOoyFjZNJMgP4QqemcIkpuuftnAspGe3Jkkm+y7Y21oVXrbEiMOSQDffw/dwu2BtyHHLQna3kySGulWUK2lSaAjGJDDxEycwFd/L5HRYAFR/mYsp8iVv3eVkcbvAKpuUzo8wkSpedTaALShCJvP2sGr0A8vEGLV+U7+AK8zdt9kqPW2Qm+L7UIQC4fm0Rzuno1fsrzzbVhwgwJ0D6UbbSclOzpMDtlXt9ufDELBJPK5/wh30VrtQIarzp20RRbmtsld0mNurL880lDz1XJEzJGlwCcQ0BbDJKHC1F2GGmfwhD19MyLZGve5EH+nRJ8ayGtsN9iNsYzJCZjLtYuiTByGR8fqkTenjbshODr0j9pgIRCSEIZ/gcUc+xIf3bYSKCW/jwNzSL1EAoJScBVrsG0l0lSVBGDC7mXhS1Bn+FzQ5R4Jn+LqR35Y9MIomT9NhvX0vqClYrKIj6U98/"
		"x8wd5ZraNyxYFzQEXqP1U9RSos09lIqUWQzcraZ+xNXx36ZEeuBq7LeQJZKFbTP2pAo4A3KWGsvzhMGLCO0ddvx8HQcWyFSfP/X3KYyKM9HSP6DA9l1s53qWtKIBsgjwlrHWJSqdLkuXCxXxgyUxu2I5OtFLFWiRxWnWnd4JceQQCZGcRgak45dwnQcbKEe9EAIC1R5eY3zXktpSob1hYov4dWex1wlbNJqE+CTR/p43lJLBGsZhRNlAFmfzKC8yJCbjylEzARnDQlhVP23SFuW290sekQoid1zSu5eqj72NsxiX3lFTPYASSUlXWZ6Ra9fdqN/Hv+83v1cO4sTkRs394Nr+/4u7tRXXFAWc3mz6k9YKlHxNIPfBuuokGkFEn54mrheiEi2l9FgaAww1YAJuzsnmMT2Ks6a9i03Er9D3PiSbjm7YI1w0i79OT4Lw4WK7Yp++9Cz2RbZfzYGUSE2D8pdEo/"
		"iGMFMfwST8SvFc1wlUr286fNLHyK2hx4DxiLTT7dNbLwPQYlR+GpY8yEW3FzRzw5T8xatrmmMyyhVplSuNuUBNcIwC+APc3rKSG9Y365NMiWCgZx4NEVL+/K1vz0hPqxQG4dT0RYAc4VU+f6LHvLBSkk6w7qY+KJKoaZfD2GsukSWZF76FKtVXXdTHoQNst4CkmFjqAssQ/TIZa4FwlIWsnMOrXnsv0KaOoCjVBJ1YruarlmWYmLjjod1siS5rAiistuSIMLkcsyk6UhZZBRSDjKLmr+B/FfUgxF4StGb1EcTxZRJMZOn8YH2S0MIfFA0hPTiUC5K8cchLFGN0a4P0phnPh1KEuSDhSkXsh3TMIx1ufF3Su/G1H0AUqqYjta32xCx60iBj43sMjFjB8uPpdCi/"
		"G93am8BzsnFo5RZsfdiPi153RpN0wRwc0BQrbh9qZ2MmbSGEt9Rk1GIb2AHggF2FpL3rzZc8TobpIZPnuetkxgV3nqPH3f/GYhfBuTRgCjaVlR5rXJUc12peEfefx02uO+kYBPIx3BZNNTOOyCEZtjszVnO4+aZplqFhIscHL+x9Hdg60ZpSJ48DGCP992SsDwD05+3+ldvEfZRfh219yBehNLfy7vkVSRfyM8V+YKNCKGD1eUZbNJ5cN14WwaxkTLd9Z/kHxzgqIU1SM59rmGugXXIkvySwuOUrLFi/VC4WhVfULzWj3yQbEtI9wMIbf7S+nAQjj9wjngKSeTDXU2ye88nTjt2umkjDQaQfAvVbHkpzJQSkNKXt+CFmHQ7jDSRAv5m+vgw33zJK8Heff8sRGCD/KCAQvrIq0rK/9bAec3jRySrBMe4piXpoujxWzSXjgw9kUDDSbmzvi5gE9egtzBhDezIUcVVzsV/"
		"K1BgXmZEr1KaeC8YI5aqiB1InxD1HcA2bBj7vstghZHFdiJzY1+77O0isOD0qJMqwQbH8OSOTlyud9OrolxxvfFE+GY04fK7vtukOUsua31BXyuTxhVilwPdWQenwE1zen87GsJpkMFdQVpXdLaaf4I64ZUOXrqbloRUvxsqVObAuV7AlIrddHkEBjKJbM1n38J5S0zC7HJSXBZiCeS86VzkEuSXGDwoXhtsIXkIk9c9reYNU2asmyIAbbXOKQ7cFlY+BESRxjUwriPLMeMDfVirw4D7dhMWYnQPc2Z8Ez0RyAtYY8Pew14HFFjajhGWm5aDuPxtnZn/lXK0EBBLTPYzVANo4G6gtrwZWTfjyvqsERdCUynyb/SaPmoc4VPpeBiAR6haSoK4T7Ojln9Y74S7F//0wM9D6uBaryrgvAYDrFBB1WhVvBhN417IQfl/NEsjhUB7a2Vvjsz1oCBUmxMmjTfv+"
		"xwwk3APT4Lpsb1TpnCsrEs26OTCQocD984Y5AMzn1dz7eTp5vCtONouFqdd2XCEMHfHoEqs2yHNjpaPgYSi39Omv+FiQPjFQ2SjAywbrOPwYek0zDBACC1uNXy+vznsiaP87iC/OTvBAkFtuz1pW4UlibaMyyccjyz9hziXEN6Bx2GsclNDjhvBegO5uky4rLlQgBUdSoe+M4ZASq9j5/eLlTYOpbn95/YaMAZwr5/Fq4W0MnJCcroWmRg2aoW4wjyGuk8Fff0vu1C/EuFSIYZD79+yTUKF1NsT9a6VD0G54gtgsAxtevXQ532K4lEyQBXJ3Jntb6bEqwJXsquH0Ki7N6dcZXWxMp2DY7vceQnWyjC96goHxJaZZicbYWxD9UcfpgjZH3kemY7nDdugcg08H8wyqWSyiS4+fqcLdAUBK2KqSAvm2Vae1erv77u0jztxsQ6gwz/SOEcxax/0lizs910gtUUpdkQM9/CVeSL4sCOT8SF2d+"
		"z0YGr5ehK1QPjXAyYtIklmn5do3AhZ0jnWXnJ+dChq+DdBWQRXppLnQiK4k+d4iIw6SQsEhGOrIAveM0ksozMmyhclgAyEV3BaYqXW61aRNi8IbLBkHnzwAUbyCTHu+YD5H5Nq0Cr8MdfjaM3wVFt2jvJK8t0PoXbP6NJPnPLB0GH+RGMmDgSi6+TXEWNMV4pY1ce/DrOZAxd73vEUEgFQyNexKcWgqQoj2PShzdHPEZcg6I4qK1ZVIw4qQR1f7zLChu/fYIKUU0QAEUWjKkqizKzs4cplpeKt5W4LPHhx74CCqoBPJgnP3Tr9w39qPBLtTUqMBTSbIqW5JYQmALL9iw75Z1PaCYmoHGzhV2IWZo4hVCr0GMWXhex4eKWhnWZNrstqhnP7hMPXcpAT10h6PhvSeNs2NZgcWkRiwoty2v5EGsEFsdfYYMaLNvm4w66O61ckgA7fbEdMw7dIKX8VZ1QiYx8ENeMvM44wcK6yHuGG/0/"
		"cWxn05AHbdxQhlcO0cfRlguAdaIkCgMzU+RLciKh5vtIyB5VR5HFF4l5Rn0Dw8dZgwLyrTj3v6RZVt9O3cNxvOFOF9sPAFGH0wx5M6Z9YfSmx1wFQcTRwcUtpJZXBeHQNx0NW6WLF345w7zb8i0WDiLj0HHdizg4oAFuoSYTpJKN4uM1UipC1OK5EH7vxty1qSz/HdUrxQDaAJJDArXYk4akeJVbPFc9lTQWpUqzPCpgNy/FV8wmYOABl1Fvt1OfQvj3CDGBoHvjwgEk/tB21KxxIsivrKtOdIWXPjKK0E8Edv/MnPrJjkbXVd697+WeL/w/H8I4Svtm/r3zMAai/0QT0wV7aYXLn3fsqe6lbn3iVSSfHziXC5E+rYqndQoFBDkfK4ynQutx2qYWxJ0aEmxD1z7I16WNHjRnleGyVvSqj/VuF+"
		"mHHDp6wasx4LYQ0ZrsttiJVmhSGkBN8oVyvAPTtI5Po3xZX8XIKLpZIvjbJdvAAhVfzp7gQzOm+fXOgnKj1NhEXsjuBTke7fVpHfg7r3YNHFGozoVZTSfxwWFEcUp8M1JxR1azkXvtrHafkhLjoEIIohD6eKKVzyh1iZ7rMmq7VUQgZ3OMs1l9DwsFl2YhoLGknj+dRhsu6YjuVRjq0/j5+SIT/cfrEDMizwPaYXtOB+guZc/2DjAxp8A+tbuCuHDKAzvQjLYMcnICb91e0ZiBp8sMImLbZpxifzpw2GQnKsJL22uE/tq5l3mu+PUfmUriuYBq/g6CgUMvbLh0K7MCUeu0IdMPv8OagVfXFfYlXPz1oNlD4cTTfPn3nRpw8+a5J/PA/piizO8xqoPvs48XS/KV93TFSFBULFQg/PGf2LU4TnF5pWzPm11WPvUHklsgagC3KrtBIdkb5iU+Phrmb/"
		"tiu5HmCMEYA6XpqvCJKOKFCPd1pZ9Ly3ZpMLU0DsbHxA7ZTJwd4JOU0cVIM+Vi5bB3NHP723Hm+td7PgqvVpTQVwYQKMbdtQTR1t/WpS80HO7ADIjhrz4PxhUCDgeKUJ6Ij5cc1QvOd034rd4UnQNBLkP6FQMyrPjKZfcU25FJsrHB7xyFo7KgubGzLxe0tyidDsZ0H1Ue7CRgtK5G8rYvU/ZcxroAi9VqPgrxRIIAmNIBHbs+Xq3wnLwffkZljDHZPxKufbWHyOptmZvJgata17N9mXoUQt4Qd8tXYQaUAhFWIT06uadzSLc5hKgaLX5thU0AdyYr6jzXhlootso8c1CcrRCD9V8AqGOoTAy69lqENmDm8hXarPJCDw/fHcZUntVLazBgokmVoiSaToU/1zbUtglqyRQCJhxLx/"
		"hqm079D3q86FELVdGjXHVOpmtONWbyR9q6QlvCdUMO5E6KxO3GmlkvqeStE89GGU6d2FtRqa3GOUcQtHSm8qWIa/YHZa5jChE/FYIyPPeAk97tHiIOa8ML7oGc3bia1U6rjaHFfAlmuoUBLAA2bFeo0pKkxTgAC80Kgp/NU0TJ7M22fCIpjvjaSnMieSf1rusUlYuJDO9hK4yU2bhSuQ0bh6Jpnzal7z+L+dgaOTb2di1RhxSZRXmsnMRquHpRPSBJN1+G5z/WRUHWCRzHToRXmIYhnaEGixoaw2wLBgzbSmLZ13hpCMXTY9GlSdY4fWFjb2SWIkVwIm4wxiNDBZ8bK7Mw/8BK5sHGoU9IHzgvM/PRg9CPuXv1C84NWa8si3piqYwXObkwibTAI5zZZnAbwsBnTAH/ohgUF55q3GrrKHnFXUVrS/YIHvh4dxByzeCHTuEC+sS3Lli2s/PgtBgf+"
		"w3Nf5uEOj6a8RcICZYlbLvhM8ZxVcmG3bKWIylK48dB3Q9Q68YuI/hg0HL7wnDFi5Hh3Znw/a5sm27p9Adf2FbFfQ8slkJsv8iN3cWL7KPgYNvt045MMXQInvMkNQr/oBRc0LotLsJNpz8zskae/HXy34VgNeMvFMyu6qPZ3u1fB0biOT2azq4qaLiraP5CHR32W6zVu9jq8q40wgOAXxhvJV4hPlldhzpretj2Z0H3KJj7qgPmHn3Rxgg1U9oTGlPrVU/UhbewHB5nEJQxswwxcCSE+W5Wv+4WyRpgRNVkemPpHMvwyVmJADlwoYM4EjyymFSQd8mRFZrAZTbrr0IZu1A1jVipF6d7H8OeAqXeeUm/6o4FoXHltCsym5KEVmHA6aQCfPak6qFG00EXHowWNAJiDEmRb+nhgeeTCwj05p9otDD2kExVvVJyl9QkDy8K3JBdUvcguKz6mz9ivuAP4T1+KxUKSM6T0Xe2IQVL0rKM/"
		"2UDLTSWfYL4OcQsDcCKCUPBMY/79ITz5mB9ZQVtkE5VUZ03DRN/28LTHrYRO86r4IjdZlC1ouRhrQU5pc65Geb/t7hzF5jodJ41g1ch6K0rvvtvOzvp0C7CPS3UpzTt4Hq4Pg9xErViWEIeilzmJ/K4JD4MN3ME0S45mowJXG6H904nJC+JCb9wyp2fzGXZe/oxouMri6Hr5kYBaDIsGa8OXgqT/eHnuM0XTAFxQMisXvY0dgNiFIVMSz29bStcJ5WKGPzlRsR1wk7XTwcmZ6hzCJ3k/y95gTJL9pI/EsSIwr+wgUC1SjsaYvoyxCPiV+SPryQrqhJSfqzvioSq/6IEL29oSLe0B024UuCl9UBXGmmuwj7WdB7Dxod4Xx5rhJG7N+twVuAe2yZDsaLbj6nsGE3w0FjInf1n2N8/+zTGkBm8hNJnuQ9UdGNa1AaCfglxZY2b6to9wxYb4Qm9w7pgvv7nD9u4ieRbcZWss+"
		"ukeIaA2LhgkNpHaAXV4flwW/QWUiPnBuBzq10PEkgcZZlcJH0pUTM5CK3U+I9grNwNMEWo34H+/KGL1Yjmg3k/BIhjC+U9GYh1dvQvj6fzghxmkDsAeoZCbyZuokRFfEWyPgL08PV0V7T8xj64bhZab+YH4wenNd83sDioYJTj+o6+Pdsd7fIkQWSnMqm+P3iCw2O6/p1doBkyX0kuylxyeSdl5iORcWsOuNLmElTT6n384I3gUCaTx6/uaFvvaIMYj9i5z6u+NeCUWARwKTB0ilBhnw1u0kKpsUXSgMqDG1c07jGKbLPgQrSKjie4faWad1EJZ06VcoVLHz1FkiUwY99q0ntnZs6huBdXhHl1WINiiESKD2O1KQXmwWfIma/DDQ9tE6bJhhdpM/IdBAGMSkgPN9EtaQlempcsonNVrxCngDC/3dMyC7KW2sev7Y/okc6E6AL2Ih+"
		"wGd4PZgkbjzHFcEq6Aim5e5AzOADvuPfS9bW5ChRQYv2ONPl+ps/4oodTXVEK9XO3hV+NBK5nqh+tPvR9L4UQb5SSKngusZ4dxYc0yNxmauGjso4PIAyF4Kb9WXWZ5gMyLj8U8qV4ba2mfjzAk4ktotVtW0rUBYeTDkptPmS78hLwPF354+GfXBZeC86Agdq/rYGhnwcdl66TroFeKBBPuAGl+uKHbCy4cODdddU+qZg0LD0mNRhQfbkUKC4Zn70lf7rOsOKZZjU041++Jp0ZC95xwpNc8sgYFElfH7SOJs9zRcHAXkjAPzhkjkUXObYym5D2Rl07UbnT5sCmlNmmZS0dT6btguHUe811zr+6JDRf/fycH+f7oJi8X5agoYZtKrsW8po+UKOmcNbidBVGmVmBsFIlCGDmYYhy2SHk5qFsq7jX70P0H8/QKaMqDa33Yzg4yZL/7hB/L/8/"
		"deVH3mbLlafGOibAHGl8qRTOUMuQZ3gRpKDT3VOkS6w+dLPcJ93WP1XtyyydCvEGKSRh8A5ayxA7nKLQgvQBWej46nLLn4D2YQUstrdPZ1hBhZX75v5BZJF66XGNnyOymrx7tU+aU1fSyaOZEasGhi2bF7eRE7S06igUKoGOWnaRUQBc+1d3kpEEV0cRfSM3Xg/sL22bljZXGuWpxlIET12zD+piaLUBEk+3Hc+7RkVngIW5g9aEL9c4StAJd1zYZsmNNzh3eLJNZbWTGbTjP44xy9raVSKbWyBw3QRRM4PtJQxMoMvAG6w+/5kJ6Yfqmkw9UHguPAetoHTHGhy2e9sHalOg8W+4XstHHpg9PVrE2LlneR6bW4KvleIz7BTeBJQp+d/JwBjxLzPVRXfYgBqxOdINVmUJZXdDsynaPeEI3u5DStpW/VnQDf4TmbAPZKGrsUix2bp3JPYJoD3Co+"
		"9HXZA9VNuTJ93QCfIr8o8IKjWl9fZOSdyF1hdErKpRP3yzjUoAZaIBDIxH9txhMmfo/GDVNl/D9mq5HtW1R2rUnB5CALcyTwmdP5CYNy1GxEMuELomsDth5r4dfsUHpIXscYQq0Jo3VMvjxs7XVXrY+YYm+C/96oy4Pn/WXGvsgx9OR4C+NmycuRmgsqAhP6qIhGn7zdHQqblAh9DIzey+gl88Lz9JuTTf8WVVqyO/JgSAoInWTWFUCBnub6erlW3EEVX/QGGnALgtQmsHtxG+Vc/peDYudfXibEqpAgkjswxMGLCbQc/BOuSbsWJnwlQjSd1R4pGpYLG0zQc2DEKTfeiIO/oFcMYUB4LT1vt5PGA01nz+nYqSdQXxc59f4Iyvpw1H4tdIVDD7fptJR038uwBynRAC1+knEka3Zq3pZU+6pvnZ8wdniSD3dOg+BBLVu+rLEVNM3XhjO1mNDd+"
		"jTZsNt0dLxYiXpSSLI2TwSJMd2HPvj7BjuHfDvl4Y27b+br3rk4lKaocL/vh4eah1ZEPNtPWB3q75GkyCFkPoVSfkRyvosooudXhLwOIE6lKImuVm7//Km3ARUwl52m5krYkV6MWEt9BjZ7JojmlAMyoRp7HU6NlUhjw57M5WSTOrX0KatiSRHA1dr/Ywt9AoZ+WFlDazZkVGZvU9nma1hBl0PwgRTiNROvhQBl/eWUx6BAQBbbC0NaHirCMsyppG4gUMOBt49fLFYXjhziNEgORB0zKl/caZ5+JSohnatvqNxXZcSI+02irOiGKNNPu3rfPxD/li2bCPGHEcXnhtLAhdZ4dbuKXbUAxt7DTrfqpGf9lyRspFfoT/ULWgBDkLbCjpy3OMfyqVlBF1IGqgsWEdRP3VbD0nLYM97eUdERA+x4DtG3K18Z0tIWKZTf4X2QiIePN8/"
		"CRBOeQZfYE5xwCtIZZjrWdFCrmtBP6vsil7Pj266sDfZjQzj78wPDReEQRlh2j1d7U/aGIt2B5E3M80r6RJkA5zjbcG2lMXbhKwAOTLJeDPSZmaTvi/YmzA6r82K20/xmp2p6ElD6LSnQa462ogo3ib76B6W8xpHQOuwX5oxedIHiUBBagZTkVRTmXa19uqaPQH8SL0zwjxUo2tuDgyIsg+LV74RZ0uElWWdEHnpIseohB02CdB8bdxGWKcNZwig0PE7ZBmLvj444Bx4CAf1zcI7vkX+6w66Cwqa2Sqz9E74tZtaDeTOTxT73kzwwwNNg+ZNgXoZhtuKAxtFbJVuszNw/L4TMSNaKT3sQtWfQgXemSM+TCwCer1RZbbMISj5SBRzvAH61uVnz2jt58OB+GKPQk/KS5zWg2H8aJiMH9K/YNiSPUI1vqpLzKWcf9m6ZXkfAK31xXv/8e8acE+Z0ccoQsGE17sCNqNA+"
		"E7PSRhgWMrDAFtsR3MNFVptcXbmzGYy1EDxyx9HPmCWYb12/mEcJdS28JmsdWlTuemtL+8QX3ZX2bzwasswx5JLSza1w+Y8MSCnMqWKumHNjuafbaDrlbyjPE/bETvyg5L0pjpyy2kszEsTKUV0tLXz8l5+kakKaSQb6vmgn+tdlN5p2qedOZtXz7/Cb+7c4MRlh9TMn8MR07Ta2WXoLAVBYO5/UOGzJFo2mLIbRoRtczVEqqWM9MlYt5gXsnYKIeDWElaoSfcPuOpKr+M+MStw2MiMrRDvLFOKZOGAmVYE+t7bHvSWE6UdzG0YNNm25/5K4AyoVtIg85aIolT6IWJCoMPt6wJx/RR5zmCn4MNtvEPipperK7WoJPFls0wQ3aJe0ELXj8tB0gRs2hrXSQGkj8IB1LYy+AwCCDpZDlTNxAIBRAeTLdJ6ErAFmjM2Mf9TcOEudgYZf/5iG/NA/H2F83PtbLYCbpisu7QbXzy5/"
		"DN4coTxgsW1oXCD4tHlnAe5u/R1LBuV6FhvlmWzJpgkxLeb60ASiQ9YntZJfc8iffjaPyfAcx97UOYGUeNittLU5RaiFXW0pj9xmgbC7SFqX0g5BgM8LmYrOkE+6eJ7US96FQIeXn2qUqpguUdq5WwtD2BvUfzZYrT2t2NSNCZLjIyZo3FRz6ZMfo8nqw4i4deUF93fc7HRBG/7wLf8cstgN8f7cSkmlJqVoTYHNFZaIVbbiOErSvnPPsEpwnBQ2FFkHcjfRA7a50/Vw7Ad4hUos1I2AKRNqEynT2Or736XWbdSuT2cHCYvnuP3MMNpPGF1tEgGoO4Eg7bdWByd7x9dzuWXsTMlHQRu4a/HGs3CR5J8ZfyvBawXR95NhafaADQA40W6aMb5MXTS9RZEdKIlWutm32xJcGgOcn/wLlLwbYJ8JOPOjynLkx2Zer9U7fPcGkYeioBzqyiVVnEJ0ZDO7TckOZ7p/NZOOLEUAVWU/"
		"B2fjTY6kM9oLmT553Q+MGq1AjYVX4bd/1D2yjDNSZHrHjvZ/Qb6OKhYS5eIFmZ6MduOLq6mBzTR1rBlmu5jiVUEyURyETtH+wKYuUiSZk/E9+Wph+ZOPQfjoKS8v9uIRLSs0cA17oRp9SGZmB3J29u4nSMzgzNSflA5Lt+9WWSvoW0igPuOQFHC41Ern60dp7MDoAmsf6+ZpINQFLdsgG+DPL013h1EPkk5Mebf6bPllvti011qrRkzevLjfhQETT/Ak5/XkaNSOiA7x+DIZbyM9moFwylZuIjA2Y0VzIM8lGTAudprQn501xkFZGPflP1+mMyl1QXcGwocy5PI5WcL2/Ex0zJKPibps0rmUKTmc71rjWxrEvXZQpPavy1C20MltOWGaMST+Jt3YpMYaB/EMT6B0kmYQatgQFIRNKn3hImh0w3J+OMXEIATGN12k/"
		"e07gkVgDJEZXcHrLftEvuQPIUJ1Ku4NiuPXCxi5WUTYwQ4YW5BORDMqrNkymoqmYBDQu9e/ve2Pvqn/CtGPd7NpDBjz/n9XnuEtzCxyY7QgCg9nYJLVwFgElmMQIX5w/3fscUHNaVis0LqbwnApBms8trcJshCNVg1Ix9LJ7aRi2UiQ+37BO7A9WsxrlRSKC+w7QqK1AT6VPwuPYb9k0xrKGnP88Ex1mRZDQzDTO8Iibt9WWZAlM0KKE2qHoIZfv7/BFqPjqsdtjdW92p9VEW4AeBsOsy2Yl9ukvvIgAnOVjuYSqCa4rZdsW4R60/uZLmfmtuecle0Ttfqy5m+tBL0YHjTqJznFHpk7z9JR9PSrwiNbNigLyd0qtCHKUFwq1tcX1obQi+oQ8choXias7HOeOx0D55w8hNgatn55JM2PYswhMNv5XQuhOnIPZOHzhrfftKUv82f2SbbT8555kJ3hbqCroduVgja1W05zM6iOZhNXkG8+"
		"TeU4K5Ifu4Clli75DV0sctFMqvhyu7l1zHpN0FDPA5rWkLAS3MC55ifemOHyYpjLRothHX22p56ZkjlknSFb9hlh3fwNUNThYhDJitsILDFwp7UJq8BI3LJE1O6qkw8uBBFW4NJJZhZopseraqI9499tm4wZMylVaJluP/szwRmh8CoN8g/CpJPRk5wbYUvHWFY+G0/4rlRcrGS0oZ/r3Y/Q0cH7G94ZAj/e9t7S/dm0uCc4WWeYhkEuOw9S7NhMh3uvzPsHYEssw5wNcBvn224WLs7F3o+WvjhQ3WGgxKI+EG0mH7AFDsMUBp/xjDMG2LHkWRW6gc7y/NU2X6q9ysmCHpwZpsD20dTU/2Wgm/Xy/14B7E7+3baE4MPS9xSGLoli5aokqm5g6CnEZE61fAt+1lJ4A1tPHPXkP3BXrJ/+Jre5a1O5uhuF98WQ2HTquQID/I1wZYe9rlYETiQKh041+"
		"6wOnXlp2mNYjlNcH5wyu8BBAXi4SvOwiz5YvdL8hs5vJAlWiw7oQZNXuqSmkcetERkDgdtiYVgembWreDrvXrfCZ4IDtFfT9HBISnYLZGeTP/JDYHDNVYFGzR1qj2kogVXUYDVXL8bG1hUrxG2jbJ9dsD4lUSeP1s2cT683pmB+58jW95hMuQn8VjQwVwtKeUA5rluHUs98P78aufvVzTHeW3EpPqGA93qY3mwknnBl0ukj24/d7TW2VH99i9v06/+eN2ZukjFMJX/Tgm+lGiANGizMumZ6LIGMHYw3yU5GbU74eq24UtUe99myzwackxVU0+d8dtQoJmeztMMS0JvCZ7GXBodgdz932K3WhYRQTHKlh6V/kzhfnN/Es/y31QxectZPsNslm00Ftia7T+2iIwEXOWqts+DT/lFefc676IwnzkqzKkchqeRAr4N5zcW/Y5I7m7sMOH0AkEr0zPOKJj9Uqj0zivktSQQx79Q7hpOeHPSE8y+"
		"nkemT0kJrrXf22lIWKaxIblC7T74B2gSvHVRVL+uZ0LSkbn49ThdcGf+nmFvQ01W8+1pVaXJoRrd+0UOILQ3jZNZ309jEXu8xv/UOk/ZXMfnk2Yp/pSIH/xjoZpCDOKdXH1Pq+d8t62KK37l6U4qeGB5aMx4NHhpxTFDH1zVbTxfgxA+QxM81i7sOJO9bjdmMd6cE9u9C+YnxDfU1nkGEjg9G9btFDses4b5OLfPS0w2VgWwrJD9bA+fI+zWKKRZOoRRH68LNQbo+9x/pAGFapYhz62vmU+AK22+np0PgNH8KQd0AVZCVImKKLrqO0d0p3FCvpEe/Y98qrSUFd409R/qyyVuEje8Sn3qwyDhTM04rK5lWI1p88VmBcIuIw9b5bOZldLdMiR1u/8We9rNiMcWed4AYDY1mIN0Zh1cMVdpzcsbMrL8TVtXbvsrUj3pMemEEV1cEBPg2V32zXbNl/z9PP0qzevegEDqYz/"
		"vt8y99dbHYqzFC1qOZYY1m/ircNu2pTteoU2PdNFJSrpwXLsAca9It4tD6wnjYJZ9JntuWhbS0SVJrkkJ7GM63uuDCPIWvC8I3uzJ2usDsqmGY6FwSKYjHGvc7F8zil0cgwNWc1I/YNKupuinqKXYvmlSSCZQVQz+22cuzWWNwnDOS0oWQX/O9M70II24T9nUAo6UnEWDbVJyP97N/oRtdKXzdOzKrttmeSOzbo+w5pfQ9DxUU6gPr8evpB/hAYeRYgkYkrJS4kpDDCPQNBg3wsxzkTlbmFTvJlntCtIRMihej5RbEF/2UaF9dmqa4in1Sz1nLADHxIwHqwgfWxneBQKx19hTuYjxcf4CCL/uIlNoqLOKH+q5lmLmdw6Exu6V4gLFhXpd5SmovdomWS1AEfkHeZsuHccgnySMStU3IqBilhUa+3q5tuOyu2WwihXwZ4exL/eNYiPz6c+nSvhsttD9ut+jnB/"
		"uVborp2J2YNNz8tEEz7TxNQUt2sOa2A8yC+RFytlgnIaIVxuDad4vD/M5VjyzHVO0KGgSYPOQePD9QVNzlfZ+Y7yQ2J4RF1IIvz9ZqUj1mSB7OuwMNwc7kWvJ8xS9dshn4feaKMukuHxYUt/E6i0Ks8iwBNRJWR7MToyPKR06fWQs4MuqDNPwWBOvOZCivax1xMU9yhJQuMH/kD3c2OPuCjyeuoO86y1jxOKZncoZXYHxJkdkLRtBDzBuzhpMMj38GvacwA5ZoYyIfDwPTJ2Q0HNb/llJoMEwr8kcOwopNQofSBtcFpxWAkBPhEWIWWmcQrCyHn/a75Fk4NJYuNJ5CBBzDZTbMn0vtv1oHApMrmeyWz6EhfwuVWzwrpMAz50AqdDe0SrejSdaMWduqRSfthtB9caOOTTPerHkoQWU1QaT8R5dfq1lngZ8WLBLPfjI+hhMCW0rWBV6atOwZchSQm+"
		"R1o7xcPZZzpYPnYzTgmmfJuWUGRk0MbpHN2aAs4yA4+mNJMqQcT5AKL5+ynKp2NHc1pIar86sJnZWefPomYiTjiDOEQM6coK4izTputo7OK6xZrnsM8dPBL+tEGfBM1RbaiUTJJrVZECGyLztsV7478pOr41OqUeK04+iJv5fd0BrpVZUR59OAxz5yyUTpd5mv1hOCND0hqNc29ZwZbrQoV+XZBFgxYPzAB5OBpg1h6WOjzCcLT6jgHGXFtcPljGGw+pxHkOQHQD4OGZ9D6I9jQsE3t+Z0GLEMcJkO4uu2JAsQsc5bPS6A0qFyf8lJ8UMwb3Xh3IqItUwAwP1wltdnzusg4Vg2xqzkMQnoAlicMakOJphcDRidQi5v2chQxFOiYwa8l4z6rwUrnpKWIoESl9ZGIyBzud9WwrbjWoN/ACOGGbCT8JeO4fsycBH2fAlZkO70ygFb3THHaxf63/HU1ZwuBGAlSE2V08ubleEcevG7r6WOTf7/"
		"9UDqnM6sa+XkzwUBjkKahyC3IK77BXlxdnJq/z8TDnSU1sXQMMj12bhNuGg0Ge/AOsR8BesxuaFDzwIur1HJZ6nuborh8TS71oE70MprXieAK/DWJxh9fT2/q/BNNZQsehhoj2Dp1N7HivSoKlM1fVddrjZKegm7/k+IF0jPzXkKHZVelG+Iao58WEyUut8q0zffBvoj/xJWhQoEkDcS2rSZMhWHFpL1QYS7E1Bmb0bYotEPV6jttAPjMrO9rATH3dLBUC2JZ0u1wn5o2JF/iYI4SdaJFQ/dvPmtB7fZ1TbvFLXU8mBLo/tsoTnwkMFifJnEodlajQWym5JpI1W2ncL0qqu0KoJQlv8fwqFrESzOL2KSA9tJ7UmiA+lmANRSB8bXm3bMgko7JkcY2R7U2V+bi/zNO54WZSKc74q2GegG3yfBgrnQQb3HCtgb2/sjvRQJ/sGmM3reXaJDwvxDWTtZyGLi/"
		"z5LaPc8VTrT7qJbOwLR3MSQKF6TzQDgLb8X/LyLWLEaWBmAfJyDMir8Jo8+qCx56KDn/kpdX4yrNucIMbz0l1ef97H9rKvmPp5l6Co7MytmrEq0zs6vHJ4akSEBp4/B8q0IaTjpV78XM9+r1gcJ0W7aPjA91qvSgJ64axCuCimRfEINZH4+clfLp/IwxkY14XdBP0nbkQyNeI+Amu5gkdtI78tTQle9B678Oau3wDezOBne7cHs3rdj6qa3jy4uYpnfRRPO2hGEBYMDZzrcb1kFF6faId4JhOw6RQhURfFbuP4377EPH76rkYHVoRXjiNfHFKIVFSvpIUcMcIsEnx9wyJ1gBqdtx3rH8dATkCjxJxol/QmMEeZM6QzRN1wS0K9GReaggW3vMRFLK3DVC6TsRaIPDSt4/P14jwuc2jtQBCvuenWPW46vSqmthwIpMQt/j6mAs/"
		"IWe5bJBSZKe8KlTTNfs3az0iYfexfjaRPxWQJBqOgIbtgnp9zDyZ7niivPMmZLJ3UO3aqXbd75C0jOi4C3phVAN/oWePkMESvliTDI96aYIi5E73iRzBA08PN9Vhi59G4RDwaG904kNNEXuMBZANmz07sqRyfjaZ9Wojcg9fglUGZP50ukpO2ZHx9UBUTwixZ5OdAWXigzbtyYiU3Rc4/QFGtAGTUaGOXfQcUkoGYvAPyRmJ+2Z3NzzConBMD1zaVPWASveYMnTvj44Hoseb5z2EsaO86qbuVa+qbDbSgRitHd12g8Yyp0Qi47PnH27AAed97PFc+kPZBHYZ/sUHOIQIt343LP6Jdfgerz0Bze0mvElmJZZkCgUkb9DjIH+M2XeVKYbASJqtZHHL/v7kB0tL8WTr7/jiq3NtzTjKgmndOtod/hax4EHEYb5PnK7DF7HbgmU5LRqtA6YdNgW9+EhI7HGgTHQSGL9H0BjCY9Cdsl5sx/"
		"J2NivyZj4t2POdiFqIR8TMZeU2b996oMU6J+ciFaIy+X2McsEROWlaNGT5nPBEYhL7kmwRJo/7lu7PBnc4r/r5tZ4SlxYtsIa+pcysDrNmZQKzNkHHqPQLliu4LhzdCoTCaYTUqNpLDq03wMwfQRViwZLnWMgxGFGzM8J/+w64ZHpZ90V/7F8hDtmxx8GSEVgkqKqumrjZuTNMP1pVqli3Ottx9sU09sQvWo9TUhowyuhHs55+dfNn1WfxAU5rosrV6yS9jy47myHtZDV9B7ybe2nHm4aF1il04zk93mGMkt54gcxq1NWnv8TBgtoPJgfGF8svT2gKcr42HJXZsaudX5txMSl9pxsVsbJo4igkpfSx423TbnxsgKVnUJITj/Ot4Ngs3MnC6t+obwOOagSF/D33DhqVWiQ1lzGO7V6VGNIb19eAYjuxsjolhaTOJNz0P+/y+jo5BQ49FS8magNXNBJVrIXEhGVHJKAY0jqhpwqSnuAX/"
		"XbK5JyJQ8kGYBGsQfbDi0QoalFTDwblav2MJ7k1RyJHImYGj/d6YVSJ83SiftsT5jZjqDpxGx7RCNpepjw6zGj6YzcJkAzq3SoFWGzVsCGSPYWWiA3PMB4PHTn+KBi9CxA27sSadM8lHvpl0Paue0MTYCAkq5NkDnAOn4l36tav6nDAX8PW1t3keMenhDvL3yYI8JjhNw+62dmn5mVerOtIm1zGetKEYAACv/Z4bj/QNdpAaKLgIUEP1H5brSAhBiEPf81F6uii5vQk1i8xIwN0NWjhPjBkMehaF4CEQslwM3axNw/heztJch3Km9ioUgdjptRsnA30q3CgS+gWvTBfjj879D/SShuXol6DTk2TEso4DYoROTV6AY6IcfKQ1USv+NaGpfF0/zD4r87SUu53EwZRBEjOyg8xsvD6NxKT+yGcKSNZkL1d6BDDQ0wS/71mSZeDsWmHDI19uwzUtS/kQxSGtD9qIV6BmLTUPkIWWmQGP8Czc/"
		"P1pOd3GUSMkXNGH5DuFCNt4oDsBxGZS4O1gmByabBnjDTDgCxsSOUkvviv2m2Z4HLXIyKOUeB1xqAucJyRyF5n1bM/U6UxhG0Cwtg09cA/Fz1/kQKB6ToUSq9xVLAO5kcWSFMcsje2Io2csv+nFGg/nLMygpqJXq9zGi8Bpc73waj7JOkmj0UwBB3eB96BWiz9f7IjI8uSTxwABzCvFDTugrynHtQH/A2AAsf8BsBB6oRjawSuyVpGxDnA8M9WykFMHA8Lqll1d+f2BVeZ/RHuAOTw7r9FcnXioCotdzTQvOprioFzgbnIGO839okwi/r3Ef/pFYJ0wgc+s1YxH3d/hwWBFS+"
		"3X7Ex0wxWSRICWm2x4ZW1A7SQPfA61eIaFqYM7Vf7iZhsC2a7HebgqV0VIcznOB9ODWBVOsNQy96vAlxKXNCCGuct99gPkI2zTQi34gDf1dxJoMdDMc7MVVlwdANTzwZLZGibtNqw0h7dOTw3dUUIRLxYPBsntKjdNMvgzxUUfYkIvE/sV7pmkdVEqCVpilv+oVN7uEDT78meoSni5SSRTSNiasUHvq0hqFLtiu7mpMop7j4RZlr+TncYpNDKVcquB3+QNK8yKPc89OCIYW83e2A8egM8WitzwGfjBtktyVB0RTVhh1ohjmqeb6I0BRCBaevoJA+qC0WIRh+fbd4YXFFcKWJxpiW6TvkyrJ3q0KfILVeJY7qLXVhh9HoXWSB05Gl7PD2tFIueST5fMivEyEQ4Dm4Gm8Ue0lGpSIieaA9d8YwZk8Irjdhef1/"
		"N74f28JUReqJZcUDbNKXJwNqTW6U9STUTWnDcYQTv8iD8qWGnZRc4XdVursdFhKcTsCUp7eJA/A/mx5mI1l2bVWbupgHHH7KQByshIdZTQL8h/uVQ0MeePOIkbxjJ4Y0eYeEEbLr1dNI5+PGTAyxwanjvqiMiWvtAuawRYX2VQruHhiQkVBmDHW6qtxptQhLzHUaZ5PLWSVDZErRSVdaJheer9waoFNLr9Hpe7V0MdUW2DqQBtlA56RRXvOB8hED/n9OiLLZs9RtMrhxOVB7aj9IvjjX5j2fg+UulcMwusMnfTe3T+3gz8yh9GFps463WQLH4lBcDWLPeWv13IvtX/h6dwU+lzLdyEQfoYkxvBPoEyg7kW5sr7niB9w+mOZ+nyD5RdX46D6U6eERT7s71swXFBo0WeAmdCf2HeUhhKtt5QlNsXJCuUVJ6f8HNsBs7y/HhqSIMUaSJ3tpvRgAphD4Af2kg/jEmq/03dWIVF1qpwrfuS+"
		"pFqMuk9j41Nr4bgCY+LsC+9zgFV8cVjuai/DizKFRsxQtxlP4uIeq9ocach1GDUYcevf/Tpb3d9HzxB+gJ/IzHciJc2i8Ebv7KW1ikAQXw3oxRbtM0DN2wq58AJrx/xUNj+0aJKyYDnUXN9v2F89gEFYFpZg2EWigifzF+ybRLAFP/LNcOF/pie9V+W7Uxt8ij649TN7NZ/lhRv91PfLyIwFIuwWvniCspmIe5naW1wUjdM68HjqGwVz0SmxQ4EmqgAIk5oiY0TaFc8rYKDnL4LyAt4rUb6X5Xpspmw8UGIScbmETN9NPZ892Qi/797MjWWxKtaX/dNVp8ZFRjI89/8Csu30D5PT1XXcRjgKE/dGgBnks0RCPCIT4oafHCgZyuxyBPflADeCt62mdRM1TicnT/UvjtuQnrJxSfJ5dTOU5cQ0i/cDHVbEzY0edx29h+smKtLoAtftGIGc96j/l2B9kT5Z5C2Z6nYe0v+"
		"c8QvQetUCiELuC4bLU2xKHR8JNiSP49sk8e8pPdyhtbUSAMi4qSORBeylIo5zOZf5HG4R0+867UgBMjzVMXi3EcRRqi2OrnQkPq+ieJN/EialisdCQnnfTKfP1Smpn4pkwnh33Z9kSSPA3x3ucC48wTcbrbc/UmPzI8pOlPSunCCxyUM4oXr+vQGuZhJIDM+8OvmzpMdC0pRA+c0YG4b+yoRdUUt9wRoa008q1e8Wqx5OnuE8EutDW4OpL5gPE8N/1priBZWqRBcDfv4999JbRCUw8sQ7Mznp+Q9r6Ln5NK7cc35Qg9dym4L5reKQ9NlMmsPzpRj2HKK/2joFU450mJypgJIZyoL5xFx3lwH0E30TXyYAPDOZ8wOJMTDnYmpHLwtG7CWNzaWjWxI/zSVoGmF+/Otlnm6vr7odywCEU6YiAiItD+Pm1MAMqCRUbWjdRWguNnB9zgKDC70flApDoy/"
		"8YBsVzYO7VNigjJXvUzcQAr1UrOWPh4g3dNHW6dB0dNDETTjS6xG/hnN46KUs2WMqd0fHSxRj0acTDOdBUT1jlfd1yOSJatVXcQt2sj1tapeBBffMshVRhR6qjt7m9Wr35WOaExkrXbHYXf7c743vqrP6Zh5tknOlnqe/0BZtbhjSNxRxnW4sPwgyCwWbjwBfL1NOmBLfNgHDPM0Q+RwUo6lwi/cyLrASW0h59+5lNj2vK1mqKptx/gSXu0q68iT/b3zT9/2ruolsnaCibyYSiadHyxHKvQYtTm4l+yy4R9k9xNE5GgUPo7JErkr59BivET/mDYuR5qKV6R7PydYBRZzpyo3c1eznQDuiUWd9glBSJAUsiWnonvrOvEBZEfwfvOYxDlMRpVbzRb56wAb4POgyoJUIxhvs5MwJy1WtvF6LXMj8QXV8JA86/aDpwIZ4m88L4FWBr/Pd1L/"
		"117nAxLh4DZSieusQg1WXjhUcOO4VK4yXsTtPnSiX14yYLrA5YzQbHYREbTrUzN0fRuknJoc3rZ1pF8WmnpxrXH7tTtlmzuoHNLuw3ihGeEpUjW6x4RWsNEzQbrq0DQbZl9D2BGjCgPr/P8S2gTycvoZwrR5U/EOPqpOsQHCDkaQOUDLjHoUKQwECF18zUekmhcGRYMRoyyTqo24nDAQM9PEXt4wb99pvkeecGjzDl+OicM8y+HJ9is4WKQrKnwRrBNr/uyN+YBs+aHz9oyeVPtXn8qxY1mb7X6Z78CP/VcnmUl4Gy3Mv9L70O2+iKGoA+d7WkoK14/PeCHqsr7tC7OZGPwYX2bJqrmnS7m1L1bnJLd6Covha6U8fMSoDS9oIu939IXlE19Vp8KcH/u10bZ1EpiaNJYiXj5T9/pMFNpUtjXaplBnwy1OdOlt9dKRBCrSYFjWF/uav1ioi07d30tuiliwjP39JZ1+"
		"Tkxc0JE0IgyvNlpXZw4BDvNek5zdDovWepxGs/sUTPylBGmX85NlSCwyQjAb11c40zn6TGADMC4JTc7EbExsnG4Qnep3R0OVOQdlx1v4Z/1JUXGdAJk59hP1H75EwRS9jcmpnESVPN4AlAmRItoK0/zaKNBDtM5JFU+BqE7zwPkum0uNFsXleE1n0xkFpUXfGdMsERyxvW1ATy5YiETzEhwP3TbjNHS9bJkYQnCCDisp9u37cO5dm5HrS4zXS930AlW14glFS40wda5omBHsjyIcGCbU1srrDZ8UCAwceYo3wcWgYMDJFgz87hbSaxL7v6fV3EA9aSVHoadJ9cbCj40CzzETEmF0pXN5MTtLJ+CvQRwIz+ggvdPMxOBe3f2sfhZ6rVVo/K5", ENDITEM, 
		"Name=__VIEWSTATEGENERATOR", "Value=856594CF", ENDITEM, 
		"Name=__VIEWSTATEENCRYPTED", "Value=", ENDITEM, 
		"Name=__ASYNCPOST", "Value=true", ENDITEM, 
		LAST);

	web_url("Error.aspx", 
		"URL=https://lt4-cmi.stratacare.net/LT4-CMI/Error.aspx?aspxerrorpath=/LT4-CMI/default.aspx", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://lt4-cmi.stratacare.net/LT4-CMI/default.aspx", 
		"Snapshot=t156.inf", 
		"Mode=HTTP", 
		LAST);

	web_url("default.aspx_5", 
		"URL=https://lt4-cmi.stratacare.net/LT4-CMI/default.aspx", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://qasso.stratacareservices1.net/adfs/ls/", 
		"Snapshot=t157.inf", 
		"Mode=HTTP", 
		LAST);

	web_submit_data("ls_2", 
		"Action=https://qasso.stratacareservices1.net/adfs/ls/", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://qaidplt4.stratacareservices1.net/StrataCareIdentityProvider/users/issue.aspx?wa=wsignin1.0&wtrealm=http%3a%2f%2fqasso.stratacareservices1.net%2fadfs%2fservices%2ftrust&wctx=60437cec-b947-46d6-93da-8245b902e3c2&wct=2015-04-24T19%3a03%3a41Z&whr=https%3a%2f%2fqaidplt4.stratacareservices1.net%2fstratacareidentityprovider%2ftrust", 
		"Snapshot=t158.inf", 
		"Mode=HTTP", 
		ITEMDATA, 
		"Name=wa", "Value=wsignin1.0", ENDITEM, 
		"Name=wresult", "Value=<trust:RequestSecurityTokenResponseCollection xmlns:trust=\"http://docs.oasis-open.org/ws-sx/ws-trust/200512\"><trust:RequestSecurityTokenResponse Context=\"60437cec-b947-46d6-93da-8245b902e3c2\"><trust:Lifetime><wsu:Created xmlns:wsu=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd\">2015-04-24T19:03:46.612Z</wsu:Created><wsu:Expires xmlns:wsu=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd\""
		">2015-04-25T09:03:46.612Z</wsu:Expires></trust:Lifetime><wsp:AppliesTo xmlns:wsp=\"http://schemas.xmlsoap.org/ws/2004/09/policy\"><wsa:EndpointReference xmlns:wsa=\"http://www.w3.org/2005/08/addressing\"><wsa:Address>http://qasso.stratacareservices1.net/adfs/services/trust</wsa:Address></wsa:EndpointReference></wsp:AppliesTo><trust:RequestedSecurityToken><xenc:EncryptedData Type=\"http://www.w3.org/2001/04/xmlenc#Element\" xmlns:xenc=\"http://www.w3.org/2001/04/xmlenc#\"><xenc:EncryptionMethod "
		"Algorithm=\"http://www.w3.org/2001/04/xmlenc#aes256-cbc\" /><KeyInfo xmlns=\"http://www.w3.org/2000/09/xmldsig#\"><e:EncryptedKey xmlns:e=\"http://www.w3.org/2001/04/xmlenc#\"><e:EncryptionMethod Algorithm=\"http://www.w3.org/2001/04/xmlenc#rsa-oaep-mgf1p\"><DigestMethod Algorithm=\"http://www.w3.org/2000/09/xmldsig#sha1\" /></e:EncryptionMethod><KeyInfo><o:SecurityTokenReference xmlns:o=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd\"><X509Data>"
		"<X509IssuerSerial><X509IssuerName>CN=GeoTrust DV SSL CA, OU=Domain Validated SSL, O=GeoTrust Inc., C=US</X509IssuerName><X509SerialNumber>185592</X509SerialNumber></X509IssuerSerial></X509Data></o:SecurityTokenReference></KeyInfo><e:CipherData><e:CipherValue>DtiL4b8EMMxYfR/uCG2JRAflDjpv+5/r/U2xrAO8skb4IdPTTrsNCSvCpOTTChuyv4WZLsPiwsSlpxIlPmCrRd9hWkKVB27TdD9koUyUezsCpb5PFK/KFQabek0hJaa8gTRBVqoSL8ypksEbIE1a5FA2ub6JQB0wixzAIUbR8AenSpJpIqdssbDTmatV0ICVBYLy5BmWIVis/h1ybWDXJieikcXCQwUly46xL8brvP+pzD/"
		"UuWYavLzGqyZB39UK0cmwAMPWS+bsbf4QClNjXt0utLpUK6Kwd1pvUvXbmF3YiUxGUgw6C1z2TLhU9vZO7TeZEAbAPXiPk9bxW94Raw==</e:CipherValue></e:CipherData></e:EncryptedKey></KeyInfo><xenc:CipherData><xenc:CipherValue>TKbhc3/K8VnsalSSRIyvpMdxxxNkjk5IbbHsxhD65DHHdtd3X9EGZPSTGKQiKGdkX3cVCodaVE2t676Gqq1RpqwvJfJAIlreLq9EsQhSpUDPnMpo1slM2zlPhIOnuMIw8gBbhsTG8MR/lgorvyBR8fPUveImdlkk1VfRelBJGKOtqCn3F0La8YViUWDcxf9uObZFKcL47+NLSZL8KAq/uPPexMUvLBHQQmmgcPgWQm8uthewZKielNTO3GULYX+CGjmE0CXgbmo81jPCqM/"
		"aGNdX6Pumr2UX51AgpVwePSDEkx63TINfNUr07vFW+HzRBHZFZKG7ZCGmKtKbJQe7cE3znobhl5PQbBNzjwwZBmzPrUf6HMME5KncX024ruQ2fz/oZ4YyAglZxsNhpMIMPsWZzoTAY82aHBNQGmbaJqzZ+hL+ewpLxnpgH4mYh47OoK4hW1QqB26EmWD3p7gzDuHQsgER2B4GUG1LInlOp19JJ7FHBrZl4GT/IAR/FdUb1V2/CjVuVzE9lbKXClru33plrBhTu5zEUzmVLCZxjfIEEN0WvSy33Ul1R46y1mCNVK0gqRfGRimQUuQ24aTuAlWEehtt9evivvrHpSTWVMGPI5gUJ2mKpsIAOkSYonnXo9304xrReTFVEGbMDpGOaVtJDEx3ahHMsQoSA4O+HCRHRUqAmYGQNHO7vnkLw6peaQfFiQIZxR1BNVfxHocSvUG76G2TlB2xwwzm9KT/fCuovCBuesPbsFYgmb0/"
		"jnBihLZr9aXXEADMkXizZF91paNmJO4nyKid+0X7yXn9xBI5vuGgf+TVOk4aANB/rskb7BlNofr3a5TNVpnsyFnHmKYqkZaCnRcWugQIKJlQSyNEronOnQJD+Gwb1bkasKiQCCyEz4bd1v5sXb4Q2hCkQXJ2iGRlVAGbjZstSTEQi6CX0RhXQxHDtHnRWEVttIENq9sSLQQAQLScuriYPr8cpPrQJdYpWijeCLgBoaqU/C1MbV/5bQCzLXkWyopEq2wNqfZTtR/001jLKkbjWqHZBnnTK3OFJOT3Wlf+tM1FcQfP9+tEuvUG1rhT1TESgLD/e7WjJAH5Cbyoi4AI1hg0DKxDqCXvkePu8P7qlobtPqhH7wHIQJ8/xM3sg45XJnRpy3VSC2ZSJFQ3FoFhsHCq/Dl+Ol6u2WkY++"
		"ofaad083ePQdFSeENTKCKZZQAWYDNzaYeUoXAckypTyEUrJfh5rGNikEV5qdk7LfpNrSGZ1zpDjmeAibouTkspBHJmERLYWLF93JIIEuXzJYJqmoO+wjGFwiR4YiCJgd59Qv+w4lDQo6FdAryKcOsCdz6GAqrC/WEWm8shw72+6pGtgwVZeROWJCJbK7HK2GmLpS3qV3cKZLaIxUmodDRWf4aXNzA0LCYNmEhTzyH8O48snOaJKjfKvYLeDsQV1T3ba9IekVJsAk3EW9zZb1g0ZwXTzXLmYnx1S5X0ix8s1SADsiT6jPnJGGPFei7P+pJSuMqpq/QorE0Ztr7GknRINV0RMeoZKzqrPXJTN1V2UnPp9Qn218iyv6iO7zOYlQr7dASvNvbAjA0DJjDp6J8JTgGkvu9lL/HkrWylc8+lZLymuG5fdfLZ/"
		"fsBXnslqJZUDEuPfwmyHqFJa7x3FFdzIUBmPsFRNuQr7qL9qPOqAK3Y2gdRXXxQFE89zPZ+Mlw0Cownwt8misYuMjpckCG8SMs2KdkTqO5hF40HCv1JDIrXn3k1Lk7rqj6kZW12HhG8QEFA44f4X9CPpSXSJBXYunnVWvt6Auyb67lGxa4kh3Grz1O89vBAb68S6tMp+5o9HuWuZueIHlVh/1BHXXMYu9VdQz8OxA6pJ0kcG+StaL5slw6OFCe16p0QDTqmi/cqcq1+IKV1YUpPsK07ZT1UO8jniENcPHB7I76ArebPF321zBscosEXNBDIFD/4aSGF1TCA6tXbudYQ0VlCdiNDcIyROBPQS23nRn+CzUvZ2o7BxXMBB5VcVjWb1ieQP7dQrR59LP+"
		"e4ZtQAllQ6HJrjrYAVPk9H7LxAVW8cpgLCsr7bvSHcALhtq1yN9DpxhFufD3KWp26DLT7NUXP3ZxZGSwEznMDQjbu0h9JpJGmoxugAmR+D0otgnYMU7jzS0BVtXR0mMiVoNCy4yglPQLtTjPB9eaVp3OE6q+PQZlimvOzO0cMFnVBVqkzbFZaqVf8OFt2dwhfVd7QszmdCCz8ay6+uQAns7Hat9eD20G92MBt4oe7pWRxKYgk2Ghv27RKx3rzTwJ3Pk+vd6zlw7QRZj4LpPopnoAGREACnthBLUqVk/7fGavhM9tEY1zSblEVd7a1MkEJZzUUhfml5/5FczH7DDa8CcuCjnHzVO1Uot3DYgEe33KubQEF/PHkaoB4K9vQcp331NhgU8DW0miSUbAGTti+YT5g5GK/296SFJsGrRFKK2waIyK4kVGbnW5qtCR/J1p/Sfd8ewk+n/+GGisO8OJVrLSrRhvQqpzw6PzxugkaLI29bFB9Tss+"
		"CAgdaqk7X2Ltq44iqGPLYYHiEme8wz8f9dbgx9RdhaVkB46r4Dln4wCbLvkuAhW/nYfaIFy9UfWimrQUoaE2iHirbwOpt+wRD/k/OXjAwt5YEaVMl9oGvTBFlKlA40A4ACEn093MpUkJCpTE+nmsMTkCrwYqVyXOqgXR4yCmTVNaHIzU6ZnuM45lwWwljEb15tdhrN2OKd/H6Niu8tcljhWd1+sufr7CgNa3m36SkF14PkB2Hjxywz3CWV2umhAm4Wx9z9t6U6IKWLr25AmDA0rTDBLikjEEh/uyy1xVqsD8yEMTe7yWHB82N1L4SsasfdXWaYLZaBuZrcMF1+XUZlcV5Uuhw6mlALH5+XI7BJ47n2/U0JW/vNJ4juF3lUHFlDfqnUATtjLgmoXbEv9UDGt7i/0UCWYjOtUy+pe1tpXq/FXgM+QmOE2468brSEYKdqcYUbWjFZvqMotH4oPUiqBGMHBs8OhMeNJTBiNf06M54HLAJ6xxBy"
		"/MB0bC8lWLn7zXZluEZ80oNhKOFXgVJ2prygSGlCH28aZ+D2nhtoJmt8Bnt9YdmzYCzjW6ZTFZD/XUrN2mSSVUP7KiVhUq7lVxO47LoexqNOwOZs806FLYWHkJAS/t4Qv7FVfVZDIAnjOSLvKrFBZ1+TOqtSQm301xZLOWe73ytneG0ZsjUgEesnZz/H3Urga7p9dfzu7zPxjQf1742e3VDDjR9c16+nSTd3240HMTYlnAFi+0gaK1DgD+Fwt7xr4HQxKZXLR51V3KaGDIBGch0kR2qVBhWI8HE+HQtb5dhxjDM5YGGi/LJgd1Mxe+n6Y1w3NfCPfiwCTY2AYYEDXkmTR+pdQA0JQEFQAdgRFBLeOo+TQzjBgl+/P5hxHVmCHVZxstqskOwlegb4G7nO6N/7jPLD/x+jctf3SI2unYAZ/gUAwKD3jrxPNYu/AZbrSdXUMOfrVJWb5rGQv09ngefjfdf8flLRQG93b88E2l7ls+"
		"h694g7UVtp08HlD8Y3k37y1tfUj5qOqfTb92En8uy2DZhaS3aiIjt5qLjD5i2Vm3EwhlNzedIay5MlfkcoRmexhHYCrkqnAiyHPZnN7G+HheQKB6Sq/8bF9AkgG+NfKJjQUyGyn7AnkPvfl+R1E16A2dUbvWTtqy6YUBKwoc1ZZPZ2z//UPh7HyexzS2U1kMBImW43ky/C4Gnbo96gpEh8g8HHrOvSpmrQvSWnqHhziVnTBLRuoTM163dqCB+zXtU0MQzcrjFprYWteOHB3s4klTuBE+ENo2aq/oKvdTnOEUOjvWWNF+IvzPdfp13KJTcrbz9Sd2rSzOSDjQCgAEDvj91hG13TmqXHqWsWk/L0Ks++YQziSaqBdo8sPv8JMnCUjh/pT4+UuuvyBHFJRQcRuvw5s6Q5B6b620LNvyy1ikCmpCAK3f4+jFuaE3ShJSVcfoZFMX2y6MTS1xYAiE70gwsxBzTdAtIwB+ZPaxQ3E/SWzHrI1P+"
		"IHV1qV7o5dqC8I1OvXP+NC6pT3Q49NMcWVzVL8zUrHa+yZmbTsXxFnXmJzfHA/WucwBAxt+pw6kkcTks4HYTpbrbgOuDaQkSDxP3s0m6wcF8w95+NK/wR0cGUpD/YOVVqUROt7vzyFQenoyjxn/irpQLlK5NY18pqwUO6sQaWmf5XQHVvYZgkIvaeRzJ/H4Ifb1srf3SjADCo25CNJ2UQw8xUtnzpwpqs4YD4izVxa8OavtNzP3ZbPbGFrHMOQTZTLetCZ7xaJIrFTPgdg1chNshcl+t2wGW71+xq4F/2tnPTS9wLYaVtdBavUd5rOwpfQo2LnPLjS8etdSNr+HUBPRuVkImvG+xRYSaHvCFd73mkV9g1XCxnd9NaGoEWbbffMuwAhgyRYewnMxwSFwhMZVV0r0zUR4a5aIyo+OijqGZ0iLKgNjDFgBiWmaE0umXyUtKDLa4Qm845Rqq2DBiQDSGzfW95BjGjD1jcEky0wKLa4m/"
		"igfE8dOJ0GdDMDjlq2e4GelEtxQcJ/xg6J0C5cZ9R2lseKXWyrIoV7mSBlo0iFXd/RLOSGRTFMHPitYILtSAxWoEY3o9azFZ1ANEub70OXKa+WqaOxXbW6TS50b2Ehi9bhZ3EVwvwa154XzLicVi45LVky8A92f9NM0fb1xvMxZqI7opUDAVkSTvIGh+D6Tbox/+qdmBvEvoNzlpbbHf5s9</xenc:CipherValue></xenc:CipherData></xenc:EncryptedData></trust:RequestedSecurityToken><trust:RequestedAttachedReference><o:SecurityTokenReference k:TokenType=\"http://docs.oasis-open.org/wss/oasis-wss-saml-token-profile-1.1#SAMLV1.1\" xmlns:k=\"http://docs.oasis-open.org/wss/"
		"oasis-wss-wssecurity-secext-1.1.xsd\" xmlns:o=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd\"><o:KeyIdentifier ValueType=\"http://docs.oasis-open.org/wss/oasis-wss-saml-token-profile-1.0#SAMLAssertionID\">_77efc3a8-a265-4505-8224-39bac7de40cb</o:KeyIdentifier></o:SecurityTokenReference></trust:RequestedAttachedReference><trust:RequestedUnattachedReference><o:SecurityTokenReference k:TokenType=\"http://docs.oasis-open.org/wss/"
		"oasis-wss-saml-token-profile-1.1#SAMLV1.1\" xmlns:k=\"http://docs.oasis-open.org/wss/oasis-wss-wssecurity-secext-1.1.xsd\" xmlns:o=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd\"><o:KeyIdentifier ValueType=\"http://docs.oasis-open.org/wss/oasis-wss-saml-token-profile-1.0#SAMLAssertionID\">_77efc3a8-a265-4505-8224-39bac7de40cb</o:KeyIdentifier></o:SecurityTokenReference></trust:RequestedUnattachedReference><trust:TokenType>urn:oasis:names:tc:SAML:1.0:assertion<"
		"/trust:TokenType><trust:RequestType>http://docs.oasis-open.org/ws-sx/ws-trust/200512/Issue</trust:RequestType><trust:KeyType>http://docs.oasis-open.org/ws-sx/ws-trust/200512/Bearer</trust:KeyType></trust:RequestSecurityTokenResponse></trust:RequestSecurityTokenResponseCollection>", ENDITEM, 
		"Name=wctx", "Value=60437cec-b947-46d6-93da-8245b902e3c2", ENDITEM, 
		LAST);

	return 0;
}