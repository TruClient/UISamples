a002_Invoke_App()
{
    // *******************************************************************************************
	// Created by:	Jason Wei
	// Create Date:	8/6/08
	// Description:	This action launches the StrataWare login window in an IE window
	// History:		
	// 
	// *******************************************************************************************

// 	//web_add_cookie("VersionNumber=6.01.0400.030; DOMAIN={CustomerCode}.stratacare.net");
//
// 	web_add_cookie("CustomerName=CareSolutionsDB vmqaApp09 & QALOADDB\\I1; DOMAIN={CustomerCode}.stratacare.net");
//
// 	web_add_cookie("CustomerCode={CustomerCode}; DOMAIN={CustomerCode}.stratacare.net");
//
// 	web_add_cookie("PathWaysAccess=True; DOMAIN={CustomerCode}.stratacare.net");
//
// 	web_add_cookie("SRMAccess=True; DOMAIN={CustomerCode}.stratacare.net");
//
// 	web_set_max_html_param_len("16262");
// 	web_reg_save_param("LoginViewState","LB=\"__VIEWSTATE\" value=\"","RB=\"",LAST);
// 	web_reg_save_param("LoginEventValidation","LB=\"__EVENTVALIDATION\" value=\"","RB=\"",LAST);
// 	web_url("{CustomerCode}.stratacare.net",
// 		"URL=https://{CustomerCode}.stratacare.net/",
// 		"Resource=0",
// 		"RecContentType=text/html",
// 		"Referer=",
// 		"Snapshot=t1.inf",
// 		"Mode=HTML",
// 		LAST);
//
// 	lr_output_message( "Viewstate: %s", lr_eval_string("{LoginViewState}") ); //DEBUG CODE
//
//
// 	//web_reg_save_param("ParamName","LB=","RB=",LAST);
// 	web_reg_save_param("WebResourceEncoding","LB=/WebResource.axd\?","RB=\"", "ORD=1", LAST);
// 	web_reg_save_param("ScriptResourceEncoding1","LB=ScriptResource.axd\?","RB=\"", "ORD=2", LAST);
// 	web_reg_save_param("ScriptResourceEncoding2","LB=ScriptResource.axd\?","RB=\"", "ORD=3", LAST);
//
// 	web_url("Login.aspx",
// 	"URL=https://{ServerURL}/Login.aspx",
// 		"Resource=0",
// 		"RecContentType=text/html",
// 		"Referer=",
// 		"Snapshot=t2.inf",
// 		"Mode=HTML",
// 		EXTRARES,
// 		"Url=images/strataware_logo.gif", ENDITEM,
// 		LAST);

    //lr_set_debug_message( LR_MSG_CLASS_JIT_LOG_ON_ERROR, LR_SWITCH_ON );	//DEBUG CODE

	//AJAX CODE
	web_add_cookie_ex("Cookie=VersionNumber=7.03.0001.050; domain={ServerURL}; path=/", ENDITEM, 
		"Cookie=CustomerLogoFile=images/strataware_portal_logo.gif; domain={ServerURL}; path=/", ENDITEM, 
		LAST);

	web_browser(lr_eval_string("{ServerURL}"), 
		DESCRIPTION, 
		ACTION, 
		"Navigate=https://{ServerURL}/", 
		LAST);

//	lr_set_debug_message( LR_MSG_CLASS_JIT_LOG_ON_ERROR, LR_SWITCH_OFF );	//DEBUG CODE

	return 0;
}
