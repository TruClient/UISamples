//#include <stdio.h>
//#include <stdlib.h>

a002_Login()
{
	// *******************************************************************************************
	// Created by:	Jason Wei
	// Create Date:	8/28/08
	// Description:	This action logs into the 6.02 StrataWare application and later
	// History:		
	// 
	// 10/07/2009 - JWei:	Added NOLOCK to user SQL query
	// *******************************************************************************************


	int iAttempts = 1;

	lr_save_string("", "SessID");

    
	lr_start_transaction("a002_LoginTime_Total");

	while( (strcmp(lr_eval_string("{SessID}"), "") == 0) && (iAttempts < 20))
	{
		lr_start_transaction("a002_LoginTime_Individual");

		lr_output_message("Attempt #: %i", iAttempts);

		//AJAX CODE
		lr_think_time(18);
		
		//sleep(18000);
		
		//Enter customer code if needed
// 		web_edit_field("Login1$CustomerCode",
// 			"Snapshot=t459.inf",
// 			DESCRIPTION,
// 			"Type=text",
// 			"Name=Login1$CustomerCode",
// 			ACTION,
// 			"SetValue={CustomerCode}",
// 			VERIFICATION,
// 			"NotFound=Warning",
// 			LAST);

// 		web_edit_field("Login1$AccountCode",
// 			"Snapshot=t15.inf",
// 			DESCRIPTION,
// 			"Type=text",
// 			"Name=Login1$AccountCode",
// 			ACTION,
// 			"SetValue={OrigAccountID}",
// 			LAST);
		AssignUserName(iAttempts);
		//BuildUserName();
		//lr_save_string(lr_eval_string("{GetDatFileAdminUserName}"), "AdminUserName");

		//Debug code - hardcode login user name for testing purposes
		//lr_save_string("technicalservices@stratacare.com", "AdminUserName");

		lr_output_message("Logging in with UserID: %s", lr_eval_string("{AdminUserName}"));

		//lr_set_debug_message( LR_MSG_CLASS_JIT_LOG_ON_ERROR, LR_SWITCH_OFF );	//DEBUG CODE
		lr_output_message("VuserID: %s, UserID: %s LoadGen: %s", 
		lr_eval_string("{VuserID}"), lr_eval_string("{AdminUserName}"), lr_eval_string("{LoadGenName}"));
		//lr_set_debug_message( LR_MSG_CLASS_JIT_LOG_ON_ERROR, LR_SWITCH_ON );	//DEBUG CODE

//		6.06 Version:
// 		web_edit_field("Login1$UserName",
// 			"Snapshot=t16.inf",
// 			DESCRIPTION,
// 			"Type=text",
// 			"Name=Login1$UserName",
// 			ACTION,
// 			"SetValue={AdminUserName}",
// 			LAST);
// 
// 		web_edit_field("Login1$Password", 
// 			"Snapshot=t17.inf",
// 			DESCRIPTION,
// 			"Type=password",
// 			"Name=Login1$Password",
// 			ACTION,
// 			"SetEncryptedValue=490a43b8652a79b13ddc020b",
// 			LAST);
 

//		6.07 Version


		web_edit_field("_login$UserName",
			"Snapshot=t16.inf",
			DESCRIPTION,
			"Type=text",
			"Name=_login$UserName",
			ACTION,
			"SetValue={AdminUserName}",
			LAST);

 
	
		web_edit_field("_login$Password", 
			"Snapshot=t17.inf", 
			DESCRIPTION, 
			"Type=password", 
			"Name=_login$Password", 
			ACTION, 
			"SetEncryptedValue=490a43b8652a79b13ddc020b", 
			LAST);


		//Don't error out on initial attempts, but error out on 10th try
		if( iAttempts < 20 ) //20
		{
			sleep( 5500 );//5500
			web_reg_save_param("SessID", "LB=SessionID=", "RB=;", "Notfound=warning", LAST);
			web_reg_save_param("UserID", "LB=UserID=", "RB=;", "Notfound=warning", LAST);
		}
		else
		{

						 lr_exit(LR_EXIT_ITERATION_AND_CONTINUE, LR_FAIL );
			 //web_reg_save_param("SessID", "LB=SessionID=", "RB=;", LAST);
			 //web_reg_save_param("UserID", "LB=UserID=", "RB=;", LAST);
			//web_reg_save_param("SessID", "LB=SessionID=", "RB=;", LAST);
			//web_reg_save_param("UserID", "LB=UserID=", "RB=;", LAST);
		}
		
		web_reg_save_param("WidgetContainerID", "LB=<span id=\"WidgetContainer", "RB=_WidgetTitle\">My To-Do List</span>", LAST);
		
		web_button("INPUT", 
			"Snapshot=t18.inf", 
			DESCRIPTION, 
			"Type=submit", 
			"Tag=INPUT", 
			"ID=_login_LoginButton", 
			ACTION, 
			"UserAction=Click", 
			LAST);
		
		lr_output_message("WidgetContainerID: %s", lr_eval_string("{WidgetContainerID}"));
		lr_output_message("SessID: %s", lr_eval_string("{SessID}"));
		lr_output_message("UserID: %s", lr_eval_string("{UserID}"));
	
		iAttempts++;
        
		lr_end_transaction("a002_LoginTime_Individual", LR_AUTO);
	}

	lr_end_transaction("a002_LoginTime_Total", LR_AUTO);

	return 0;
}

int BuildUserName()
{
	int id, scid;
	char *vuser_group;
	char userName[20] = "";
	
	lr_whoami(&id, &vuser_group, &scid);
	if( id == -1 )
		id = 1;
	sprintf(userName, "QA%d", id); 

	lr_save_string(userName,"AdminUserName");
	
	return 0;
}

int AssignUserName(int a)
{
	//Assigns a random username to the LR paramater {AdminUserName}
	char sql[1000] = "";
	char sql2[1000] = "";
	char sql3[1000] = "";
	char sql4[1000] = "";
	char sql5[1000] = "";
	char sql6[1000] = "";
	char userName[20] = "";
	char dummyValue[20] = "";
	char vuserName[20] = "";
	int iVUserID;
	int id, scid;
	char *vuser_group;
	int num;
	char myBuf[20];


	while( strcmp(userName, "") == 0)
	{
		sleep( 500 );	//Sleep for 1/2 second
		//lr_think_time(1);

// 		strcpy(sql,"select top 1 * from siteuser WITH(NOLOCK) where customerid = ");
// 		strcat(sql,lr_eval_string("{OrigCustomerID}"));
// 		strcat(sql," and accountid = ");
// 		strcat(sql,lr_eval_string("{OrigAccountID}"));
// 		strcat(sql," and siteuserid in (select siteuserid from r_siteuser_siteusergroup "
// 					"WITH(NOLOCK) where siteusergroupid in"
// 					"(SELECT SiteUserGroupID FROM SiteUserGroup WITH(NOLOCK) WHERE CustomerID=");
// 		strcat(sql,lr_eval_string("{OrigCustomerID}"));
// 		strcat(sql," and IsSystemAdminGroup=1)) and siteuserid not in (select siteuserid from "
// 					"session_activesession WITH(NOLOCK)) and IsLocked=0 order by newid()");

lr_whoami(&id, &vuser_group, &scid);
sprintf(myBuf,"%d",id);
lr_output_message("MyBuf #: %s", myBuf);

				if( a > 1 ) 
		{
			
		strcpy(sql5,"use QADB DELETE FROM Login_Stats WHERE vusername = '");
		strcat(sql5,myBuf);
		strcpy(sql6, "'");
		strcat(sql5,sql6);
    	GetStringValue(lr_eval_string("{DBServerName}"),"SiteDB","sa","123!@#care",sql5,"vusername",dummyValue);

		}




		//lr_whoami(&iVUserID,NULL,NULL);
		//lr_output_message("Integer value of vuserid: %d", iVUserID);
		//strcpy(sql,"select top 1 * from authenticationuser where lastname = 'lt adjuster' and customerid = 35 and authenticationuserid not in (select authenticationuserid from siteuser where siteuserid in (select siteuserid from session_activesession)) and emailaddress not in (SELECT username from QADB.dbo.Login_Stats WHERE scriptname = '002_AdjusterPortal_MyToDoList_BillApprove_New') order by newid()");
    	
		strcpy(sql,"select top 1 * from authenticationuser where emailaddress = 'lt_adjuster_35_1@stratacare.com' and customerid = 35 and authenticationuserid not in (select authenticationuserid from siteuser where siteuserid in (select siteuserid from session_activesession)) and emailaddress not in (SELECT username from QADB.dbo.Login_Stats WHERE scriptname = '002_AdjusterPortal_MyToDoList_BillApprove_New') order by newid()");
		
		GetStringValue(lr_eval_string("{DBServerName}"),"SiteDB","sa","123!@#care",sql,"EmailAddress",userName);
		strcpy(sql2,"use QADB INSERT INTO Login_Stats VALUES ('");
		strcat(sql2,userName);
		strcpy(sql3, "','002_AdjusterPortal_MyToDoList_BillApprove_New',getdate(),'");
		strcat(sql2,sql3);
		strcat(sql2,myBuf);
		strcpy(sql4, "')");
		strcat(sql2,sql4);
		GetStringValue(lr_eval_string("{DBServerName}"),"QADB","sa","123!@#care",sql2,"EmailAddress",dummyValue);

	}

	lr_save_string(userName,"AdminUserName");

	return 0;
}
