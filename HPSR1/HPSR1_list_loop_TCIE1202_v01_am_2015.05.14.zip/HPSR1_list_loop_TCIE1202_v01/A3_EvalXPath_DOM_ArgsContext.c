A3_EvalXPath_DOM_ArgsContext()
{
	return 0;
}
