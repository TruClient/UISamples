A2_EvalXPathArgsContext()
{
	return 0;
}
